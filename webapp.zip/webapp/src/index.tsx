import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

type Bindings = {
  DB: D1Database;
  AI: Ai;
}

const app = new Hono<{ Bindings: Bindings }>()

// Enable CORS
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// ==================== AUTH API ====================

// Register new user
app.post('/api/auth/register', async (c) => {
  try {
    const { email, password, full_name, role } = await c.req.json()
    
    // Validate input
    if (!email || !password || !full_name || !role) {
      return c.json({ error: 'All fields are required' }, 400)
    }
    
    if (!['admin', 'doctor', 'patient'].includes(role)) {
      return c.json({ error: 'Invalid role' }, 400)
    }
    
    // Check if user exists
    const existing = await c.env.DB.prepare(
      'SELECT id FROM users WHERE email = ?'
    ).bind(email).first()
    
    if (existing) {
      return c.json({ error: 'Email already registered' }, 400)
    }
    
    // Insert user (in production, hash password with bcrypt)
    const result = await c.env.DB.prepare(
      'INSERT INTO users (email, password, full_name, role) VALUES (?, ?, ?, ?)'
    ).bind(email, password, full_name, role).run()
    
    const userId = result.meta.last_row_id
    
    // Create profile based on role
    if (role === 'patient') {
      await c.env.DB.prepare(
        'INSERT INTO patients (user_id) VALUES (?)'
      ).bind(userId).run()
    } else if (role === 'doctor') {
      // For doctors, require additional info during registration
      return c.json({ 
        message: 'Doctor account created. Please complete your profile.',
        userId,
        requiresProfile: true
      }, 201)
    }
    
    return c.json({ 
      message: 'Registration successful',
      userId,
      role
    }, 201)
  } catch (error) {
    console.error('Registration error:', error)
    return c.json({ error: 'Registration failed' }, 500)
  }
})

// Login
app.post('/api/auth/login', async (c) => {
  try {
    const { email, password } = await c.req.json()
    
    if (!email || !password) {
      return c.json({ error: 'Email and password required' }, 400)
    }
    
    const user = await c.env.DB.prepare(
      'SELECT * FROM users WHERE email = ? AND password = ?'
    ).bind(email, password).first()
    
    if (!user) {
      return c.json({ error: 'Invalid credentials' }, 401)
    }
    
    // Return user info (in production, return JWT token)
    return c.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        role: user.role
      }
    })
  } catch (error) {
    console.error('Login error:', error)
    return c.json({ error: 'Login failed' }, 500)
  }
})

// ==================== PATIENT API ====================

// Update patient profile
app.put('/api/patients/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    const data = await c.req.json()
    
    const { gender, blood_group, date_of_birth, phone, address, emergency_contact, allergies, chronic_conditions } = data
    
    // Check if patient profile exists
    const existing = await c.env.DB.prepare(
      'SELECT id FROM patients WHERE user_id = ?'
    ).bind(userId).first()
    
    if (existing) {
      // Update existing profile
      await c.env.DB.prepare(`
        UPDATE patients 
        SET gender = ?, blood_group = ?, date_of_birth = ?, phone = ?, 
            address = ?, emergency_contact = ?, allergies = ?, chronic_conditions = ?
        WHERE user_id = ?
      `).bind(gender, blood_group, date_of_birth, phone, address, emergency_contact, allergies, chronic_conditions, userId).run()
    } else {
      // Create new profile
      await c.env.DB.prepare(`
        INSERT INTO patients (user_id, gender, blood_group, date_of_birth, phone, address, emergency_contact, allergies, chronic_conditions)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(userId, gender, blood_group, date_of_birth, phone, address, emergency_contact, allergies, chronic_conditions).run()
    }
    
    return c.json({ message: 'Profile updated successfully' })
  } catch (error) {
    console.error('Update profile error:', error)
    return c.json({ error: 'Failed to update profile' }, 500)
  }
})

// Get patient profile
app.get('/api/patients/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    const patient = await c.env.DB.prepare(`
      SELECT p.*, u.full_name, u.email 
      FROM patients p
      JOIN users u ON p.user_id = u.id
      WHERE p.user_id = ?
    `).bind(userId).first()
    
    if (!patient) {
      return c.json({ error: 'Patient not found' }, 404)
    }
    
    return c.json(patient)
  } catch (error) {
    console.error('Get patient error:', error)
    return c.json({ error: 'Failed to get patient' }, 500)
  }
})

// Get patient medical history
app.get('/api/patients/:userId/history', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Get patient id from user id
    const patient = await c.env.DB.prepare(
      'SELECT id FROM patients WHERE user_id = ?'
    ).bind(userId).first()
    
    if (!patient) {
      return c.json({ error: 'Patient not found' }, 404)
    }
    
    const history = await c.env.DB.prepare(`
      SELECT mh.*, d.name as disease_name, u.full_name as doctor_name
      FROM medical_history mh
      LEFT JOIN diseases d ON mh.disease_id = d.id
      LEFT JOIN doctors doc ON mh.diagnosed_by = doc.id
      LEFT JOIN users u ON doc.user_id = u.id
      WHERE mh.patient_id = ?
      ORDER BY mh.diagnosis_date DESC
    `).bind(patient.id).all()
    
    return c.json(history.results)
  } catch (error) {
    console.error('Get history error:', error)
    return c.json({ error: 'Failed to get medical history' }, 500)
  }
})

// Add medical history entry
app.post('/api/patients/:userId/history', async (c) => {
  try {
    const userId = c.req.param('userId')
    const { disease_name, diagnosis_date, status, notes } = await c.req.json()
    
    // Get patient id
    const patient = await c.env.DB.prepare(
      'SELECT id FROM patients WHERE user_id = ?'
    ).bind(userId).first()
    
    if (!patient) {
      return c.json({ error: 'Patient not found' }, 404)
    }
    
    await c.env.DB.prepare(`
      INSERT INTO medical_history (patient_id, disease_name, diagnosis_date, status, notes)
      VALUES (?, ?, ?, ?, ?)
    `).bind(patient.id, disease_name, diagnosis_date, status, notes).run()
    
    return c.json({ message: 'Medical history added successfully' }, 201)
  } catch (error) {
    console.error('Add history error:', error)
    return c.json({ error: 'Failed to add medical history' }, 500)
  }
})

// ==================== DOCTOR API ====================

// Complete doctor profile
app.post('/api/doctors/profile', async (c) => {
  try {
    const { userId, specialization, license_number, phone, years_of_experience, qualification, consultation_fee } = await c.req.json()
    
    // Check if profile exists
    const existing = await c.env.DB.prepare(
      'SELECT id FROM doctors WHERE user_id = ?'
    ).bind(userId).first()
    
    if (existing) {
      return c.json({ error: 'Doctor profile already exists' }, 400)
    }
    
    await c.env.DB.prepare(`
      INSERT INTO doctors (user_id, specialization, license_number, phone, years_of_experience, qualification, consultation_fee)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(userId, specialization, license_number, phone, years_of_experience, qualification, consultation_fee).run()
    
    return c.json({ message: 'Doctor profile completed' }, 201)
  } catch (error) {
    console.error('Complete doctor profile error:', error)
    return c.json({ error: 'Failed to complete profile' }, 500)
  }
})

// Get all doctors
app.get('/api/doctors', async (c) => {
  try {
    const doctors = await c.env.DB.prepare(`
      SELECT d.*, u.full_name, u.email 
      FROM doctors d
      JOIN users u ON d.user_id = u.id
      ORDER BY u.full_name
    `).all()
    
    return c.json(doctors.results)
  } catch (error) {
    console.error('Get doctors error:', error)
    return c.json({ error: 'Failed to get doctors' }, 500)
  }
})

// Get doctor's patients
app.get('/api/doctors/:userId/patients', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Get doctor id
    const doctor = await c.env.DB.prepare(
      'SELECT id FROM doctors WHERE user_id = ?'
    ).bind(userId).first()
    
    if (!doctor) {
      return c.json({ error: 'Doctor not found' }, 404)
    }
    
    // Get unique patients who have appointments with this doctor
    const patients = await c.env.DB.prepare(`
      SELECT DISTINCT p.*, u.full_name, u.email
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      JOIN users u ON p.user_id = u.id
      WHERE a.doctor_id = ?
      ORDER BY u.full_name
    `).bind(doctor.id).all()
    
    return c.json(patients.results)
  } catch (error) {
    console.error('Get doctor patients error:', error)
    return c.json({ error: 'Failed to get patients' }, 500)
  }
})

// ==================== APPOINTMENTS API ====================

// Create appointment
app.post('/api/appointments', async (c) => {
  try {
    const { patientUserId, doctorId, appointment_date, appointment_time, reason } = await c.req.json()
    
    // Get patient id from user id
    const patient = await c.env.DB.prepare(
      'SELECT id FROM patients WHERE user_id = ?'
    ).bind(patientUserId).first()
    
    if (!patient) {
      return c.json({ error: 'Patient not found' }, 404)
    }
    
    await c.env.DB.prepare(`
      INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status)
      VALUES (?, ?, ?, ?, ?, 'scheduled')
    `).bind(patient.id, doctorId, appointment_date, appointment_time, reason).run()
    
    return c.json({ message: 'Appointment scheduled successfully' }, 201)
  } catch (error) {
    console.error('Create appointment error:', error)
    return c.json({ error: 'Failed to create appointment' }, 500)
  }
})

// Get patient appointments
app.get('/api/appointments/patient/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    const patient = await c.env.DB.prepare(
      'SELECT id FROM patients WHERE user_id = ?'
    ).bind(userId).first()
    
    if (!patient) {
      return c.json({ error: 'Patient not found' }, 404)
    }
    
    const appointments = await c.env.DB.prepare(`
      SELECT a.*, u.full_name as doctor_name, d.specialization
      FROM appointments a
      JOIN doctors d ON a.doctor_id = d.id
      JOIN users u ON d.user_id = u.id
      WHERE a.patient_id = ?
      ORDER BY a.appointment_date DESC, a.appointment_time DESC
    `).bind(patient.id).all()
    
    return c.json(appointments.results)
  } catch (error) {
    console.error('Get appointments error:', error)
    return c.json({ error: 'Failed to get appointments' }, 500)
  }
})

// Get doctor appointments
app.get('/api/appointments/doctor/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    const doctor = await c.env.DB.prepare(
      'SELECT id FROM doctors WHERE user_id = ?'
    ).bind(userId).first()
    
    if (!doctor) {
      return c.json({ error: 'Doctor not found' }, 404)
    }
    
    const appointments = await c.env.DB.prepare(`
      SELECT a.*, u.full_name as patient_name, p.phone, p.blood_group
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      JOIN users u ON p.user_id = u.id
      WHERE a.doctor_id = ?
      ORDER BY a.appointment_date DESC, a.appointment_time DESC
    `).bind(doctor.id).all()
    
    return c.json(appointments.results)
  } catch (error) {
    console.error('Get doctor appointments error:', error)
    return c.json({ error: 'Failed to get appointments' }, 500)
  }
})

// Update appointment status
app.put('/api/appointments/:id', async (c) => {
  try {
    const id = c.req.param('id')
    const { status, notes } = await c.req.json()
    
    await c.env.DB.prepare(`
      UPDATE appointments 
      SET status = ?, notes = ?
      WHERE id = ?
    `).bind(status, notes, id).run()
    
    return c.json({ message: 'Appointment updated successfully' })
  } catch (error) {
    console.error('Update appointment error:', error)
    return c.json({ error: 'Failed to update appointment' }, 500)
  }
})

// ==================== PRESCRIPTIONS API ====================

// Create prescription
app.post('/api/prescriptions', async (c) => {
  try {
    const { patientUserId, doctorUserId, diagnosis, medications, instructions, valid_until, appointment_id } = await c.req.json()
    
    // Get patient and doctor IDs
    const patient = await c.env.DB.prepare(
      'SELECT id FROM patients WHERE user_id = ?'
    ).bind(patientUserId).first()
    
    const doctor = await c.env.DB.prepare(
      'SELECT id FROM doctors WHERE user_id = ?'
    ).bind(doctorUserId).first()
    
    if (!patient || !doctor) {
      return c.json({ error: 'Patient or doctor not found' }, 404)
    }
    
    await c.env.DB.prepare(`
      INSERT INTO prescriptions (patient_id, doctor_id, appointment_id, diagnosis, medications, instructions, valid_until)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(patient.id, doctor.id, appointment_id, diagnosis, JSON.stringify(medications), instructions, valid_until).run()
    
    return c.json({ message: 'Prescription created successfully' }, 201)
  } catch (error) {
    console.error('Create prescription error:', error)
    return c.json({ error: 'Failed to create prescription' }, 500)
  }
})

// Get patient prescriptions
app.get('/api/prescriptions/patient/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    const patient = await c.env.DB.prepare(
      'SELECT id FROM patients WHERE user_id = ?'
    ).bind(userId).first()
    
    if (!patient) {
      return c.json({ error: 'Patient not found' }, 404)
    }
    
    const prescriptions = await c.env.DB.prepare(`
      SELECT p.*, u.full_name as doctor_name, d.specialization
      FROM prescriptions p
      JOIN doctors d ON p.doctor_id = d.id
      JOIN users u ON d.user_id = u.id
      WHERE p.patient_id = ?
      ORDER BY p.prescription_date DESC
    `).bind(patient.id).all()
    
    return c.json(prescriptions.results)
  } catch (error) {
    console.error('Get prescriptions error:', error)
    return c.json({ error: 'Failed to get prescriptions' }, 500)
  }
})

// ==================== DISEASES API ====================

// Get all diseases
app.get('/api/diseases', async (c) => {
  try {
    const diseases = await c.env.DB.prepare(`
      SELECT * FROM diseases 
      ORDER BY category, name
    `).all()
    
    return c.json(diseases.results)
  } catch (error) {
    console.error('Get diseases error:', error)
    return c.json({ error: 'Failed to get diseases' }, 500)
  }
})

// Search diseases by symptoms
app.post('/api/diseases/search', async (c) => {
  try {
    const { symptoms } = await c.req.json()
    
    if (!symptoms || symptoms.length === 0) {
      return c.json({ error: 'Symptoms required' }, 400)
    }
    
    // Simple search - in production, use better search algorithm
    const searchTerm = `%${symptoms.join('%')}%`
    
    const diseases = await c.env.DB.prepare(`
      SELECT * FROM diseases 
      WHERE symptoms LIKE ?
      ORDER BY severity DESC
      LIMIT 20
    `).bind(searchTerm).all()
    
    return c.json(diseases.results)
  } catch (error) {
    console.error('Search diseases error:', error)
    return c.json({ error: 'Failed to search diseases' }, 500)
  }
})

// Get disease by ID
app.get('/api/diseases/:id', async (c) => {
  try {
    const id = c.req.param('id')
    
    const disease = await c.env.DB.prepare(
      'SELECT * FROM diseases WHERE id = ?'
    ).bind(id).first()
    
    if (!disease) {
      return c.json({ error: 'Disease not found' }, 404)
    }
    
    return c.json(disease)
  } catch (error) {
    console.error('Get disease error:', error)
    return c.json({ error: 'Failed to get disease' }, 500)
  }
})

// ==================== AI CHATBOT API ====================

// AI Health Assistant
app.post('/api/ai/chat', async (c) => {
  try {
    const { message, conversationHistory } = await c.req.json()
    
    if (!message) {
      return c.json({ error: 'Message required' }, 400)
    }
    
    // Build conversation context
    let context = `You are a helpful medical AI assistant for HEALNEX health platform. 
    Provide accurate, helpful medical information while always recommending users consult 
    with healthcare professionals for serious concerns. Be empathetic and clear.
    
    User message: ${message}`
    
    // Use Cloudflare AI to generate response
    const response = await c.env.AI.run('@cf/meta/llama-3-8b-instruct', {
      messages: [
        { role: 'system', content: context },
        { role: 'user', content: message }
      ]
    })
    
    return c.json({
      response: response.response,
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error('AI chat error:', error)
    return c.json({ error: 'AI service unavailable' }, 500)
  }
})

// ==================== ADMIN API ====================

// Get all users (admin only)
app.get('/api/admin/users', async (c) => {
  try {
    const users = await c.env.DB.prepare(`
      SELECT id, email, full_name, role, created_at 
      FROM users 
      ORDER BY created_at DESC
    `).all()
    
    return c.json(users.results)
  } catch (error) {
    console.error('Get users error:', error)
    return c.json({ error: 'Failed to get users' }, 500)
  }
})

// Get system statistics (admin only)
app.get('/api/admin/stats', async (c) => {
  try {
    const totalUsers = await c.env.DB.prepare('SELECT COUNT(*) as count FROM users').first()
    const totalPatients = await c.env.DB.prepare('SELECT COUNT(*) as count FROM patients').first()
    const totalDoctors = await c.env.DB.prepare('SELECT COUNT(*) as count FROM doctors').first()
    const totalAppointments = await c.env.DB.prepare('SELECT COUNT(*) as count FROM appointments').first()
    const totalDiseases = await c.env.DB.prepare('SELECT COUNT(*) as count FROM diseases').first()
    
    return c.json({
      totalUsers: totalUsers?.count || 0,
      totalPatients: totalPatients?.count || 0,
      totalDoctors: totalDoctors?.count || 0,
      totalAppointments: totalAppointments?.count || 0,
      totalDiseases: totalDiseases?.count || 0
    })
  } catch (error) {
    console.error('Get stats error:', error)
    return c.json({ error: 'Failed to get statistics' }, 500)
  }
})

// ==================== MAIN ROUTE ====================

app.get('/', (c) => {
  return c.html(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HEALNEX - Healthcare Data Management Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Rajdhani', sans-serif;
            background: #000000;
            color: #ffffff;
            overflow-x: hidden;
        }
        
        #bg-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        
        .content {
            position: relative;
            z-index: 1;
        }
        
        .neon-text {
            font-family: 'Orbitron', sans-serif;
            text-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff, 0 0 40px #00ffff;
            animation: neon-pulse 1.5s ease-in-out infinite alternate;
        }
        
        @keyframes neon-pulse {
            from { text-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff; }
            to { text-shadow: 0 0 20px #00ffff, 0 0 30px #00ffff, 0 0 40px #00ffff, 0 0 50px #00ffff; }
        }
        
        .glass-card {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(0, 255, 255, 0.3);
            border-radius: 15px;
            box-shadow: 0 8px 32px 0 rgba(0, 255, 255, 0.2);
        }
        
        .btn-neon {
            background: linear-gradient(45deg, #00ffff, #ff00ff);
            border: none;
            color: #000;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
        }
        
        .btn-neon:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px #00ffff, 0 0 40px #ff00ff;
        }
        
        .btn-neon::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .btn-neon:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .feature-card {
            background: linear-gradient(135deg, rgba(0, 255, 255, 0.1), rgba(255, 0, 255, 0.1));
            border: 2px solid transparent;
            background-clip: padding-box;
            position: relative;
            transition: all 0.3s;
        }
        
        .feature-card::before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, #00ffff, #ff00ff, #00ff00, #ffff00);
            border-radius: 15px;
            z-index: -1;
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .feature-card:hover::before {
            opacity: 1;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
        }
        
        input, select, textarea {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(0, 255, 255, 0.5);
            color: #fff;
            transition: all 0.3s;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #00ffff;
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .chat-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 999;
        }
        
        .chat-button {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(45deg, #00ffff, #ff00ff);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.5);
            transition: all 0.3s;
        }
        
        .chat-button:hover {
            transform: scale(1.1);
            box-shadow: 0 0 30px rgba(0, 255, 255, 0.8);
        }
        
        .chat-window {
            display: none;
            position: absolute;
            bottom: 80px;
            right: 0;
            width: 350px;
            height: 500px;
            background: rgba(0, 0, 0, 0.95);
            border: 2px solid #00ffff;
            border-radius: 15px;
            flex-direction: column;
        }
        
        .chat-window.active {
            display: flex;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        .message {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 10px;
        }
        
        .message.user {
            background: linear-gradient(45deg, #00ffff, #0080ff);
            margin-left: 20%;
        }
        
        .message.ai {
            background: linear-gradient(45deg, #ff00ff, #ff0080);
            margin-right: 20%;
        }
        
        .hidden {
            display: none !important;
        }
        
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 255, 255, 0.3);
        }
        
        .dashboard-nav {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .nav-btn {
            padding: 10px 20px;
            background: rgba(0, 255, 255, 0.1);
            border: 1px solid #00ffff;
            color: #00ffff;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .nav-btn:hover, .nav-btn.active {
            background: #00ffff;
            color: #000;
        }
        
        .data-table {
            width: 100%;
            background: rgba(0, 0, 0, 0.5);
            border-collapse: collapse;
        }
        
        .data-table th, .data-table td {
            padding: 12px;
            border: 1px solid rgba(0, 255, 255, 0.3);
            text-align: left;
        }
        
        .data-table th {
            background: rgba(0, 255, 255, 0.2);
            font-weight: 700;
            text-transform: uppercase;
        }
        
        .data-table tr:hover {
            background: rgba(0, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    
    <div class="content">
        <!-- Navbar -->
        <nav class="navbar fixed top-0 w-full z-50 px-6 py-4">
            <div class="container mx-auto flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-heartbeat text-3xl" style="color: #00ffff;"></i>
                    <h1 class="text-2xl font-bold neon-text">HEALNEX</h1>
                    <span class="text-sm" style="color: #ff00ff;">by QUADXTITAN</span>
                </div>
                <div id="nav-menu" class="hidden md:flex space-x-6">
                    <button onclick="showHome()" class="hover:text-cyan-400 transition">Home</button>
                    <button onclick="showFeatures()" class="hover:text-cyan-400 transition">Features</button>
                    <button onclick="showLogin()" class="hover:text-cyan-400 transition">Login</button>
                    <button onclick="showRegister()" class="btn-neon px-6 py-2 rounded-full">Get Started</button>
                </div>
                <div id="user-menu" class="hidden space-x-4">
                    <span id="user-name" class="text-cyan-400"></span>
                    <button onclick="logout()" class="hover:text-red-400 transition">Logout</button>
                </div>
            </div>
        </nav>
        
        <!-- Home Page -->
        <div id="home-page" class="min-h-screen flex items-center justify-center px-6 pt-20">
            <div class="text-center max-w-5xl">
                <h1 class="text-6xl md:text-8xl font-bold neon-text mb-6">HEALNEX</h1>
                <p class="text-xl md:text-3xl mb-4" style="color: #00ffff;">Healthcare Data Management Platform</p>
                <p class="text-lg md:text-xl mb-8" style="color: #ff00ff;">by QUADXTITAN</p>
                <p class="text-lg mb-12 max-w-3xl mx-auto">
                    Tackling healthcare data fragmentation with innovative solutions. 
                    Access your complete health records, connect with doctors, and take control of your healthcare journey.
                </p>
                <div class="flex gap-4 justify-center flex-wrap">
                    <button onclick="showRegister()" class="btn-neon px-8 py-4 rounded-full text-lg">
                        Start Your Journey <i class="fas fa-arrow-right ml-2"></i>
                    </button>
                    <button onclick="showFeatures()" class="px-8 py-4 rounded-full text-lg border-2 border-cyan-400 hover:bg-cyan-400 hover:text-black transition">
                        Learn More
                    </button>
                </div>
                
                <!-- Features Grid -->
                <div id="features-section" class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
                    <div class="feature-card glass-card p-6 rounded-xl">
                        <i class="fas fa-user-md text-5xl mb-4" style="color: #00ffff;"></i>
                        <h3 class="text-xl font-bold mb-2">Patient Dashboard</h3>
                        <p>Complete health records, appointments, and prescriptions in one place</p>
                    </div>
                    <div class="feature-card glass-card p-6 rounded-xl">
                        <i class="fas fa-stethoscope text-5xl mb-4" style="color: #ff00ff;"></i>
                        <h3 class="text-xl font-bold mb-2">Doctor Portal</h3>
                        <p>Manage patients, diagnose conditions, and prescribe treatments efficiently</p>
                    </div>
                    <div class="feature-card glass-card p-6 rounded-xl">
                        <i class="fas fa-database text-5xl mb-4" style="color: #00ff00;"></i>
                        <h3 class="text-xl font-bold mb-2">Disease Database</h3>
                        <p>Comprehensive database of diseases with symptoms, treatments, and prevention</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Login Modal -->
        <div id="login-modal" class="modal">
            <div class="glass-card p-8 rounded-xl max-w-md w-full mx-4">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-3xl font-bold neon-text">Login</h2>
                    <button onclick="closeModal('login-modal')" class="text-3xl hover:text-red-400">&times;</button>
                </div>
                <form id="login-form" onsubmit="handleLogin(event)">
                    <div class="mb-4">
                        <label class="block mb-2">Email</label>
                        <input type="email" id="login-email" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-6">
                        <label class="block mb-2">Password</label>
                        <input type="password" id="login-password" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <button type="submit" class="btn-neon w-full py-3 rounded-lg">
                        <span id="login-btn-text">Login</span>
                        <span id="login-loading" class="loading hidden"></span>
                    </button>
                </form>
                <p class="mt-4 text-center">
                    Don't have an account? 
                    <button onclick="closeModal('login-modal'); showRegister()" class="text-cyan-400 hover:underline">Register</button>
                </p>
            </div>
        </div>
        
        <!-- Register Modal -->
        <div id="register-modal" class="modal">
            <div class="glass-card p-8 rounded-xl max-w-md w-full mx-4">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-3xl font-bold neon-text">Register</h2>
                    <button onclick="closeModal('register-modal')" class="text-3xl hover:text-red-400">&times;</button>
                </div>
                <form id="register-form" onsubmit="handleRegister(event)">
                    <div class="mb-4">
                        <label class="block mb-2">Full Name</label>
                        <input type="text" id="reg-name" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-4">
                        <label class="block mb-2">Email</label>
                        <input type="email" id="reg-email" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-4">
                        <label class="block mb-2">Password</label>
                        <input type="password" id="reg-password" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-6">
                        <label class="block mb-2">I am a...</label>
                        <select id="reg-role" required class="w-full px-4 py-3 rounded-lg">
                            <option value="">Select Role</option>
                            <option value="patient">Patient</option>
                            <option value="doctor">Doctor</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-neon w-full py-3 rounded-lg">
                        <span id="register-btn-text">Register</span>
                        <span id="register-loading" class="loading hidden"></span>
                    </button>
                </form>
                <p class="mt-4 text-center">
                    Already have an account? 
                    <button onclick="closeModal('register-modal'); showLogin()" class="text-cyan-400 hover:underline">Login</button>
                </p>
            </div>
        </div>
        
        <!-- Dashboard (hidden initially) -->
        <div id="dashboard" class="hidden min-h-screen px-6 pt-24 pb-20">
            <div class="container mx-auto max-w-7xl">
                <div class="glass-card p-8 rounded-xl mb-6">
                    <h2 class="text-4xl font-bold neon-text mb-2">Dashboard</h2>
                    <p id="welcome-message"></p>
                </div>
                
                <!-- Dashboard content will be loaded dynamically -->
                <div id="dashboard-content"></div>
            </div>
        </div>
    </div>
    
    <!-- AI Chat Bot -->
    <div class="chat-container">
        <div class="chat-window" id="chat-window">
            <div class="p-4 border-b border-cyan-400">
                <h3 class="font-bold">HEALNEX AI Assistant</h3>
                <p class="text-sm opacity-75">Powered by Cloudflare AI</p>
            </div>
            <div class="chat-messages" id="chat-messages">
                <div class="message ai">
                    <p>Hello! I'm your HEALNEX AI health assistant. How can I help you today?</p>
                </div>
            </div>
            <div class="p-4 border-t border-cyan-400">
                <form onsubmit="sendChatMessage(event)" class="flex gap-2">
                    <input type="text" id="chat-input" placeholder="Ask me anything..." 
                           class="flex-1 px-4 py-2 rounded-lg">
                    <button type="submit" class="btn-neon px-4 py-2 rounded-lg">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
            </div>
        </div>
        <div class="chat-button" onclick="toggleChat()">
            <i class="fas fa-robot text-2xl text-white"></i>
        </div>
    </div>
    
    <script src="/static/app.js"></script>
</body>
</html>
  `)
})

export default app
