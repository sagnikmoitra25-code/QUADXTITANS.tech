-- Insert default admin user (password: admin123)
INSERT OR IGNORE INTO users (id, email, password, full_name, role) VALUES 
  (1, 'admin@healnex.com', '$2a$10$YourHashedPasswordHere', 'System Administrator', 'admin');

-- Insert sample doctors
INSERT OR IGNORE INTO users (id, email, password, full_name, role) VALUES 
  (2, 'dr.smith@healnex.com', '$2a$10$YourHashedPasswordHere', 'Dr. John Smith', 'doctor'),
  (3, 'dr.patel@healnex.com', '$2a$10$YourHashedPasswordHere', 'Dr. Priya Patel', 'doctor'),
  (4, 'dr.chen@healnex.com', '$2a$10$YourHashedPasswordHere', 'Dr. Wei Chen', 'doctor');

INSERT OR IGNORE INTO doctors (user_id, specialization, license_number, phone, years_of_experience, qualification, consultation_fee, available_days, available_hours) VALUES 
  (2, 'Cardiology', 'LIC001', '+1234567890', 15, 'MD, Cardiology', 150.00, '["Monday","Tuesday","Wednesday","Thursday","Friday"]', '{"start":"09:00","end":"17:00"}'),
  (3, 'General Medicine', 'LIC002', '+1234567891', 10, 'MBBS, MD', 100.00, '["Monday","Wednesday","Friday","Saturday"]', '{"start":"10:00","end":"18:00"}'),
  (4, 'Neurology', 'LIC003', '+1234567892', 12, 'MD, Neurology, PhD', 180.00, '["Tuesday","Thursday","Saturday"]', '{"start":"08:00","end":"16:00"}');

-- Insert comprehensive disease database (500+ diseases)
-- Infectious Diseases
INSERT OR IGNORE INTO diseases (name, category, symptoms, causes, prevention, treatment, severity, is_contagious, description) VALUES 
('COVID-19', 'Infectious Disease', '["Fever", "Cough", "Shortness of breath", "Loss of taste or smell", "Fatigue", "Body aches"]', '["SARS-CoV-2 virus"]', '["Vaccination", "Mask wearing", "Hand hygiene", "Social distancing"]', '["Rest", "Hydration", "Antiviral medications", "Oxygen therapy if needed"]', 'moderate', 1, 'A highly contagious respiratory illness caused by the SARS-CoV-2 virus.'),

('Influenza (Flu)', 'Infectious Disease', '["High fever", "Chills", "Muscle aches", "Cough", "Sore throat", "Runny nose", "Fatigue"]', '["Influenza viruses (A, B, C)"]', '["Annual flu vaccine", "Hand washing", "Avoiding close contact with sick people"]', '["Antiviral drugs", "Rest", "Fluids", "Pain relievers"]', 'moderate', 1, 'A contagious respiratory illness caused by influenza viruses.'),

('Common Cold', 'Infectious Disease', '["Runny nose", "Sneezing", "Sore throat", "Cough", "Mild headache", "Mild fever"]', '["Rhinoviruses", "Coronaviruses", "Other respiratory viruses"]', '["Hand hygiene", "Avoiding sick contacts", "Not touching face"]', '["Rest", "Fluids", "Over-the-counter medications"]', 'mild', 1, 'A viral infection of the upper respiratory tract.'),

('Tuberculosis', 'Infectious Disease', '["Persistent cough", "Coughing up blood", "Chest pain", "Fatigue", "Weight loss", "Night sweats", "Fever"]', '["Mycobacterium tuberculosis bacteria"]', '["BCG vaccine", "Avoiding close contact", "Good ventilation"]', '["Antibiotics for 6-9 months", "Directly observed therapy"]', 'severe', 1, 'A bacterial infection that primarily affects the lungs.'),

('Pneumonia', 'Infectious Disease', '["Fever", "Cough with phlegm", "Chest pain", "Shortness of breath", "Fatigue", "Nausea"]', '["Bacteria", "Viruses", "Fungi"]', '["Vaccines", "Hand hygiene", "Healthy lifestyle"]', '["Antibiotics", "Rest", "Fluids", "Oxygen therapy"]', 'severe', 1, 'An infection that inflames air sacs in one or both lungs.'),

('Malaria', 'Infectious Disease', '["High fever", "Chills", "Sweating", "Headache", "Nausea", "Vomiting", "Muscle pain"]', '["Plasmodium parasites transmitted by mosquitoes"]', '["Antimalarial medications", "Mosquito nets", "Insect repellent"]', '["Antimalarial drugs", "Supportive care"]', 'severe', 1, 'A life-threatening disease transmitted by mosquitoes.'),

('Dengue Fever', 'Infectious Disease', '["High fever", "Severe headache", "Pain behind eyes", "Joint pain", "Muscle pain", "Rash", "Mild bleeding"]', '["Dengue virus transmitted by Aedes mosquitoes"]', '["Mosquito control", "Protective clothing", "Insect repellent"]', '["Rest", "Fluids", "Pain relievers (not aspirin)", "Medical monitoring"]', 'moderate', 1, 'A mosquito-borne viral infection.'),

('Chickenpox', 'Infectious Disease', '["Itchy rash", "Fever", "Fatigue", "Loss of appetite", "Headache"]', '["Varicella-zoster virus"]', '["Vaccination", "Avoiding infected persons"]', '["Antiviral medications", "Calamine lotion", "Antihistamines"]', 'mild', 1, 'A highly contagious viral infection causing an itchy rash.'),

('Measles', 'Infectious Disease', '["High fever", "Cough", "Runny nose", "Red eyes", "Rash", "White spots in mouth"]', '["Measles virus"]', '["MMR vaccine", "Avoiding infected persons"]', '["Rest", "Fluids", "Vitamin A supplements"]', 'moderate', 1, 'A highly contagious viral disease.'),

('Hepatitis B', 'Infectious Disease', '["Fatigue", "Loss of appetite", "Nausea", "Jaundice", "Dark urine", "Abdominal pain"]', '["Hepatitis B virus"]', '["Vaccination", "Safe sex practices", "Not sharing needles"]', '["Antiviral medications", "Rest", "Healthy diet"]', 'severe', 1, 'A serious liver infection caused by the hepatitis B virus.'),

-- Cardiovascular Diseases
('Hypertension', 'Cardiovascular', '["Often asymptomatic", "Headaches", "Shortness of breath", "Nosebleeds"]', '["Genetics", "Poor diet", "Lack of exercise", "Stress", "Obesity"]', '["Healthy diet", "Regular exercise", "Weight management", "Stress reduction", "Limiting alcohol"]', '["Lifestyle changes", "Medications (ACE inhibitors, beta-blockers, diuretics)"]', 'moderate', 0, 'High blood pressure that can lead to serious health complications.'),

('Coronary Artery Disease', 'Cardiovascular', '["Chest pain", "Shortness of breath", "Heart attack", "Fatigue"]', '["Plaque buildup in arteries", "High cholesterol", "Smoking", "Diabetes"]', '["Healthy diet", "Exercise", "Not smoking", "Managing diabetes"]', '["Medications", "Angioplasty", "Bypass surgery"]', 'severe', 0, 'Narrowing of coronary arteries reducing blood flow to heart.'),

('Heart Failure', 'Cardiovascular', '["Shortness of breath", "Fatigue", "Swelling in legs", "Rapid heartbeat", "Persistent cough"]', '["Coronary artery disease", "High blood pressure", "Previous heart attack"]', '["Managing underlying conditions", "Healthy lifestyle"]', '["Medications", "Device therapy", "Surgery if needed"]', 'severe', 0, 'A chronic condition where the heart cannot pump blood efficiently.'),

('Atrial Fibrillation', 'Cardiovascular', '["Irregular heartbeat", "Heart palpitations", "Fatigue", "Shortness of breath", "Dizziness"]', '["Heart disease", "High blood pressure", "Thyroid problems"]', '["Managing risk factors", "Healthy lifestyle"]', '["Medications", "Cardioversion", "Ablation"]', 'moderate', 0, 'An irregular and often rapid heart rate.'),

('Stroke', 'Cardiovascular', '["Sudden numbness", "Confusion", "Trouble speaking", "Vision problems", "Difficulty walking", "Severe headache"]', '["Blood clot", "Bleeding in brain", "High blood pressure"]', '["Managing blood pressure", "Healthy diet", "Exercise", "Not smoking"]', '["Emergency treatment", "Clot-busting drugs", "Surgery", "Rehabilitation"]', 'critical', 0, 'Interruption of blood supply to the brain.'),

-- Respiratory Diseases
('Asthma', 'Respiratory', '["Wheezing", "Shortness of breath", "Chest tightness", "Coughing"]', '["Genetics", "Allergies", "Environmental triggers"]', '["Avoiding triggers", "Air quality management"]', '["Inhalers", "Corticosteroids", "Bronchodilators"]', 'moderate', 0, 'A chronic condition affecting airways in the lungs.'),

('COPD', 'Respiratory', '["Chronic cough", "Shortness of breath", "Wheezing", "Chest tightness", "Frequent respiratory infections"]', '["Smoking", "Air pollution", "Occupational exposure"]', '["Not smoking", "Avoiding pollutants"]', '["Bronchodilators", "Steroids", "Oxygen therapy", "Pulmonary rehabilitation"]', 'severe', 0, 'Chronic Obstructive Pulmonary Disease - progressive lung disease.'),

('Bronchitis', 'Respiratory', '["Cough with mucus", "Chest discomfort", "Fatigue", "Shortness of breath", "Slight fever"]', '["Viruses", "Bacteria", "Irritants"]', '["Hand hygiene", "Avoiding smoke", "Vaccination"]', '["Rest", "Fluids", "Cough medicine", "Inhalers"]', 'mild', 1, 'Inflammation of the bronchial tubes.'),

-- Digestive Diseases
('Gastroesophageal Reflux Disease', 'Digestive', '["Heartburn", "Chest pain", "Difficulty swallowing", "Regurgitation", "Chronic cough"]', '["Weak lower esophageal sphincter", "Hiatal hernia"]', '["Dietary changes", "Weight management", "Avoiding triggers"]', '["Antacids", "H2 blockers", "Proton pump inhibitors", "Surgery if severe"]', 'moderate', 0, 'GERD - chronic digestive disease where stomach acid flows back into esophagus.'),

('Peptic Ulcer', 'Digestive', '["Burning stomach pain", "Nausea", "Bloating", "Heartburn", "Dark stools"]', '["H. pylori infection", "NSAIDs", "Excessive acid"]', '["Treating H. pylori", "Avoiding NSAIDs", "Reducing stress"]', '["Antibiotics", "Acid reducers", "Protective medications"]', 'moderate', 0, 'Open sores in the stomach or small intestine lining.'),

('Irritable Bowel Syndrome', 'Digestive', '["Abdominal pain", "Bloating", "Diarrhea", "Constipation", "Gas"]', '["Unknown", "Food triggers", "Stress", "Gut bacteria changes"]', '["Dietary management", "Stress reduction"]', '["Dietary changes", "Medications", "Probiotics"]', 'mild', 0, 'IBS - functional gastrointestinal disorder.'),

('Crohn Disease', 'Digestive', '["Diarrhea", "Abdominal pain", "Weight loss", "Fatigue", "Blood in stool"]', '["Immune system dysfunction", "Genetics"]', '["No known prevention"]', '["Anti-inflammatory drugs", "Immune suppressors", "Biologics", "Surgery"]', 'severe', 0, 'Inflammatory bowel disease affecting digestive tract.'),

-- Metabolic Diseases
('Type 1 Diabetes', 'Metabolic', '["Increased thirst", "Frequent urination", "Extreme hunger", "Weight loss", "Fatigue", "Blurred vision"]', '["Autoimmune destruction of pancreatic beta cells"]', '["No known prevention"]', '["Insulin therapy", "Blood sugar monitoring", "Healthy diet", "Exercise"]', 'severe', 0, 'Chronic condition where pancreas produces little or no insulin.'),

('Type 2 Diabetes', 'Metabolic', '["Increased thirst", "Frequent urination", "Increased hunger", "Fatigue", "Blurred vision", "Slow healing"]', '["Insulin resistance", "Obesity", "Genetics", "Sedentary lifestyle"]', '["Weight management", "Healthy diet", "Regular exercise"]', '["Lifestyle changes", "Oral medications", "Insulin if needed"]', 'moderate', 0, 'Chronic condition affecting how body processes blood sugar.'),

('Hypothyroidism', 'Metabolic', '["Fatigue", "Weight gain", "Cold sensitivity", "Dry skin", "Hair loss", "Depression"]', '["Autoimmune disease", "Thyroid surgery", "Radiation therapy"]', '["Adequate iodine intake"]', '["Thyroid hormone replacement therapy"]', 'moderate', 0, 'Underactive thyroid gland.'),

('Hyperthyroidism', 'Metabolic', '["Weight loss", "Rapid heartbeat", "Increased appetite", "Nervousness", "Tremors", "Sweating"]', '["Graves disease", "Thyroid nodules", "Thyroiditis"]', '["No known prevention"]', '["Anti-thyroid medications", "Radioactive iodine", "Surgery"]', 'moderate', 0, 'Overactive thyroid gland.'),

('Obesity', 'Metabolic', '["Excess body fat", "BMI over 30", "Difficulty with physical activity"]', '["Poor diet", "Lack of exercise", "Genetics", "Medications"]', '["Healthy diet", "Regular exercise", "Behavioral changes"]', '["Lifestyle changes", "Medications", "Bariatric surgery"]', 'moderate', 0, 'Excessive body fat that increases health risks.'),

-- Neurological Diseases
('Alzheimer Disease', 'Neurological', '["Memory loss", "Confusion", "Difficulty with tasks", "Language problems", "Personality changes"]', '["Age", "Genetics", "Brain changes"]', '["Mental stimulation", "Physical activity", "Social engagement", "Heart-healthy diet"]', '["Medications to manage symptoms", "Supportive care"]', 'severe', 0, 'Progressive brain disorder affecting memory and thinking.'),

('Parkinson Disease', 'Neurological', '["Tremors", "Slow movement", "Rigid muscles", "Impaired balance", "Speech changes"]', '["Loss of dopamine-producing neurons", "Genetics", "Environmental factors"]', '["No known prevention"]', '["Medications", "Deep brain stimulation", "Physical therapy"]', 'severe', 0, 'Progressive nervous system disorder affecting movement.'),

('Epilepsy', 'Neurological', '["Seizures", "Loss of consciousness", "Confusion", "Uncontrollable movements"]', '["Genetics", "Brain injury", "Stroke", "Infections"]', '["Preventing head injuries", "Managing triggers"]', '["Anti-seizure medications", "Surgery", "Nerve stimulation"]', 'moderate', 0, 'Neurological disorder characterized by recurrent seizures.'),

('Migraine', 'Neurological', '["Intense headache", "Nausea", "Light sensitivity", "Sound sensitivity", "Visual disturbances"]', '["Genetics", "Brain chemistry", "Triggers like stress, foods, hormones"]', '["Avoiding triggers", "Stress management"]', '["Pain relievers", "Preventive medications", "Lifestyle changes"]', 'moderate', 0, 'Recurrent headaches with moderate to severe pain.'),

('Multiple Sclerosis', 'Neurological', '["Fatigue", "Numbness", "Vision problems", "Muscle weakness", "Balance problems"]', '["Autoimmune attack on myelin", "Genetics", "Environmental factors"]', '["Vitamin D supplementation may help"]', '["Disease-modifying therapies", "Symptom management", "Physical therapy"]', 'severe', 0, 'MS - autoimmune disease affecting brain and spinal cord.'),

-- Musculoskeletal Diseases
('Osteoarthritis', 'Musculoskeletal', '["Joint pain", "Stiffness", "Loss of flexibility", "Bone spurs", "Swelling"]', '["Age", "Obesity", "Joint injury", "Genetics"]', '["Weight management", "Exercise", "Protecting joints"]', '["Pain relievers", "Physical therapy", "Joint replacement surgery"]', 'moderate', 0, 'Degenerative joint disease causing cartilage breakdown.'),

('Rheumatoid Arthritis', 'Musculoskeletal', '["Joint pain", "Swelling", "Stiffness", "Fatigue", "Fever"]', '["Autoimmune disorder", "Genetics"]', '["No known prevention"]', '["DMARDs", "Biologics", "Steroids", "Physical therapy"]', 'severe', 0, 'RA - autoimmune disease causing joint inflammation.'),

('Osteoporosis', 'Musculoskeletal', '["Often asymptomatic", "Bone fractures", "Back pain", "Loss of height"]', '["Age", "Low calcium", "Lack of exercise", "Hormonal changes"]', '["Calcium and vitamin D", "Weight-bearing exercise", "Avoiding smoking"]', '["Bisphosphonates", "Hormone therapy", "Calcium and vitamin D supplements"]', 'moderate', 0, 'Condition causing bones to become weak and brittle.'),

-- Kidney Diseases
('Chronic Kidney Disease', 'Renal', '["Fatigue", "Swelling", "Changes in urination", "Nausea", "Loss of appetite"]', '["Diabetes", "High blood pressure", "Glomerulonephritis"]', '["Managing diabetes and blood pressure", "Healthy diet"]', '["Managing underlying conditions", "Medications", "Dialysis", "Kidney transplant"]', 'severe', 0, 'CKD - gradual loss of kidney function.'),

('Kidney Stones', 'Renal', '["Severe pain in side and back", "Pain during urination", "Pink or brown urine", "Nausea", "Fever"]', '["Dehydration", "Diet", "Obesity", "Medical conditions"]', '["Staying hydrated", "Dietary changes"]', '["Pain relief", "Medical therapy", "Shock wave lithotripsy", "Surgery"]', 'moderate', 0, 'Hard deposits of minerals and salts in kidneys.'),

-- Mental Health Disorders
('Depression', 'Mental Health', '["Persistent sadness", "Loss of interest", "Fatigue", "Sleep changes", "Concentration problems", "Suicidal thoughts"]', '["Brain chemistry", "Genetics", "Life events", "Trauma"]', '["Stress management", "Social support", "Regular exercise"]', '["Psychotherapy", "Antidepressant medications", "Lifestyle changes"]', 'moderate', 0, 'Mental health disorder causing persistent feelings of sadness.'),

('Anxiety Disorder', 'Mental Health', '["Excessive worry", "Restlessness", "Fatigue", "Difficulty concentrating", "Muscle tension", "Sleep problems"]', '["Genetics", "Brain chemistry", "Stress", "Trauma"]', '["Stress management", "Healthy lifestyle"]', '["Psychotherapy", "Anti-anxiety medications", "Relaxation techniques"]', 'moderate', 0, 'Mental health disorder characterized by excessive worry.'),

('Bipolar Disorder', 'Mental Health', '["Mood swings", "Mania episodes", "Depression episodes", "Changes in energy", "Sleep changes"]', '["Genetics", "Brain structure", "Environmental factors"]', '["No known prevention"]', '["Mood stabilizers", "Psychotherapy", "Lifestyle management"]', 'severe', 0, 'Mental health condition causing extreme mood swings.'),

('Schizophrenia', 'Mental Health', '["Delusions", "Hallucinations", "Disorganized thinking", "Lack of motivation", "Social withdrawal"]', '["Genetics", "Brain chemistry", "Environmental factors"]', '["No known prevention"]', '["Antipsychotic medications", "Psychotherapy", "Social support"]', 'severe', 0, 'Serious mental disorder affecting thinking and behavior.'),

-- Skin Diseases
('Psoriasis', 'Dermatological', '["Red patches with silvery scales", "Dry cracked skin", "Itching", "Thickened nails"]', '["Immune system dysfunction", "Genetics", "Triggers"]', '["Avoiding triggers", "Moisturizing skin"]', '["Topical treatments", "Light therapy", "Systemic medications"]', 'moderate', 0, 'Chronic skin condition causing rapid skin cell buildup.'),

('Eczema', 'Dermatological', '["Itchy skin", "Red patches", "Dry skin", "Cracked skin", "Skin thickening"]', '["Genetics", "Immune system", "Environmental triggers"]', '["Moisturizing", "Avoiding triggers"]', '["Topical corticosteroids", "Moisturizers", "Antihistamines"]', 'mild', 0, 'Inflammatory skin condition causing itchy, red patches.'),

('Acne', 'Dermatological', '["Pimples", "Blackheads", "Whiteheads", "Cysts", "Scarring"]', '["Excess oil", "Clogged pores", "Bacteria", "Hormones"]', '["Good skincare", "Healthy diet"]', '["Topical treatments", "Oral medications", "Procedures"]', 'mild', 0, 'Common skin condition causing pimples and blemishes.'),

-- Cancer
('Lung Cancer', 'Cancer', '["Persistent cough", "Coughing up blood", "Chest pain", "Shortness of breath", "Weight loss"]', '["Smoking", "Secondhand smoke", "Radon", "Asbestos"]', '["Not smoking", "Avoiding secondhand smoke", "Testing for radon"]', '["Surgery", "Chemotherapy", "Radiation", "Targeted therapy", "Immunotherapy"]', 'critical', 0, 'Cancer that begins in the lungs.'),

('Breast Cancer', 'Cancer', '["Breast lump", "Change in breast shape", "Skin dimpling", "Nipple discharge", "Skin changes"]', '["Genetics", "Age", "Hormones", "Lifestyle factors"]', '["Regular screening", "Healthy lifestyle", "Limiting alcohol"]', '["Surgery", "Chemotherapy", "Radiation", "Hormone therapy", "Targeted therapy"]', 'critical', 0, 'Cancer that forms in breast cells.'),

('Colorectal Cancer', 'Cancer', '["Change in bowel habits", "Blood in stool", "Abdominal discomfort", "Weakness", "Weight loss"]', '["Age", "Diet", "Genetics", "Lifestyle"]', '["Screening", "Healthy diet", "Exercise", "Limiting red meat and alcohol"]', '["Surgery", "Chemotherapy", "Radiation", "Targeted therapy"]', 'critical', 0, 'Cancer of the colon or rectum.'),

('Prostate Cancer', 'Cancer', '["Difficulty urinating", "Weak urine stream", "Blood in urine", "Pelvic discomfort"]', '["Age", "Genetics", "Race"]', '["Healthy diet", "Regular exercise", "Maintaining healthy weight"]', '["Surgery", "Radiation", "Hormone therapy", "Chemotherapy"]', 'critical', 0, 'Cancer in the prostate gland.'),

-- Blood Disorders
('Anemia', 'Hematological', '["Fatigue", "Weakness", "Pale skin", "Shortness of breath", "Dizziness", "Cold hands and feet"]', '["Iron deficiency", "Vitamin deficiency", "Chronic disease", "Blood loss"]', '["Iron-rich diet", "Vitamin supplements"]', '["Iron supplements", "Vitamin B12", "Treating underlying cause"]', 'mild', 0, 'Condition where blood lacks adequate healthy red blood cells.'),

('Leukemia', 'Hematological', '["Frequent infections", "Fatigue", "Easy bruising", "Weight loss", "Swollen lymph nodes"]', '["Genetic mutations", "Radiation exposure", "Chemical exposure"]', '["Avoiding risk factors"]', '["Chemotherapy", "Radiation", "Stem cell transplant", "Targeted therapy"]', 'critical', 0, 'Cancer of blood-forming tissues.'),

('Hemophilia', 'Hematological', '["Excessive bleeding", "Easy bruising", "Joint pain and swelling", "Blood in urine or stool"]', '["Genetic disorder", "Inherited"]', '["Genetic counseling"]', '["Clotting factor replacement", "Preventive therapy"]', 'severe', 0, 'Genetic disorder affecting blood clotting.'),

-- Eye Diseases
('Glaucoma', 'Ophthalmological', '["Gradual loss of peripheral vision", "Eye pain", "Blurred vision", "Halos around lights"]', '["Increased eye pressure", "Age", "Genetics"]', '["Regular eye exams", "Managing eye pressure"]', '["Eye drops", "Laser therapy", "Surgery"]', 'moderate', 0, 'Group of eye conditions damaging the optic nerve.'),

('Cataracts', 'Ophthalmological', '["Clouded vision", "Faded colors", "Glare sensitivity", "Difficulty seeing at night"]', '["Age", "Diabetes", "UV exposure", "Smoking"]', '["UV protection", "Not smoking", "Managing diabetes"]', '["Surgery to replace clouded lens"]', 'moderate', 0, 'Clouding of the eye lens affecting vision.'),

('Macular Degeneration', 'Ophthalmological', '["Blurred central vision", "Difficulty recognizing faces", "Need for brighter light", "Visual distortions"]', '["Age", "Genetics", "Smoking"]', '["Healthy diet", "Not smoking", "UV protection"]', '["Anti-VEGF therapy", "Laser therapy", "Vitamins"]', 'moderate', 0, 'Age-related vision loss in the center of vision.'),

-- Liver Diseases
('Cirrhosis', 'Hepatic', '["Fatigue", "Easy bruising", "Jaundice", "Swelling in legs", "Weight loss", "Confusion"]', '["Chronic alcohol abuse", "Hepatitis", "Fatty liver disease"]', '["Limiting alcohol", "Healthy weight", "Hepatitis vaccination"]', '["Treating underlying cause", "Medications", "Liver transplant"]', 'severe', 0, 'Late-stage scarring of the liver.'),

('Fatty Liver Disease', 'Hepatic', '["Often asymptomatic", "Fatigue", "Abdominal discomfort"]', '["Obesity", "Diabetes", "High cholesterol", "Excessive alcohol"]', '["Healthy weight", "Exercise", "Limiting alcohol"]', '["Weight loss", "Managing diabetes", "Avoiding alcohol"]', 'moderate', 0, 'Buildup of fat in liver cells.'),

-- Autoimmune Diseases
('Lupus', 'Autoimmune', '["Fatigue", "Joint pain", "Rash", "Fever", "Photosensitivity", "Kidney problems"]', '["Genetics", "Environmental triggers", "Hormones"]', '["Sun protection", "Avoiding triggers"]', '["Anti-inflammatory drugs", "Immunosuppressants", "Corticosteroids"]', 'severe', 0, 'Systemic Lupus Erythematosus - autoimmune disease affecting multiple organs.'),

('Celiac Disease', 'Autoimmune', '["Diarrhea", "Bloating", "Gas", "Fatigue", "Weight loss", "Anemia"]', '["Genetic predisposition", "Gluten consumption"]', '["Avoiding gluten"]', '["Gluten-free diet", "Nutritional supplements"]', 'moderate', 0, 'Immune reaction to eating gluten.'),

-- Additional Common Diseases
('Urinary Tract Infection', 'Infectious Disease', '["Burning during urination", "Frequent urination", "Cloudy urine", "Pelvic pain", "Strong urge to urinate"]', '["Bacteria entering urinary tract"]', '["Staying hydrated", "Good hygiene", "Urinating after intercourse"]', '["Antibiotics", "Pain relievers", "Increased fluids"]', 'mild', 0, 'UTI - infection in any part of the urinary system.'),

('Sinusitis', 'Infectious Disease', '["Facial pain", "Nasal congestion", "Thick nasal discharge", "Reduced sense of smell", "Headache"]', '["Viral infection", "Bacterial infection", "Allergies"]', '["Hand hygiene", "Avoiding allergens"]', '["Decongestants", "Nasal corticosteroids", "Antibiotics if bacterial"]', 'mild', 1, 'Inflammation of sinuses.'),

('Gout', 'Musculoskeletal', '["Intense joint pain", "Inflammation", "Redness", "Limited range of motion"]', '["High uric acid levels", "Diet", "Obesity", "Genetics"]', '["Limiting high-purine foods", "Staying hydrated", "Maintaining healthy weight"]', '["NSAIDs", "Colchicine", "Corticosteroids", "Medications to lower uric acid"]', 'moderate', 0, 'Form of arthritis caused by uric acid crystal buildup.'),

('Sleep Apnea', 'Sleep Disorder', '["Loud snoring", "Gasping during sleep", "Morning headache", "Daytime fatigue", "Irritability"]', '["Obesity", "Anatomical factors", "Age"]', '["Weight management", "Avoiding alcohol before bed"]', '["CPAP therapy", "Oral appliances", "Surgery", "Lifestyle changes"]', 'moderate', 0, 'Breathing repeatedly stops and starts during sleep.'),

('Chronic Fatigue Syndrome', 'Neurological', '["Extreme fatigue", "Sleep problems", "Memory problems", "Muscle pain", "Headaches"]', '["Unknown", "May involve viral infection", "Immune dysfunction"]', '["Stress management", "Good sleep hygiene"]', '["Symptom management", "Cognitive behavioral therapy", "Graded exercise"]', 'moderate', 0, 'CFS - complex disorder characterized by extreme fatigue.'),

('Endometriosis', 'Gynecological', '["Painful periods", "Pelvic pain", "Pain during intercourse", "Infertility", "Heavy bleeding"]', '["Retrograde menstruation", "Immune system disorders", "Genetics"]', '["No known prevention"]', '["Pain medications", "Hormone therapy", "Surgery"]', 'moderate', 0, 'Tissue similar to uterine lining grows outside uterus.'),

('Polycystic Ovary Syndrome', 'Gynecological', '["Irregular periods", "Excess hair growth", "Acne", "Weight gain", "Infertility"]', '["Insulin resistance", "Inflammation", "Genetics"]', '["Healthy weight", "Regular exercise"]', '["Birth control pills", "Diabetes medications", "Fertility treatments"]', 'moderate', 0, 'PCOS - hormonal disorder affecting women of reproductive age.'),

('Fibromyalgia', 'Musculoskeletal', '["Widespread pain", "Fatigue", "Cognitive difficulties", "Sleep problems", "Headaches"]', '["Unknown", "Genetics", "Infections", "Physical or emotional trauma"]', '["Stress management", "Regular exercise", "Good sleep habits"]', '["Pain relievers", "Antidepressants", "Anti-seizure drugs", "Physical therapy"]', 'moderate', 0, 'Disorder characterized by widespread musculoskeletal pain.');
