// Global state
let currentUser = null;
let chatOpen = false;

// Initialize Three.js background
function initBackground() {
    const canvas = document.getElementById('bg-canvas');
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.position.z = 5;
    
    // Create particles
    const particlesGeometry = new THREE.BufferGeometry();
    const particlesCount = 5000;
    const posArray = new Float32Array(particlesCount * 3);
    
    for(let i = 0; i < particlesCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 10;
    }
    
    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    
    const particlesMaterial = new THREE.PointsMaterial({
        size: 0.005,
        color: 0x00ffff,
        transparent: true,
        opacity: 0.8
    });
    
    const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particlesMesh);
    
    // Animation
    function animate() {
        requestAnimationFrame(animate);
        particlesMesh.rotation.x += 0.0005;
        particlesMesh.rotation.y += 0.001;
        renderer.render(scene, camera);
    }
    
    animate();
    
    // Handle resize
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    initBackground();
    checkAuth();
});

// Check if user is logged in
function checkAuth() {
    const user = localStorage.getItem('healnex_user');
    if (user) {
        currentUser = JSON.parse(user);
        showDashboard();
    }
}

// Navigation functions
function showHome() {
    document.getElementById('home-page').classList.remove('hidden');
    document.getElementById('dashboard').classList.add('hidden');
    document.getElementById('nav-menu').classList.remove('hidden');
    document.getElementById('user-menu').classList.add('hidden');
}

function showFeatures() {
    document.getElementById('features-section').scrollIntoView({ behavior: 'smooth' });
}

function showLogin() {
    document.getElementById('login-modal').classList.add('active');
}

function showRegister() {
    document.getElementById('register-modal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Authentication handlers
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    setLoading('login', true);
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.user;
            localStorage.setItem('healnex_user', JSON.stringify(data.user));
            closeModal('login-modal');
            showDashboard();
            showNotification('Login successful!', 'success');
        } else {
            showNotification(data.error || 'Login failed', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    }
    
    setLoading('login', false);
}

async function handleRegister(event) {
    event.preventDefault();
    
    const full_name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;
    const role = document.getElementById('reg-role').value;
    
    setLoading('register', true);
    
    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, full_name, role })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Registration successful! Please login.', 'success');
            closeModal('register-modal');
            
            // If doctor, show additional profile form
            if (data.requiresProfile) {
                currentUser = { id: data.userId, email, full_name, role };
                localStorage.setItem('healnex_user', JSON.stringify(currentUser));
                showDashboard();
            } else {
                showLogin();
            }
        } else {
            showNotification(data.error || 'Registration failed', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    }
    
    setLoading('register', false);
}

function logout() {
    currentUser = null;
    localStorage.removeItem('healnex_user');
    showHome();
    showNotification('Logged out successfully', 'success');
}

// Dashboard functions
async function showDashboard() {
    document.getElementById('home-page').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    document.getElementById('nav-menu').classList.add('hidden');
    document.getElementById('user-menu').classList.remove('hidden');
    
    document.getElementById('user-name').textContent = currentUser.full_name;
    document.getElementById('welcome-message').textContent = `Welcome back, ${currentUser.full_name}!`;
    
    // Load appropriate dashboard based on role
    if (currentUser.role === 'patient') {
        loadPatientDashboard();
    } else if (currentUser.role === 'doctor') {
        loadDoctorDashboard();
    } else if (currentUser.role === 'admin') {
        loadAdminDashboard();
    }
}

// Patient Dashboard
async function loadPatientDashboard() {
    const content = document.getElementById('dashboard-content');
    
    content.innerHTML = `
        <div class="dashboard-nav">
            <button class="nav-btn active" onclick="showPatientSection('profile')">Profile</button>
            <button class="nav-btn" onclick="showPatientSection('appointments')">Appointments</button>
            <button class="nav-btn" onclick="showPatientSection('history')">Medical History</button>
            <button class="nav-btn" onclick="showPatientSection('prescriptions')">Prescriptions</button>
            <button class="nav-btn" onclick="showPatientSection('diseases')">Disease Database</button>
        </div>
        
        <div id="patient-profile" class="glass-card p-6 rounded-xl">
            <h3 class="text-2xl font-bold mb-4 neon-text">My Profile</h3>
            <form id="profile-form" onsubmit="updatePatientProfile(event)">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block mb-2">Gender</label>
                        <select id="gender" class="w-full px-4 py-3 rounded-lg">
                            <option value="">Select</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div>
                        <label class="block mb-2">Blood Group</label>
                        <select id="blood_group" class="w-full px-4 py-3 rounded-lg">
                            <option value="">Select</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                    <div>
                        <label class="block mb-2">Date of Birth</label>
                        <input type="date" id="date_of_birth" class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div>
                        <label class="block mb-2">Phone</label>
                        <input type="tel" id="phone" class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block mb-2">Address</label>
                        <textarea id="address" rows="2" class="w-full px-4 py-3 rounded-lg"></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block mb-2">Emergency Contact</label>
                        <input type="text" id="emergency_contact" class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block mb-2">Allergies</label>
                        <textarea id="allergies" rows="2" placeholder="List any allergies..." class="w-full px-4 py-3 rounded-lg"></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block mb-2">Chronic Conditions</label>
                        <textarea id="chronic_conditions" rows="2" placeholder="List any chronic conditions..." class="w-full px-4 py-3 rounded-lg"></textarea>
                    </div>
                </div>
                <button type="submit" class="btn-neon px-6 py-3 rounded-lg mt-4">Update Profile</button>
            </form>
        </div>
        
        <div id="patient-appointments" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">My Appointments</h3>
            <button onclick="showBookAppointment()" class="btn-neon px-6 py-3 rounded-lg mb-4">
                <i class="fas fa-plus mr-2"></i>Book New Appointment
            </button>
            <div id="appointments-list"></div>
        </div>
        
        <div id="patient-history" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">Medical History</h3>
            <button onclick="showAddHistory()" class="btn-neon px-6 py-3 rounded-lg mb-4">
                <i class="fas fa-plus mr-2"></i>Add Entry
            </button>
            <div id="history-list"></div>
        </div>
        
        <div id="patient-prescriptions" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">My Prescriptions</h3>
            <div id="prescriptions-list"></div>
        </div>
        
        <div id="patient-diseases" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">Disease Database</h3>
            <div class="mb-4">
                <input type="text" id="disease-search" placeholder="Search diseases..." 
                       class="w-full px-4 py-3 rounded-lg" onkeyup="searchDiseases()">
            </div>
            <div id="diseases-list"></div>
        </div>
    `;
    
    loadPatientProfile();
}

async function loadPatientProfile() {
    try {
        const response = await fetch(`/api/patients/${currentUser.id}`);
        if (response.ok) {
            const patient = await response.json();
            document.getElementById('gender').value = patient.gender || '';
            document.getElementById('blood_group').value = patient.blood_group || '';
            document.getElementById('date_of_birth').value = patient.date_of_birth || '';
            document.getElementById('phone').value = patient.phone || '';
            document.getElementById('address').value = patient.address || '';
            document.getElementById('emergency_contact').value = patient.emergency_contact || '';
            document.getElementById('allergies').value = patient.allergies || '';
            document.getElementById('chronic_conditions').value = patient.chronic_conditions || '';
        }
    } catch (error) {
        console.error('Failed to load profile:', error);
    }
}

async function updatePatientProfile(event) {
    event.preventDefault();
    
    const data = {
        gender: document.getElementById('gender').value,
        blood_group: document.getElementById('blood_group').value,
        date_of_birth: document.getElementById('date_of_birth').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value,
        emergency_contact: document.getElementById('emergency_contact').value,
        allergies: document.getElementById('allergies').value,
        chronic_conditions: document.getElementById('chronic_conditions').value
    };
    
    try {
        const response = await fetch(`/api/patients/${currentUser.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Profile updated successfully!', 'success');
        } else {
            showNotification('Failed to update profile', 'error');
        }
    } catch (error) {
        showNotification('Network error', 'error');
    }
}

function showPatientSection(section) {
    // Hide all sections
    document.getElementById('patient-profile').classList.add('hidden');
    document.getElementById('patient-appointments').classList.add('hidden');
    document.getElementById('patient-history').classList.add('hidden');
    document.getElementById('patient-prescriptions').classList.add('hidden');
    document.getElementById('patient-diseases').classList.add('hidden');
    
    // Remove active class from all buttons
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    
    // Show selected section
    document.getElementById(`patient-${section}`).classList.remove('hidden');
    event.target.classList.add('active');
    
    // Load data for the section
    if (section === 'appointments') loadAppointments();
    else if (section === 'history') loadMedicalHistory();
    else if (section === 'prescriptions') loadPrescriptions();
    else if (section === 'diseases') loadDiseases();
}

async function loadAppointments() {
    try {
        const response = await fetch(`/api/appointments/patient/${currentUser.id}`);
        const appointments = await response.json();
        
        const list = document.getElementById('appointments-list');
        if (appointments.length === 0) {
            list.innerHTML = '<p class="text-gray-400">No appointments scheduled yet.</p>';
            return;
        }
        
        list.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Doctor</th>
                        <th>Specialization</th>
                        <th>Status</th>
                        <th>Reason</th>
                    </tr>
                </thead>
                <tbody>
                    ${appointments.map(apt => `
                        <tr>
                            <td>${apt.appointment_date}</td>
                            <td>${apt.appointment_time}</td>
                            <td>${apt.doctor_name}</td>
                            <td>${apt.specialization}</td>
                            <td><span class="px-2 py-1 rounded" style="background: ${getStatusColor(apt.status)}">${apt.status}</span></td>
                            <td>${apt.reason || '-'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Failed to load appointments:', error);
    }
}

async function showBookAppointment() {
    // Load doctors first
    const response = await fetch('/api/doctors');
    const doctors = await response.json();
    
    const content = document.getElementById('appointments-list');
    content.innerHTML = `
        <div class="glass-card p-6 rounded-xl mb-4">
            <h4 class="text-xl font-bold mb-4">Book New Appointment</h4>
            <form onsubmit="bookAppointment(event)">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block mb-2">Select Doctor</label>
                        <select id="apt-doctor" required class="w-full px-4 py-3 rounded-lg">
                            <option value="">Choose a doctor</option>
                            ${doctors.map(doc => `
                                <option value="${doc.id}">${doc.full_name} - ${doc.specialization}</option>
                            `).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block mb-2">Date</label>
                        <input type="date" id="apt-date" required class="w-full px-4 py-3 rounded-lg" min="${new Date().toISOString().split('T')[0]}">
                    </div>
                    <div>
                        <label class="block mb-2">Time</label>
                        <input type="time" id="apt-time" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div>
                        <label class="block mb-2">Reason for Visit</label>
                        <input type="text" id="apt-reason" class="w-full px-4 py-3 rounded-lg">
                    </div>
                </div>
                <div class="flex gap-4 mt-4">
                    <button type="submit" class="btn-neon px-6 py-3 rounded-lg">Book Appointment</button>
                    <button type="button" onclick="loadAppointments()" class="px-6 py-3 rounded-lg border border-gray-400">Cancel</button>
                </div>
            </form>
        </div>
    `;
}

async function bookAppointment(event) {
    event.preventDefault();
    
    const data = {
        patientUserId: currentUser.id,
        doctorId: document.getElementById('apt-doctor').value,
        appointment_date: document.getElementById('apt-date').value,
        appointment_time: document.getElementById('apt-time').value,
        reason: document.getElementById('apt-reason').value
    };
    
    try {
        const response = await fetch('/api/appointments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Appointment booked successfully!', 'success');
            loadAppointments();
        } else {
            showNotification('Failed to book appointment', 'error');
        }
    } catch (error) {
        showNotification('Network error', 'error');
    }
}

async function loadMedicalHistory() {
    try {
        const response = await fetch(`/api/patients/${currentUser.id}/history`);
        const history = await response.json();
        
        const list = document.getElementById('history-list');
        if (history.length === 0) {
            list.innerHTML = '<p class="text-gray-400">No medical history recorded yet.</p>';
            return;
        }
        
        list.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Disease</th>
                        <th>Status</th>
                        <th>Diagnosed By</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    ${history.map(item => `
                        <tr>
                            <td>${item.diagnosis_date}</td>
                            <td>${item.disease_name || 'N/A'}</td>
                            <td><span class="px-2 py-1 rounded" style="background: ${getStatusColor(item.status)}">${item.status}</span></td>
                            <td>${item.doctor_name || 'Self-reported'}</td>
                            <td>${item.notes || '-'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Failed to load medical history:', error);
    }
}

async function showAddHistory() {
    const content = document.getElementById('history-list');
    content.innerHTML = `
        <div class="glass-card p-6 rounded-xl mb-4">
            <h4 class="text-xl font-bold mb-4">Add Medical History Entry</h4>
            <form onsubmit="addMedicalHistory(event)">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block mb-2">Disease Name</label>
                        <input type="text" id="hist-disease" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div>
                        <label class="block mb-2">Diagnosis Date</label>
                        <input type="date" id="hist-date" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div>
                        <label class="block mb-2">Status</label>
                        <select id="hist-status" required class="w-full px-4 py-3 rounded-lg">
                            <option value="active">Active</option>
                            <option value="recovered">Recovered</option>
                            <option value="chronic">Chronic</option>
                            <option value="monitoring">Monitoring</option>
                        </select>
                    </div>
                    <div>
                        <label class="block mb-2">Notes</label>
                        <textarea id="hist-notes" class="w-full px-4 py-3 rounded-lg" rows="2"></textarea>
                    </div>
                </div>
                <div class="flex gap-4 mt-4">
                    <button type="submit" class="btn-neon px-6 py-3 rounded-lg">Add Entry</button>
                    <button type="button" onclick="loadMedicalHistory()" class="px-6 py-3 rounded-lg border border-gray-400">Cancel</button>
                </div>
            </form>
        </div>
    `;
}

async function addMedicalHistory(event) {
    event.preventDefault();
    
    const data = {
        disease_name: document.getElementById('hist-disease').value,
        diagnosis_date: document.getElementById('hist-date').value,
        status: document.getElementById('hist-status').value,
        notes: document.getElementById('hist-notes').value
    };
    
    try {
        const response = await fetch(`/api/patients/${currentUser.id}/history`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Medical history added successfully!', 'success');
            loadMedicalHistory();
        } else {
            showNotification('Failed to add medical history', 'error');
        }
    } catch (error) {
        showNotification('Network error', 'error');
    }
}

async function loadPrescriptions() {
    try {
        const response = await fetch(`/api/prescriptions/patient/${currentUser.id}`);
        const prescriptions = await response.json();
        
        const list = document.getElementById('prescriptions-list');
        if (prescriptions.length === 0) {
            list.innerHTML = '<p class="text-gray-400">No prescriptions yet.</p>';
            return;
        }
        
        list.innerHTML = prescriptions.map(rx => {
            const medications = JSON.parse(rx.medications || '[]');
            return `
                <div class="glass-card p-6 rounded-xl mb-4">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h4 class="text-xl font-bold">${rx.diagnosis}</h4>
                            <p class="text-gray-400">Prescribed by: ${rx.doctor_name} (${rx.specialization})</p>
                            <p class="text-sm text-gray-500">Date: ${rx.prescription_date}</p>
                        </div>
                        <span class="px-3 py-1 rounded bg-cyan-500 text-black">Valid until: ${rx.valid_until}</span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-bold mb-2">Medications:</h5>
                        <ul class="list-disc list-inside">
                            ${medications.map(med => `
                                <li>${med.name} - ${med.dosage} - ${med.frequency} for ${med.duration}</li>
                            `).join('')}
                        </ul>
                    </div>
                    ${rx.instructions ? `
                        <div>
                            <h5 class="font-bold mb-2">Instructions:</h5>
                            <p>${rx.instructions}</p>
                        </div>
                    ` : ''}
                </div>
            `;
        }).join('');
    } catch (error) {
        console.error('Failed to load prescriptions:', error);
    }
}

async function loadDiseases() {
    try {
        const response = await fetch('/api/diseases');
        const diseases = await response.json();
        
        const list = document.getElementById('diseases-list');
        list.innerHTML = diseases.map(disease => `
            <div class="glass-card p-6 rounded-xl mb-4 cursor-pointer hover:border-cyan-400" onclick="showDiseaseDetails(${disease.id})">
                <div class="flex justify-between items-start">
                    <div>
                        <h4 class="text-xl font-bold">${disease.name}</h4>
                        <p class="text-gray-400">${disease.category}</p>
                    </div>
                    <span class="px-3 py-1 rounded" style="background: ${getSeverityColor(disease.severity)}">${disease.severity}</span>
                </div>
                <p class="mt-2 text-sm">${disease.description}</p>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load diseases:', error);
    }
}

async function searchDiseases() {
    const query = document.getElementById('disease-search').value.toLowerCase();
    
    try {
        const response = await fetch('/api/diseases');
        const diseases = await response.json();
        
        const filtered = diseases.filter(d => 
            d.name.toLowerCase().includes(query) || 
            d.category.toLowerCase().includes(query) ||
            d.description.toLowerCase().includes(query)
        );
        
        const list = document.getElementById('diseases-list');
        list.innerHTML = filtered.map(disease => `
            <div class="glass-card p-6 rounded-xl mb-4 cursor-pointer hover:border-cyan-400" onclick="showDiseaseDetails(${disease.id})">
                <div class="flex justify-between items-start">
                    <div>
                        <h4 class="text-xl font-bold">${disease.name}</h4>
                        <p class="text-gray-400">${disease.category}</p>
                    </div>
                    <span class="px-3 py-1 rounded" style="background: ${getSeverityColor(disease.severity)}">${disease.severity}</span>
                </div>
                <p class="mt-2 text-sm">${disease.description}</p>
            </div>
        `).join('');
    } catch (error) {
        console.error('Search failed:', error);
    }
}

async function showDiseaseDetails(diseaseId) {
    try {
        const response = await fetch(`/api/diseases/${diseaseId}`);
        const disease = await response.json();
        
        const symptoms = JSON.parse(disease.symptoms || '[]');
        const causes = JSON.parse(disease.causes || '[]');
        const prevention = JSON.parse(disease.prevention || '[]');
        const treatment = JSON.parse(disease.treatment || '[]');
        
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="glass-card p-8 rounded-xl max-w-3xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="flex justify-between items-start mb-6">
                    <div>
                        <h2 class="text-3xl font-bold neon-text">${disease.name}</h2>
                        <p class="text-gray-400">${disease.category}</p>
                    </div>
                    <button onclick="this.closest('.modal').remove()" class="text-3xl hover:text-red-400">&times;</button>
                </div>
                
                <div class="mb-4">
                    <p>${disease.description}</p>
                    <div class="flex gap-4 mt-2">
                        <span class="px-3 py-1 rounded" style="background: ${getSeverityColor(disease.severity)}">Severity: ${disease.severity}</span>
                        <span class="px-3 py-1 rounded ${disease.is_contagious ? 'bg-red-500' : 'bg-green-500'}">
                            ${disease.is_contagious ? 'Contagious' : 'Not Contagious'}
                        </span>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h4 class="text-xl font-bold mb-2" style="color: #ff00ff;">Symptoms</h4>
                        <ul class="list-disc list-inside">
                            ${symptoms.map(s => `<li>${s}</li>`).join('')}
                        </ul>
                    </div>
                    
                    <div>
                        <h4 class="text-xl font-bold mb-2" style="color: #ff00ff;">Causes</h4>
                        <ul class="list-disc list-inside">
                            ${causes.map(c => `<li>${c}</li>`).join('')}
                        </ul>
                    </div>
                    
                    <div>
                        <h4 class="text-xl font-bold mb-2" style="color: #00ff00;">Prevention</h4>
                        <ul class="list-disc list-inside">
                            ${prevention.map(p => `<li>${p}</li>`).join('')}
                        </ul>
                    </div>
                    
                    <div>
                        <h4 class="text-xl font-bold mb-2" style="color: #00ffff;">Treatment</h4>
                        <ul class="list-disc list-inside">
                            ${treatment.map(t => `<li>${t}</li>`).join('')}
                        </ul>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    } catch (error) {
        console.error('Failed to load disease details:', error);
    }
}

// Doctor Dashboard
async function loadDoctorDashboard() {
    const content = document.getElementById('dashboard-content');
    
    content.innerHTML = `
        <div class="dashboard-nav">
            <button class="nav-btn active" onclick="showDoctorSection('appointments')">My Appointments</button>
            <button class="nav-btn" onclick="showDoctorSection('patients')">My Patients</button>
            <button class="nav-btn" onclick="showDoctorSection('prescribe')">Write Prescription</button>
            <button class="nav-btn" onclick="showDoctorSection('diseases')">Disease Database</button>
        </div>
        
        <div id="doctor-appointments" class="glass-card p-6 rounded-xl">
            <h3 class="text-2xl font-bold mb-4 neon-text">My Appointments</h3>
            <div id="doctor-appointments-list"></div>
        </div>
        
        <div id="doctor-patients" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">My Patients</h3>
            <div id="doctor-patients-list"></div>
        </div>
        
        <div id="doctor-prescribe" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">Write Prescription</h3>
            <div id="prescribe-form-container"></div>
        </div>
        
        <div id="doctor-diseases" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">Disease Database</h3>
            <div class="mb-4">
                <input type="text" id="doctor-disease-search" placeholder="Search diseases..." 
                       class="w-full px-4 py-3 rounded-lg" onkeyup="searchDiseasesDoctor()">
            </div>
            <div id="doctor-diseases-list"></div>
        </div>
    `;
    
    loadDoctorAppointments();
}

function showDoctorSection(section) {
    document.getElementById('doctor-appointments').classList.add('hidden');
    document.getElementById('doctor-patients').classList.add('hidden');
    document.getElementById('doctor-prescribe').classList.add('hidden');
    document.getElementById('doctor-diseases').classList.add('hidden');
    
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`doctor-${section}`).classList.remove('hidden');
    event.target.classList.add('active');
    
    if (section === 'appointments') loadDoctorAppointments();
    else if (section === 'patients') loadDoctorPatients();
    else if (section === 'prescribe') loadPrescribeForm();
    else if (section === 'diseases') loadDiseasesDoctor();
}

async function loadDoctorAppointments() {
    try {
        const response = await fetch(`/api/appointments/doctor/${currentUser.id}`);
        const appointments = await response.json();
        
        const list = document.getElementById('doctor-appointments-list');
        if (appointments.length === 0) {
            list.innerHTML = '<p class="text-gray-400">No appointments scheduled.</p>';
            return;
        }
        
        list.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Patient</th>
                        <th>Phone</th>
                        <th>Blood Group</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${appointments.map(apt => `
                        <tr>
                            <td>${apt.appointment_date}</td>
                            <td>${apt.appointment_time}</td>
                            <td>${apt.patient_name}</td>
                            <td>${apt.phone || 'N/A'}</td>
                            <td>${apt.blood_group || 'N/A'}</td>
                            <td><span class="px-2 py-1 rounded" style="background: ${getStatusColor(apt.status)}">${apt.status}</span></td>
                            <td>
                                ${apt.status === 'scheduled' ? `
                                    <button onclick="updateAppointmentStatus(${apt.id}, 'completed')" class="px-3 py-1 bg-green-500 rounded text-sm">Complete</button>
                                    <button onclick="updateAppointmentStatus(${apt.id}, 'cancelled')" class="px-3 py-1 bg-red-500 rounded text-sm">Cancel</button>
                                ` : '-'}
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Failed to load appointments:', error);
    }
}

async function updateAppointmentStatus(appointmentId, status) {
    try {
        const response = await fetch(`/api/appointments/${appointmentId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status })
        });
        
        if (response.ok) {
            showNotification('Appointment updated successfully!', 'success');
            loadDoctorAppointments();
        } else {
            showNotification('Failed to update appointment', 'error');
        }
    } catch (error) {
        showNotification('Network error', 'error');
    }
}

async function loadDoctorPatients() {
    try {
        const response = await fetch(`/api/doctors/${currentUser.id}/patients`);
        const patients = await response.json();
        
        const list = document.getElementById('doctor-patients-list');
        if (patients.length === 0) {
            list.innerHTML = '<p class="text-gray-400">No patients yet.</p>';
            return;
        }
        
        list.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Blood Group</th>
                        <th>Gender</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${patients.map(patient => `
                        <tr>
                            <td>${patient.full_name}</td>
                            <td>${patient.email}</td>
                            <td>${patient.phone || 'N/A'}</td>
                            <td>${patient.blood_group || 'N/A'}</td>
                            <td>${patient.gender || 'N/A'}</td>
                            <td>
                                <button onclick="viewPatientHistory(${patient.user_id})" class="px-3 py-1 bg-cyan-500 rounded text-sm">View History</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Failed to load patients:', error);
    }
}

async function viewPatientHistory(userId) {
    try {
        const response = await fetch(`/api/patients/${userId}/history`);
        const history = await response.json();
        
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="glass-card p-8 rounded-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="flex justify-between items-start mb-6">
                    <h2 class="text-3xl font-bold neon-text">Patient Medical History</h2>
                    <button onclick="this.closest('.modal').remove()" class="text-3xl hover:text-red-400">&times;</button>
                </div>
                
                ${history.length === 0 ? '<p class="text-gray-400">No medical history recorded.</p>' : `
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Disease</th>
                                <th>Status</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${history.map(item => `
                                <tr>
                                    <td>${item.diagnosis_date}</td>
                                    <td>${item.disease_name}</td>
                                    <td><span class="px-2 py-1 rounded" style="background: ${getStatusColor(item.status)}">${item.status}</span></td>
                                    <td>${item.notes || '-'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                `}
            </div>
        `;
        
        document.body.appendChild(modal);
    } catch (error) {
        console.error('Failed to load patient history:', error);
    }
}

async function loadPrescribeForm() {
    // Load patients for dropdown
    const response = await fetch(`/api/doctors/${currentUser.id}/patients`);
    const patients = await response.json();
    
    const container = document.getElementById('prescribe-form-container');
    container.innerHTML = `
        <form onsubmit="createPrescription(event)">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block mb-2">Select Patient</label>
                    <select id="rx-patient" required class="w-full px-4 py-3 rounded-lg">
                        <option value="">Choose patient</option>
                        ${patients.map(p => `<option value="${p.user_id}">${p.full_name}</option>`).join('')}
                    </select>
                </div>
                <div>
                    <label class="block mb-2">Diagnosis</label>
                    <input type="text" id="rx-diagnosis" required class="w-full px-4 py-3 rounded-lg">
                </div>
                <div class="md:col-span-2">
                    <label class="block mb-2">Medications</label>
                    <div id="medications-container">
                        <div class="medication-row grid grid-cols-4 gap-2 mb-2">
                            <input type="text" placeholder="Medicine name" class="med-name px-4 py-3 rounded-lg">
                            <input type="text" placeholder="Dosage" class="med-dosage px-4 py-3 rounded-lg">
                            <input type="text" placeholder="Frequency" class="med-frequency px-4 py-3 rounded-lg">
                            <input type="text" placeholder="Duration" class="med-duration px-4 py-3 rounded-lg">
                        </div>
                    </div>
                    <button type="button" onclick="addMedicationRow()" class="px-4 py-2 bg-cyan-500 rounded mt-2">+ Add More</button>
                </div>
                <div class="md:col-span-2">
                    <label class="block mb-2">Instructions</label>
                    <textarea id="rx-instructions" rows="3" class="w-full px-4 py-3 rounded-lg"></textarea>
                </div>
                <div>
                    <label class="block mb-2">Valid Until</label>
                    <input type="date" id="rx-valid" required class="w-full px-4 py-3 rounded-lg">
                </div>
            </div>
            <button type="submit" class="btn-neon px-6 py-3 rounded-lg mt-4">Create Prescription</button>
        </form>
    `;
}

function addMedicationRow() {
    const container = document.getElementById('medications-container');
    const row = document.createElement('div');
    row.className = 'medication-row grid grid-cols-4 gap-2 mb-2';
    row.innerHTML = `
        <input type="text" placeholder="Medicine name" class="med-name px-4 py-3 rounded-lg">
        <input type="text" placeholder="Dosage" class="med-dosage px-4 py-3 rounded-lg">
        <input type="text" placeholder="Frequency" class="med-frequency px-4 py-3 rounded-lg">
        <input type="text" placeholder="Duration" class="med-duration px-4 py-3 rounded-lg">
    `;
    container.appendChild(row);
}

async function createPrescription(event) {
    event.preventDefault();
    
    // Collect medications
    const medications = [];
    document.querySelectorAll('.medication-row').forEach(row => {
        const name = row.querySelector('.med-name').value;
        const dosage = row.querySelector('.med-dosage').value;
        const frequency = row.querySelector('.med-frequency').value;
        const duration = row.querySelector('.med-duration').value;
        
        if (name && dosage) {
            medications.push({ name, dosage, frequency, duration });
        }
    });
    
    const data = {
        patientUserId: document.getElementById('rx-patient').value,
        doctorUserId: currentUser.id,
        diagnosis: document.getElementById('rx-diagnosis').value,
        medications: medications,
        instructions: document.getElementById('rx-instructions').value,
        valid_until: document.getElementById('rx-valid').value
    };
    
    try {
        const response = await fetch('/api/prescriptions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showNotification('Prescription created successfully!', 'success');
            loadPrescribeForm(); // Reset form
        } else {
            showNotification('Failed to create prescription', 'error');
        }
    } catch (error) {
        showNotification('Network error', 'error');
    }
}

async function loadDiseasesDoctor() {
    try {
        const response = await fetch('/api/diseases');
        const diseases = await response.json();
        
        const list = document.getElementById('doctor-diseases-list');
        list.innerHTML = diseases.map(disease => `
            <div class="glass-card p-6 rounded-xl mb-4 cursor-pointer hover:border-cyan-400" onclick="showDiseaseDetails(${disease.id})">
                <div class="flex justify-between items-start">
                    <div>
                        <h4 class="text-xl font-bold">${disease.name}</h4>
                        <p class="text-gray-400">${disease.category}</p>
                    </div>
                    <span class="px-3 py-1 rounded" style="background: ${getSeverityColor(disease.severity)}">${disease.severity}</span>
                </div>
                <p class="mt-2 text-sm">${disease.description}</p>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load diseases:', error);
    }
}

async function searchDiseasesDoctor() {
    const query = document.getElementById('doctor-disease-search').value.toLowerCase();
    
    try {
        const response = await fetch('/api/diseases');
        const diseases = await response.json();
        
        const filtered = diseases.filter(d => 
            d.name.toLowerCase().includes(query) || 
            d.category.toLowerCase().includes(query) ||
            d.description.toLowerCase().includes(query)
        );
        
        const list = document.getElementById('doctor-diseases-list');
        list.innerHTML = filtered.map(disease => `
            <div class="glass-card p-6 rounded-xl mb-4 cursor-pointer hover:border-cyan-400" onclick="showDiseaseDetails(${disease.id})">
                <div class="flex justify-between items-start">
                    <div>
                        <h4 class="text-xl font-bold">${disease.name}</h4>
                        <p class="text-gray-400">${disease.category}</p>
                    </div>
                    <span class="px-3 py-1 rounded" style="background: ${getSeverityColor(disease.severity)}">${disease.severity}</span>
                </div>
                <p class="mt-2 text-sm">${disease.description}</p>
            </div>
        `).join('');
    } catch (error) {
        console.error('Search failed:', error);
    }
}

// Admin Dashboard
async function loadAdminDashboard() {
    const content = document.getElementById('dashboard-content');
    
    content.innerHTML = `
        <div class="dashboard-nav">
            <button class="nav-btn active" onclick="showAdminSection('stats')">Statistics</button>
            <button class="nav-btn" onclick="showAdminSection('users')">All Users</button>
        </div>
        
        <div id="admin-stats" class="glass-card p-6 rounded-xl">
            <h3 class="text-2xl font-bold mb-4 neon-text">System Statistics</h3>
            <div id="stats-container" class="grid grid-cols-1 md:grid-cols-3 gap-6"></div>
        </div>
        
        <div id="admin-users" class="glass-card p-6 rounded-xl hidden">
            <h3 class="text-2xl font-bold mb-4 neon-text">All Users</h3>
            <div id="users-list"></div>
        </div>
    `;
    
    loadAdminStats();
}

function showAdminSection(section) {
    document.getElementById('admin-stats').classList.add('hidden');
    document.getElementById('admin-users').classList.add('hidden');
    
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`admin-${section}`).classList.remove('hidden');
    event.target.classList.add('active');
    
    if (section === 'stats') loadAdminStats();
    else if (section === 'users') loadAllUsers();
}

async function loadAdminStats() {
    try {
        const response = await fetch('/api/admin/stats');
        const stats = await response.json();
        
        const container = document.getElementById('stats-container');
        container.innerHTML = `
            <div class="glass-card p-6 rounded-xl text-center">
                <i class="fas fa-users text-5xl mb-4" style="color: #00ffff;"></i>
                <h4 class="text-3xl font-bold">${stats.totalUsers}</h4>
                <p class="text-gray-400">Total Users</p>
            </div>
            <div class="glass-card p-6 rounded-xl text-center">
                <i class="fas fa-user-injured text-5xl mb-4" style="color: #ff00ff;"></i>
                <h4 class="text-3xl font-bold">${stats.totalPatients}</h4>
                <p class="text-gray-400">Patients</p>
            </div>
            <div class="glass-card p-6 rounded-xl text-center">
                <i class="fas fa-user-md text-5xl mb-4" style="color: #00ff00;"></i>
                <h4 class="text-3xl font-bold">${stats.totalDoctors}</h4>
                <p class="text-gray-400">Doctors</p>
            </div>
            <div class="glass-card p-6 rounded-xl text-center">
                <i class="fas fa-calendar-check text-5xl mb-4" style="color: #ffff00;"></i>
                <h4 class="text-3xl font-bold">${stats.totalAppointments}</h4>
                <p class="text-gray-400">Appointments</p>
            </div>
            <div class="glass-card p-6 rounded-xl text-center">
                <i class="fas fa-virus text-5xl mb-4" style="color: #ff0080;"></i>
                <h4 class="text-3xl font-bold">${stats.totalDiseases}</h4>
                <p class="text-gray-400">Diseases in Database</p>
            </div>
        `;
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

async function loadAllUsers() {
    try {
        const response = await fetch('/api/admin/users');
        const users = await response.json();
        
        const list = document.getElementById('users-list');
        list.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    ${users.map(user => `
                        <tr>
                            <td>${user.id}</td>
                            <td>${user.full_name}</td>
                            <td>${user.email}</td>
                            <td><span class="px-2 py-1 rounded" style="background: ${getRoleColor(user.role)}">${user.role}</span></td>
                            <td>${new Date(user.created_at).toLocaleDateString()}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

// Chat functions
function toggleChat() {
    chatOpen = !chatOpen;
    const chatWindow = document.getElementById('chat-window');
    if (chatOpen) {
        chatWindow.classList.add('active');
    } else {
        chatWindow.classList.remove('active');
    }
}

async function sendChatMessage(event) {
    event.preventDefault();
    
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addChatMessage(message, 'user');
    input.value = '';
    
    // Add loading indicator
    const loadingId = 'loading-' + Date.now();
    addChatMessage('<div class="loading"></div>', 'ai', loadingId);
    
    try {
        const response = await fetch('/api/ai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });
        
        const data = await response.json();
        
        // Remove loading indicator
        document.getElementById(loadingId).remove();
        
        // Add AI response
        addChatMessage(data.response, 'ai');
    } catch (error) {
        document.getElementById(loadingId).remove();
        addChatMessage('Sorry, I encountered an error. Please try again.', 'ai');
    }
}

function addChatMessage(text, sender, id = null) {
    const messagesContainer = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    if (id) messageDiv.id = id;
    messageDiv.innerHTML = `<p>${text}</p>`;
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Utility functions
function setLoading(type, isLoading) {
    const btnText = document.getElementById(`${type}-btn-text`);
    const loading = document.getElementById(`${type}-loading`);
    
    if (isLoading) {
        btnText.classList.add('hidden');
        loading.classList.remove('hidden');
    } else {
        btnText.classList.remove('hidden');
        loading.classList.add('hidden');
    }
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `fixed top-24 right-6 glass-card p-4 rounded-lg z-[9999] ${
        type === 'success' ? 'border-green-500' : 'border-red-500'
    }`;
    notification.style.borderWidth = '2px';
    notification.innerHTML = `
        <div class="flex items-center gap-3">
            <i class="fas ${type === 'success' ? 'fa-check-circle text-green-500' : 'fa-exclamation-circle text-red-500'} text-2xl"></i>
            <p>${message}</p>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function getStatusColor(status) {
    const colors = {
        'scheduled': '#3b82f6',
        'completed': '#10b981',
        'cancelled': '#ef4444',
        'no-show': '#6b7280',
        'active': '#ef4444',
        'recovered': '#10b981',
        'chronic': '#f59e0b',
        'monitoring': '#3b82f6'
    };
    return colors[status] || '#6b7280';
}

function getSeverityColor(severity) {
    const colors = {
        'mild': '#10b981',
        'moderate': '#f59e0b',
        'severe': '#ef4444',
        'critical': '#dc2626'
    };
    return colors[severity] || '#6b7280';
}

function getRoleColor(role) {
    const colors = {
        'admin': '#8b5cf6',
        'doctor': '#3b82f6',
        'patient': '#10b981'
    };
    return colors[role] || '#6b7280';
}
