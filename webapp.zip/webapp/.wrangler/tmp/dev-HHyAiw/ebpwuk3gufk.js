var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// node_modules/unenv/dist/runtime/_internal/utils.mjs
// @__NO_SIDE_EFFECTS__
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw /* @__PURE__ */ createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  static {
    __name(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark = class PerformanceMark2 extends PerformanceEntry {
  static {
    __name(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance = class {
  static {
    __name(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver = class {
  static {
    __name(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
  static {
    __name(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};

// node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
  static {
    __name(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir4, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x2, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env3) {
    return 1;
  }
  hasColors(count4, env3) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};

// node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class _Process2 extends EventEmitter {
  static {
    __name(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process2.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd3) {
    this.#cwd = cwd3;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION}`;
  }
  get versions() {
    return { node: NODE_VERSION };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var workerdProcess = getBuiltinModule("node:process");
var isWorkerdProcessV2 = globalThis.Cloudflare.compatibilityFlags.enable_nodejs_process_v2;
var unenvProcess = new Process({
  env: globalProcess.env,
  // `hrtime` is only available from workerd process v2
  hrtime: isWorkerdProcessV2 ? workerdProcess.hrtime : hrtime,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess.nextTick
});
var { exit, features, platform } = workerdProcess;
var {
  // Always implemented by workerd
  env,
  // Only implemented in workerd v2
  hrtime: hrtime3,
  // Always implemented by workerd
  nextTick
} = unenvProcess;
var {
  _channel,
  _disconnect,
  _events,
  _eventsCount,
  _handleQueue,
  _maxListeners,
  _pendingMessage,
  _send,
  assert: assert2,
  disconnect,
  mainModule
} = unenvProcess;
var {
  // @ts-expect-error `_debugEnd` is missing typings
  _debugEnd,
  // @ts-expect-error `_debugProcess` is missing typings
  _debugProcess,
  // @ts-expect-error `_exiting` is missing typings
  _exiting,
  // @ts-expect-error `_fatalException` is missing typings
  _fatalException,
  // @ts-expect-error `_getActiveHandles` is missing typings
  _getActiveHandles,
  // @ts-expect-error `_getActiveRequests` is missing typings
  _getActiveRequests,
  // @ts-expect-error `_kill` is missing typings
  _kill,
  // @ts-expect-error `_linkedBinding` is missing typings
  _linkedBinding,
  // @ts-expect-error `_preload_modules` is missing typings
  _preload_modules,
  // @ts-expect-error `_rawDebug` is missing typings
  _rawDebug,
  // @ts-expect-error `_startProfilerIdleNotifier` is missing typings
  _startProfilerIdleNotifier,
  // @ts-expect-error `_stopProfilerIdleNotifier` is missing typings
  _stopProfilerIdleNotifier,
  // @ts-expect-error `_tickCallback` is missing typings
  _tickCallback,
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  arch,
  argv,
  argv0,
  availableMemory,
  // @ts-expect-error `binding` is missing typings
  binding,
  channel,
  chdir,
  config,
  connected,
  constrainedMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  // @ts-expect-error `domain` is missing typings
  domain,
  emit,
  emitWarning,
  eventNames,
  execArgv,
  execPath,
  exitCode,
  finalization,
  getActiveResourcesInfo,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getMaxListeners,
  getuid,
  hasUncaughtExceptionCaptureCallback,
  // @ts-expect-error `initgroups` is missing typings
  initgroups,
  kill,
  listenerCount,
  listeners,
  loadEnvFile,
  memoryUsage,
  // @ts-expect-error `moduleLoadList` is missing typings
  moduleLoadList,
  off,
  on,
  once,
  // @ts-expect-error `openStdin` is missing typings
  openStdin,
  permission,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  // @ts-expect-error `reallyExit` is missing typings
  reallyExit,
  ref,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  send,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setMaxListeners,
  setSourceMapsEnabled,
  setuid,
  setUncaughtExceptionCaptureCallback,
  sourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  throwDeprecation,
  title,
  traceDeprecation,
  umask,
  unref,
  uptime,
  version,
  versions
} = isWorkerdProcessV2 ? workerdProcess : unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// .wrangler/tmp/pages-dOh9w8/bundledWorker-0.32556740221676006.mjs
import { Writable as Writable2 } from "node:stream";
import { EventEmitter as EventEmitter2 } from "node:events";
var __defProp2 = Object.defineProperty;
var __name2 = /* @__PURE__ */ __name((target, value) => __defProp2(target, "name", { value, configurable: true }), "__name");
// @__NO_SIDE_EFFECTS__
function createNotImplementedError2(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError2, "createNotImplementedError");
__name2(createNotImplementedError2, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented2(name) {
  const fn = /* @__PURE__ */ __name2(() => {
    throw /* @__PURE__ */ createNotImplementedError2(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented2, "notImplemented");
__name2(notImplemented2, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass2(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass2, "notImplementedClass");
__name2(notImplementedClass2, "notImplementedClass");
var _timeOrigin2 = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow2 = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin2;
var nodeTiming2 = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry2 = class {
  static {
    __name(this, "PerformanceEntry");
  }
  static {
    __name2(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow2();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow2() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark3 = class PerformanceMark22 extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceMark2");
  }
  static {
    __name2(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure2 = class extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceMeasure");
  }
  static {
    __name2(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming2 = class extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  static {
    __name2(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList2 = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  static {
    __name2(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance2 = class {
  static {
    __name(this, "Performance");
  }
  static {
    __name2(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin2;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming2;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming2("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin2) {
      return _performanceNow2();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark3(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure2(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver2 = class {
  static {
    __name(this, "PerformanceObserver");
  }
  static {
    __name2(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw /* @__PURE__ */ createNotImplementedError2("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw /* @__PURE__ */ createNotImplementedError2("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance2 = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance2();
globalThis.performance = performance2;
globalThis.Performance = Performance2;
globalThis.PerformanceEntry = PerformanceEntry2;
globalThis.PerformanceMark = PerformanceMark3;
globalThis.PerformanceMeasure = PerformanceMeasure2;
globalThis.PerformanceObserver = PerformanceObserver2;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList2;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming2;
var noop_default2 = Object.assign(() => {
}, { __unenv__: true });
var _console2 = globalThis.console;
var _ignoreErrors2 = true;
var _stderr2 = new Writable2();
var _stdout2 = new Writable2();
var log3 = _console2?.log ?? noop_default2;
var info3 = _console2?.info ?? log3;
var trace3 = _console2?.trace ?? info3;
var debug3 = _console2?.debug ?? log3;
var table3 = _console2?.table ?? log3;
var error3 = _console2?.error ?? log3;
var warn3 = _console2?.warn ?? error3;
var createTask3 = _console2?.createTask ?? /* @__PURE__ */ notImplemented2("console.createTask");
var clear3 = _console2?.clear ?? noop_default2;
var count3 = _console2?.count ?? noop_default2;
var countReset3 = _console2?.countReset ?? noop_default2;
var dir3 = _console2?.dir ?? noop_default2;
var dirxml3 = _console2?.dirxml ?? noop_default2;
var group3 = _console2?.group ?? noop_default2;
var groupEnd3 = _console2?.groupEnd ?? noop_default2;
var groupCollapsed3 = _console2?.groupCollapsed ?? noop_default2;
var profile3 = _console2?.profile ?? noop_default2;
var profileEnd3 = _console2?.profileEnd ?? noop_default2;
var time3 = _console2?.time ?? noop_default2;
var timeEnd3 = _console2?.timeEnd ?? noop_default2;
var timeLog3 = _console2?.timeLog ?? noop_default2;
var timeStamp3 = _console2?.timeStamp ?? noop_default2;
var Console2 = _console2?.Console ?? /* @__PURE__ */ notImplementedClass2("console.Console");
var _times2 = /* @__PURE__ */ new Map();
var _stdoutErrorHandler2 = noop_default2;
var _stderrErrorHandler2 = noop_default2;
var workerdConsole2 = globalThis["console"];
var {
  assert: assert3,
  clear: clear22,
  // @ts-expect-error undocumented public API
  context: context2,
  count: count22,
  countReset: countReset22,
  // @ts-expect-error undocumented public API
  createTask: createTask22,
  debug: debug22,
  dir: dir22,
  dirxml: dirxml22,
  error: error22,
  group: group22,
  groupCollapsed: groupCollapsed22,
  groupEnd: groupEnd22,
  info: info22,
  log: log22,
  profile: profile22,
  profileEnd: profileEnd22,
  table: table22,
  time: time22,
  timeEnd: timeEnd22,
  timeLog: timeLog22,
  timeStamp: timeStamp22,
  trace: trace22,
  warn: warn22
} = workerdConsole2;
Object.assign(workerdConsole2, {
  Console: Console2,
  _ignoreErrors: _ignoreErrors2,
  _stderr: _stderr2,
  _stderrErrorHandler: _stderrErrorHandler2,
  _stdout: _stdout2,
  _stdoutErrorHandler: _stdoutErrorHandler2,
  _times: _times2
});
var console_default2 = workerdConsole2;
globalThis.console = console_default2;
var hrtime4 = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name2(/* @__PURE__ */ __name(function hrtime22(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime2"), "hrtime"), { bigint: /* @__PURE__ */ __name2(/* @__PURE__ */ __name(function bigint2() {
  return BigInt(Date.now() * 1e6);
}, "bigint"), "bigint") });
var ReadStream2 = class {
  static {
    __name(this, "ReadStream");
  }
  static {
    __name2(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};
var WriteStream2 = class {
  static {
    __name(this, "WriteStream");
  }
  static {
    __name2(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir32, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x2, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env22) {
    return 1;
  }
  hasColors(count32, env22) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};
var NODE_VERSION2 = "22.14.0";
var Process2 = class _Process extends EventEmitter2 {
  static {
    __name(this, "_Process");
  }
  static {
    __name2(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process.prototype), ...Object.getOwnPropertyNames(EventEmitter2.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream2(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream2(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream2(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd22) {
    this.#cwd = cwd22;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION2}`;
  }
  get versions() {
    return { node: NODE_VERSION2 };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw /* @__PURE__ */ createNotImplementedError2("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw /* @__PURE__ */ createNotImplementedError2("process.getActiveResourcesInfo");
  }
  exit() {
    throw /* @__PURE__ */ createNotImplementedError2("process.exit");
  }
  reallyExit() {
    throw /* @__PURE__ */ createNotImplementedError2("process.reallyExit");
  }
  kill() {
    throw /* @__PURE__ */ createNotImplementedError2("process.kill");
  }
  abort() {
    throw /* @__PURE__ */ createNotImplementedError2("process.abort");
  }
  dlopen() {
    throw /* @__PURE__ */ createNotImplementedError2("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw /* @__PURE__ */ createNotImplementedError2("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw /* @__PURE__ */ createNotImplementedError2("process.loadEnvFile");
  }
  disconnect() {
    throw /* @__PURE__ */ createNotImplementedError2("process.disconnect");
  }
  cpuUsage() {
    throw /* @__PURE__ */ createNotImplementedError2("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw /* @__PURE__ */ createNotImplementedError2("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw /* @__PURE__ */ createNotImplementedError2("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw /* @__PURE__ */ createNotImplementedError2("process.initgroups");
  }
  openStdin() {
    throw /* @__PURE__ */ createNotImplementedError2("process.openStdin");
  }
  assert() {
    throw /* @__PURE__ */ createNotImplementedError2("process.assert");
  }
  binding() {
    throw /* @__PURE__ */ createNotImplementedError2("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented2("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented2("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented2("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented2("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented2("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented2("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name2(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};
var globalProcess2 = globalThis["process"];
var getBuiltinModule2 = globalProcess2.getBuiltinModule;
var workerdProcess2 = getBuiltinModule2("node:process");
var isWorkerdProcessV22 = globalThis.Cloudflare.compatibilityFlags.enable_nodejs_process_v2;
var unenvProcess2 = new Process2({
  env: globalProcess2.env,
  // `hrtime` is only available from workerd process v2
  hrtime: isWorkerdProcessV22 ? workerdProcess2.hrtime : hrtime4,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess2.nextTick
});
var { exit: exit2, features: features2, platform: platform2 } = workerdProcess2;
var {
  // Always implemented by workerd
  env: env2,
  // Only implemented in workerd v2
  hrtime: hrtime32,
  // Always implemented by workerd
  nextTick: nextTick2
} = unenvProcess2;
var {
  _channel: _channel2,
  _disconnect: _disconnect2,
  _events: _events2,
  _eventsCount: _eventsCount2,
  _handleQueue: _handleQueue2,
  _maxListeners: _maxListeners2,
  _pendingMessage: _pendingMessage2,
  _send: _send2,
  assert: assert22,
  disconnect: disconnect2,
  mainModule: mainModule2
} = unenvProcess2;
var {
  // @ts-expect-error `_debugEnd` is missing typings
  _debugEnd: _debugEnd2,
  // @ts-expect-error `_debugProcess` is missing typings
  _debugProcess: _debugProcess2,
  // @ts-expect-error `_exiting` is missing typings
  _exiting: _exiting2,
  // @ts-expect-error `_fatalException` is missing typings
  _fatalException: _fatalException2,
  // @ts-expect-error `_getActiveHandles` is missing typings
  _getActiveHandles: _getActiveHandles2,
  // @ts-expect-error `_getActiveRequests` is missing typings
  _getActiveRequests: _getActiveRequests2,
  // @ts-expect-error `_kill` is missing typings
  _kill: _kill2,
  // @ts-expect-error `_linkedBinding` is missing typings
  _linkedBinding: _linkedBinding2,
  // @ts-expect-error `_preload_modules` is missing typings
  _preload_modules: _preload_modules2,
  // @ts-expect-error `_rawDebug` is missing typings
  _rawDebug: _rawDebug2,
  // @ts-expect-error `_startProfilerIdleNotifier` is missing typings
  _startProfilerIdleNotifier: _startProfilerIdleNotifier2,
  // @ts-expect-error `_stopProfilerIdleNotifier` is missing typings
  _stopProfilerIdleNotifier: _stopProfilerIdleNotifier2,
  // @ts-expect-error `_tickCallback` is missing typings
  _tickCallback: _tickCallback2,
  abort: abort2,
  addListener: addListener2,
  allowedNodeEnvironmentFlags: allowedNodeEnvironmentFlags2,
  arch: arch2,
  argv: argv2,
  argv0: argv02,
  availableMemory: availableMemory2,
  // @ts-expect-error `binding` is missing typings
  binding: binding2,
  channel: channel2,
  chdir: chdir2,
  config: config2,
  connected: connected2,
  constrainedMemory: constrainedMemory2,
  cpuUsage: cpuUsage2,
  cwd: cwd2,
  debugPort: debugPort2,
  dlopen: dlopen2,
  // @ts-expect-error `domain` is missing typings
  domain: domain2,
  emit: emit2,
  emitWarning: emitWarning2,
  eventNames: eventNames2,
  execArgv: execArgv2,
  execPath: execPath2,
  exitCode: exitCode2,
  finalization: finalization2,
  getActiveResourcesInfo: getActiveResourcesInfo2,
  getegid: getegid2,
  geteuid: geteuid2,
  getgid: getgid2,
  getgroups: getgroups2,
  getMaxListeners: getMaxListeners2,
  getuid: getuid2,
  hasUncaughtExceptionCaptureCallback: hasUncaughtExceptionCaptureCallback2,
  // @ts-expect-error `initgroups` is missing typings
  initgroups: initgroups2,
  kill: kill2,
  listenerCount: listenerCount2,
  listeners: listeners2,
  loadEnvFile: loadEnvFile2,
  memoryUsage: memoryUsage2,
  // @ts-expect-error `moduleLoadList` is missing typings
  moduleLoadList: moduleLoadList2,
  off: off2,
  on: on2,
  once: once2,
  // @ts-expect-error `openStdin` is missing typings
  openStdin: openStdin2,
  permission: permission2,
  pid: pid2,
  ppid: ppid2,
  prependListener: prependListener2,
  prependOnceListener: prependOnceListener2,
  rawListeners: rawListeners2,
  // @ts-expect-error `reallyExit` is missing typings
  reallyExit: reallyExit2,
  ref: ref2,
  release: release2,
  removeAllListeners: removeAllListeners2,
  removeListener: removeListener2,
  report: report2,
  resourceUsage: resourceUsage2,
  send: send2,
  setegid: setegid2,
  seteuid: seteuid2,
  setgid: setgid2,
  setgroups: setgroups2,
  setMaxListeners: setMaxListeners2,
  setSourceMapsEnabled: setSourceMapsEnabled2,
  setuid: setuid2,
  setUncaughtExceptionCaptureCallback: setUncaughtExceptionCaptureCallback2,
  sourceMapsEnabled: sourceMapsEnabled2,
  stderr: stderr2,
  stdin: stdin2,
  stdout: stdout2,
  throwDeprecation: throwDeprecation2,
  title: title2,
  traceDeprecation: traceDeprecation2,
  umask: umask2,
  unref: unref2,
  uptime: uptime2,
  version: version2,
  versions: versions2
} = isWorkerdProcessV22 ? workerdProcess2 : unenvProcess2;
var _process2 = {
  abort: abort2,
  addListener: addListener2,
  allowedNodeEnvironmentFlags: allowedNodeEnvironmentFlags2,
  hasUncaughtExceptionCaptureCallback: hasUncaughtExceptionCaptureCallback2,
  setUncaughtExceptionCaptureCallback: setUncaughtExceptionCaptureCallback2,
  loadEnvFile: loadEnvFile2,
  sourceMapsEnabled: sourceMapsEnabled2,
  arch: arch2,
  argv: argv2,
  argv0: argv02,
  chdir: chdir2,
  config: config2,
  connected: connected2,
  constrainedMemory: constrainedMemory2,
  availableMemory: availableMemory2,
  cpuUsage: cpuUsage2,
  cwd: cwd2,
  debugPort: debugPort2,
  dlopen: dlopen2,
  disconnect: disconnect2,
  emit: emit2,
  emitWarning: emitWarning2,
  env: env2,
  eventNames: eventNames2,
  execArgv: execArgv2,
  execPath: execPath2,
  exit: exit2,
  finalization: finalization2,
  features: features2,
  getBuiltinModule: getBuiltinModule2,
  getActiveResourcesInfo: getActiveResourcesInfo2,
  getMaxListeners: getMaxListeners2,
  hrtime: hrtime32,
  kill: kill2,
  listeners: listeners2,
  listenerCount: listenerCount2,
  memoryUsage: memoryUsage2,
  nextTick: nextTick2,
  on: on2,
  off: off2,
  once: once2,
  pid: pid2,
  platform: platform2,
  ppid: ppid2,
  prependListener: prependListener2,
  prependOnceListener: prependOnceListener2,
  rawListeners: rawListeners2,
  release: release2,
  removeAllListeners: removeAllListeners2,
  removeListener: removeListener2,
  report: report2,
  resourceUsage: resourceUsage2,
  setMaxListeners: setMaxListeners2,
  setSourceMapsEnabled: setSourceMapsEnabled2,
  stderr: stderr2,
  stdin: stdin2,
  stdout: stdout2,
  title: title2,
  throwDeprecation: throwDeprecation2,
  traceDeprecation: traceDeprecation2,
  umask: umask2,
  uptime: uptime2,
  version: version2,
  versions: versions2,
  // @ts-expect-error old API
  domain: domain2,
  initgroups: initgroups2,
  moduleLoadList: moduleLoadList2,
  reallyExit: reallyExit2,
  openStdin: openStdin2,
  assert: assert22,
  binding: binding2,
  send: send2,
  exitCode: exitCode2,
  channel: channel2,
  getegid: getegid2,
  geteuid: geteuid2,
  getgid: getgid2,
  getgroups: getgroups2,
  getuid: getuid2,
  setegid: setegid2,
  seteuid: seteuid2,
  setgid: setgid2,
  setgroups: setgroups2,
  setuid: setuid2,
  permission: permission2,
  mainModule: mainModule2,
  _events: _events2,
  _eventsCount: _eventsCount2,
  _exiting: _exiting2,
  _maxListeners: _maxListeners2,
  _debugEnd: _debugEnd2,
  _debugProcess: _debugProcess2,
  _fatalException: _fatalException2,
  _getActiveHandles: _getActiveHandles2,
  _getActiveRequests: _getActiveRequests2,
  _kill: _kill2,
  _preload_modules: _preload_modules2,
  _rawDebug: _rawDebug2,
  _startProfilerIdleNotifier: _startProfilerIdleNotifier2,
  _stopProfilerIdleNotifier: _stopProfilerIdleNotifier2,
  _tickCallback: _tickCallback2,
  _disconnect: _disconnect2,
  _handleQueue: _handleQueue2,
  _pendingMessage: _pendingMessage2,
  _channel: _channel2,
  _send: _send2,
  _linkedBinding: _linkedBinding2
};
var process_default2 = _process2;
globalThis.process = process_default2;
var wt = Object.defineProperty;
var Fe = /* @__PURE__ */ __name2((e) => {
  throw TypeError(e);
}, "Fe");
var yt = /* @__PURE__ */ __name2((e, t, r) => t in e ? wt(e, t, { enumerable: true, configurable: true, writable: true, value: r }) : e[t] = r, "yt");
var h = /* @__PURE__ */ __name2((e, t, r) => yt(e, typeof t != "symbol" ? t + "" : t, r), "h");
var De = /* @__PURE__ */ __name2((e, t, r) => t.has(e) || Fe("Cannot " + r), "De");
var o = /* @__PURE__ */ __name2((e, t, r) => (De(e, t, "read from private field"), r ? r.call(e) : t.get(e)), "o");
var g = /* @__PURE__ */ __name2((e, t, r) => t.has(e) ? Fe("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r), "g");
var f = /* @__PURE__ */ __name2((e, t, r, s) => (De(e, t, "write to private field"), s ? s.call(e, r) : t.set(e, r), r), "f");
var b = /* @__PURE__ */ __name2((e, t, r) => (De(e, t, "access private method"), r), "b");
var Me = /* @__PURE__ */ __name2((e, t, r, s) => ({ set _(n) {
  f(e, t, n, r);
}, get _() {
  return o(e, t, s);
} }), "Me");
var ke = /* @__PURE__ */ __name2((e, t, r) => (s, n) => {
  let a = -1;
  return i(0);
  async function i(d) {
    if (d <= a) throw new Error("next() called multiple times");
    a = d;
    let l, c = false, u;
    if (e[d] ? (u = e[d][0][0], s.req.routeIndex = d) : u = d === e.length && n || void 0, u) try {
      l = await u(s, () => i(d + 1));
    } catch (p) {
      if (p instanceof Error && t) s.error = p, l = await t(p, s), c = true;
      else throw p;
    }
    else s.finalized === false && r && (l = await r(s));
    return l && (s.finalized === false || c) && (s.res = l), s;
  }
  __name(i, "i");
  __name2(i, "i");
}, "ke");
var Et = Symbol();
var Rt = /* @__PURE__ */ __name2(async (e, t = /* @__PURE__ */ Object.create(null)) => {
  const { all: r = false, dot: s = false } = t, a = (e instanceof nt ? e.raw.headers : e.headers).get("Content-Type");
  return a != null && a.startsWith("multipart/form-data") || a != null && a.startsWith("application/x-www-form-urlencoded") ? jt(e, { all: r, dot: s }) : {};
}, "Rt");
async function jt(e, t) {
  const r = await e.formData();
  return r ? Ot(r, t) : {};
}
__name(jt, "jt");
__name2(jt, "jt");
function Ot(e, t) {
  const r = /* @__PURE__ */ Object.create(null);
  return e.forEach((s, n) => {
    t.all || n.endsWith("[]") ? _t(r, n, s) : r[n] = s;
  }), t.dot && Object.entries(r).forEach(([s, n]) => {
    s.includes(".") && (St(r, s, n), delete r[s]);
  }), r;
}
__name(Ot, "Ot");
__name2(Ot, "Ot");
var _t = /* @__PURE__ */ __name2((e, t, r) => {
  e[t] !== void 0 ? Array.isArray(e[t]) ? e[t].push(r) : e[t] = [e[t], r] : t.endsWith("[]") ? e[t] = [r] : e[t] = r;
}, "_t");
var St = /* @__PURE__ */ __name2((e, t, r) => {
  let s = e;
  const n = t.split(".");
  n.forEach((a, i) => {
    i === n.length - 1 ? s[a] = r : ((!s[a] || typeof s[a] != "object" || Array.isArray(s[a]) || s[a] instanceof File) && (s[a] = /* @__PURE__ */ Object.create(null)), s = s[a]);
  });
}, "St");
var Ze = /* @__PURE__ */ __name2((e) => {
  const t = e.split("/");
  return t[0] === "" && t.shift(), t;
}, "Ze");
var Tt = /* @__PURE__ */ __name2((e) => {
  const { groups: t, path: r } = Ct(e), s = Ze(r);
  return Dt(s, t);
}, "Tt");
var Ct = /* @__PURE__ */ __name2((e) => {
  const t = [];
  return e = e.replace(/\{[^}]+\}/g, (r, s) => {
    const n = `@${s}`;
    return t.push([n, r]), n;
  }), { groups: t, path: e };
}, "Ct");
var Dt = /* @__PURE__ */ __name2((e, t) => {
  for (let r = t.length - 1; r >= 0; r--) {
    const [s] = t[r];
    for (let n = e.length - 1; n >= 0; n--) if (e[n].includes(s)) {
      e[n] = e[n].replace(s, t[r][1]);
      break;
    }
  }
  return e;
}, "Dt");
var ye = {};
var It = /* @__PURE__ */ __name2((e, t) => {
  if (e === "*") return "*";
  const r = e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (r) {
    const s = `${e}#${t}`;
    return ye[s] || (r[2] ? ye[s] = t && t[0] !== ":" && t[0] !== "*" ? [s, r[1], new RegExp(`^${r[2]}(?=/${t})`)] : [e, r[1], new RegExp(`^${r[2]}$`)] : ye[s] = [e, r[1], true]), ye[s];
  }
  return null;
}, "It");
var Le = /* @__PURE__ */ __name2((e, t) => {
  try {
    return t(e);
  } catch {
    return e.replace(/(?:%[0-9A-Fa-f]{2})+/g, (r) => {
      try {
        return t(r);
      } catch {
        return r;
      }
    });
  }
}, "Le");
var At = /* @__PURE__ */ __name2((e) => Le(e, decodeURI), "At");
var et = /* @__PURE__ */ __name2((e) => {
  const t = e.url, r = t.indexOf("/", t.indexOf(":") + 4);
  let s = r;
  for (; s < t.length; s++) {
    const n = t.charCodeAt(s);
    if (n === 37) {
      const a = t.indexOf("?", s), i = t.slice(r, a === -1 ? void 0 : a);
      return At(i.includes("%25") ? i.replace(/%25/g, "%2525") : i);
    } else if (n === 63) break;
  }
  return t.slice(r, s);
}, "et");
var Nt = /* @__PURE__ */ __name2((e) => {
  const t = et(e);
  return t.length > 1 && t.at(-1) === "/" ? t.slice(0, -1) : t;
}, "Nt");
var re = /* @__PURE__ */ __name2((e, t, ...r) => (r.length && (t = re(t, ...r)), `${(e == null ? void 0 : e[0]) === "/" ? "" : "/"}${e}${t === "/" ? "" : `${(e == null ? void 0 : e.at(-1)) === "/" ? "" : "/"}${(t == null ? void 0 : t[0]) === "/" ? t.slice(1) : t}`}`), "re");
var tt = /* @__PURE__ */ __name2((e) => {
  if (e.charCodeAt(e.length - 1) !== 63 || !e.includes(":")) return null;
  const t = e.split("/"), r = [];
  let s = "";
  return t.forEach((n) => {
    if (n !== "" && !/\:/.test(n)) s += "/" + n;
    else if (/\:/.test(n)) if (/\?/.test(n)) {
      r.length === 0 && s === "" ? r.push("/") : r.push(s);
      const a = n.replace("?", "");
      s += "/" + a, r.push(s);
    } else s += "/" + n;
  }), r.filter((n, a, i) => i.indexOf(n) === a);
}, "tt");
var Ie = /* @__PURE__ */ __name2((e) => /[%+]/.test(e) ? (e.indexOf("+") !== -1 && (e = e.replace(/\+/g, " ")), e.indexOf("%") !== -1 ? Le(e, st) : e) : e, "Ie");
var rt = /* @__PURE__ */ __name2((e, t, r) => {
  let s;
  if (!r && t && !/[%+]/.test(t)) {
    let i = e.indexOf(`?${t}`, 8);
    for (i === -1 && (i = e.indexOf(`&${t}`, 8)); i !== -1; ) {
      const d = e.charCodeAt(i + t.length + 1);
      if (d === 61) {
        const l = i + t.length + 2, c = e.indexOf("&", l);
        return Ie(e.slice(l, c === -1 ? void 0 : c));
      } else if (d == 38 || isNaN(d)) return "";
      i = e.indexOf(`&${t}`, i + 1);
    }
    if (s = /[%+]/.test(e), !s) return;
  }
  const n = {};
  s ?? (s = /[%+]/.test(e));
  let a = e.indexOf("?", 8);
  for (; a !== -1; ) {
    const i = e.indexOf("&", a + 1);
    let d = e.indexOf("=", a);
    d > i && i !== -1 && (d = -1);
    let l = e.slice(a + 1, d === -1 ? i === -1 ? void 0 : i : d);
    if (s && (l = Ie(l)), a = i, l === "") continue;
    let c;
    d === -1 ? c = "" : (c = e.slice(d + 1, i === -1 ? void 0 : i), s && (c = Ie(c))), r ? (n[l] && Array.isArray(n[l]) || (n[l] = []), n[l].push(c)) : n[l] ?? (n[l] = c);
  }
  return t ? n[t] : n;
}, "rt");
var Pt = rt;
var Lt = /* @__PURE__ */ __name2((e, t) => rt(e, t, true), "Lt");
var st = decodeURIComponent;
var Be = /* @__PURE__ */ __name2((e) => Le(e, st), "Be");
var ae;
var C;
var k;
var at;
var it;
var Ne;
var q;
var We;
var nt = (We = class {
  static {
    __name(this, "We");
  }
  static {
    __name2(this, "We");
  }
  constructor(e, t = "/", r = [[]]) {
    g(this, k);
    h(this, "raw");
    g(this, ae);
    g(this, C);
    h(this, "routeIndex", 0);
    h(this, "path");
    h(this, "bodyCache", {});
    g(this, q, (e2) => {
      const { bodyCache: t2, raw: r2 } = this, s = t2[e2];
      if (s) return s;
      const n = Object.keys(t2)[0];
      return n ? t2[n].then((a) => (n === "json" && (a = JSON.stringify(a)), new Response(a)[e2]())) : t2[e2] = r2[e2]();
    });
    this.raw = e, this.path = t, f(this, C, r), f(this, ae, {});
  }
  param(e) {
    return e ? b(this, k, at).call(this, e) : b(this, k, it).call(this);
  }
  query(e) {
    return Pt(this.url, e);
  }
  queries(e) {
    return Lt(this.url, e);
  }
  header(e) {
    if (e) return this.raw.headers.get(e) ?? void 0;
    const t = {};
    return this.raw.headers.forEach((r, s) => {
      t[s] = r;
    }), t;
  }
  async parseBody(e) {
    var t;
    return (t = this.bodyCache).parsedBody ?? (t.parsedBody = await Rt(this, e));
  }
  json() {
    return o(this, q).call(this, "text").then((e) => JSON.parse(e));
  }
  text() {
    return o(this, q).call(this, "text");
  }
  arrayBuffer() {
    return o(this, q).call(this, "arrayBuffer");
  }
  blob() {
    return o(this, q).call(this, "blob");
  }
  formData() {
    return o(this, q).call(this, "formData");
  }
  addValidatedData(e, t) {
    o(this, ae)[e] = t;
  }
  valid(e) {
    return o(this, ae)[e];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get [Et]() {
    return o(this, C);
  }
  get matchedRoutes() {
    return o(this, C)[0].map(([[, e]]) => e);
  }
  get routePath() {
    return o(this, C)[0].map(([[, e]]) => e)[this.routeIndex].path;
  }
}, ae = /* @__PURE__ */ new WeakMap(), C = /* @__PURE__ */ new WeakMap(), k = /* @__PURE__ */ new WeakSet(), at = /* @__PURE__ */ __name2(function(e) {
  const t = o(this, C)[0][this.routeIndex][1][e], r = b(this, k, Ne).call(this, t);
  return r && /\%/.test(r) ? Be(r) : r;
}, "at"), it = /* @__PURE__ */ __name2(function() {
  const e = {}, t = Object.keys(o(this, C)[0][this.routeIndex][1]);
  for (const r of t) {
    const s = b(this, k, Ne).call(this, o(this, C)[0][this.routeIndex][1][r]);
    s !== void 0 && (e[r] = /\%/.test(s) ? Be(s) : s);
  }
  return e;
}, "it"), Ne = /* @__PURE__ */ __name2(function(e) {
  return o(this, C)[1] ? o(this, C)[1][e] : e;
}, "Ne"), q = /* @__PURE__ */ new WeakMap(), We);
var Ht = { Stringify: 1 };
var ot = /* @__PURE__ */ __name2(async (e, t, r, s, n) => {
  typeof e == "object" && !(e instanceof String) && (e instanceof Promise || (e = e.toString()), e instanceof Promise && (e = await e));
  const a = e.callbacks;
  return a != null && a.length ? (n ? n[0] += e : n = [e], Promise.all(a.map((d) => d({ phase: t, buffer: n, context: s }))).then((d) => Promise.all(d.filter(Boolean).map((l) => ot(l, t, false, s, n))).then(() => n[0]))) : Promise.resolve(e);
}, "ot");
var Ft = "text/plain; charset=UTF-8";
var Ae = /* @__PURE__ */ __name2((e, t) => ({ "Content-Type": e, ...t }), "Ae");
var me;
var ge;
var L;
var ie;
var H;
var S;
var be;
var oe;
var le;
var Y;
var xe;
var ve;
var $;
var se;
var ze;
var Mt = (ze = class {
  static {
    __name(this, "ze");
  }
  static {
    __name2(this, "ze");
  }
  constructor(e, t) {
    g(this, $);
    g(this, me);
    g(this, ge);
    h(this, "env", {});
    g(this, L);
    h(this, "finalized", false);
    h(this, "error");
    g(this, ie);
    g(this, H);
    g(this, S);
    g(this, be);
    g(this, oe);
    g(this, le);
    g(this, Y);
    g(this, xe);
    g(this, ve);
    h(this, "render", (...e2) => (o(this, oe) ?? f(this, oe, (t2) => this.html(t2)), o(this, oe).call(this, ...e2)));
    h(this, "setLayout", (e2) => f(this, be, e2));
    h(this, "getLayout", () => o(this, be));
    h(this, "setRenderer", (e2) => {
      f(this, oe, e2);
    });
    h(this, "header", (e2, t2, r) => {
      this.finalized && f(this, S, new Response(o(this, S).body, o(this, S)));
      const s = o(this, S) ? o(this, S).headers : o(this, Y) ?? f(this, Y, new Headers());
      t2 === void 0 ? s.delete(e2) : r != null && r.append ? s.append(e2, t2) : s.set(e2, t2);
    });
    h(this, "status", (e2) => {
      f(this, ie, e2);
    });
    h(this, "set", (e2, t2) => {
      o(this, L) ?? f(this, L, /* @__PURE__ */ new Map()), o(this, L).set(e2, t2);
    });
    h(this, "get", (e2) => o(this, L) ? o(this, L).get(e2) : void 0);
    h(this, "newResponse", (...e2) => b(this, $, se).call(this, ...e2));
    h(this, "body", (e2, t2, r) => b(this, $, se).call(this, e2, t2, r));
    h(this, "text", (e2, t2, r) => !o(this, Y) && !o(this, ie) && !t2 && !r && !this.finalized ? new Response(e2) : b(this, $, se).call(this, e2, t2, Ae(Ft, r)));
    h(this, "json", (e2, t2, r) => b(this, $, se).call(this, JSON.stringify(e2), t2, Ae("application/json", r)));
    h(this, "html", (e2, t2, r) => {
      const s = /* @__PURE__ */ __name2((n) => b(this, $, se).call(this, n, t2, Ae("text/html; charset=UTF-8", r)), "s");
      return typeof e2 == "object" ? ot(e2, Ht.Stringify, false, {}).then(s) : s(e2);
    });
    h(this, "redirect", (e2, t2) => {
      const r = String(e2);
      return this.header("Location", /[^\x00-\xFF]/.test(r) ? encodeURI(r) : r), this.newResponse(null, t2 ?? 302);
    });
    h(this, "notFound", () => (o(this, le) ?? f(this, le, () => new Response()), o(this, le).call(this, this)));
    f(this, me, e), t && (f(this, H, t.executionCtx), this.env = t.env, f(this, le, t.notFoundHandler), f(this, ve, t.path), f(this, xe, t.matchResult));
  }
  get req() {
    return o(this, ge) ?? f(this, ge, new nt(o(this, me), o(this, ve), o(this, xe))), o(this, ge);
  }
  get event() {
    if (o(this, H) && "respondWith" in o(this, H)) return o(this, H);
    throw Error("This context has no FetchEvent");
  }
  get executionCtx() {
    if (o(this, H)) return o(this, H);
    throw Error("This context has no ExecutionContext");
  }
  get res() {
    return o(this, S) || f(this, S, new Response(null, { headers: o(this, Y) ?? f(this, Y, new Headers()) }));
  }
  set res(e) {
    if (o(this, S) && e) {
      e = new Response(e.body, e);
      for (const [t, r] of o(this, S).headers.entries()) if (t !== "content-type") if (t === "set-cookie") {
        const s = o(this, S).headers.getSetCookie();
        e.headers.delete("set-cookie");
        for (const n of s) e.headers.append("set-cookie", n);
      } else e.headers.set(t, r);
    }
    f(this, S, e), this.finalized = true;
  }
  get var() {
    return o(this, L) ? Object.fromEntries(o(this, L)) : {};
  }
}, me = /* @__PURE__ */ new WeakMap(), ge = /* @__PURE__ */ new WeakMap(), L = /* @__PURE__ */ new WeakMap(), ie = /* @__PURE__ */ new WeakMap(), H = /* @__PURE__ */ new WeakMap(), S = /* @__PURE__ */ new WeakMap(), be = /* @__PURE__ */ new WeakMap(), oe = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakMap(), Y = /* @__PURE__ */ new WeakMap(), xe = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), $ = /* @__PURE__ */ new WeakSet(), se = /* @__PURE__ */ __name2(function(e, t, r) {
  const s = o(this, S) ? new Headers(o(this, S).headers) : o(this, Y) ?? new Headers();
  if (typeof t == "object" && "headers" in t) {
    const a = t.headers instanceof Headers ? t.headers : new Headers(t.headers);
    for (const [i, d] of a) i.toLowerCase() === "set-cookie" ? s.append(i, d) : s.set(i, d);
  }
  if (r) for (const [a, i] of Object.entries(r)) if (typeof i == "string") s.set(a, i);
  else {
    s.delete(a);
    for (const d of i) s.append(a, d);
  }
  const n = typeof t == "number" ? t : (t == null ? void 0 : t.status) ?? o(this, ie);
  return new Response(e, { status: n, headers: s });
}, "se"), ze);
var E = "ALL";
var kt = "all";
var Bt = ["get", "post", "put", "delete", "options", "patch"];
var lt = "Can not add a route since the matcher is already built.";
var dt = class extends Error {
  static {
    __name(this, "dt");
  }
  static {
    __name2(this, "dt");
  }
};
var qt = "__COMPOSED_HANDLER";
var $t = /* @__PURE__ */ __name2((e) => e.text("404 Not Found", 404), "$t");
var qe = /* @__PURE__ */ __name2((e, t) => {
  if ("getResponse" in e) {
    const r = e.getResponse();
    return t.newResponse(r.body, r);
  }
  return console.error(e), t.text("Internal Server Error", 500);
}, "qe");
var D;
var R;
var ut;
var I;
var J;
var Ee;
var Re;
var Ge;
var ct = (Ge = class {
  static {
    __name(this, "Ge");
  }
  static {
    __name2(this, "Ge");
  }
  constructor(t = {}) {
    g(this, R);
    h(this, "get");
    h(this, "post");
    h(this, "put");
    h(this, "delete");
    h(this, "options");
    h(this, "patch");
    h(this, "all");
    h(this, "on");
    h(this, "use");
    h(this, "router");
    h(this, "getPath");
    h(this, "_basePath", "/");
    g(this, D, "/");
    h(this, "routes", []);
    g(this, I, $t);
    h(this, "errorHandler", qe);
    h(this, "onError", (t2) => (this.errorHandler = t2, this));
    h(this, "notFound", (t2) => (f(this, I, t2), this));
    h(this, "fetch", (t2, ...r) => b(this, R, Re).call(this, t2, r[1], r[0], t2.method));
    h(this, "request", (t2, r, s2, n2) => t2 instanceof Request ? this.fetch(r ? new Request(t2, r) : t2, s2, n2) : (t2 = t2.toString(), this.fetch(new Request(/^https?:\/\//.test(t2) ? t2 : `http://localhost${re("/", t2)}`, r), s2, n2)));
    h(this, "fire", () => {
      addEventListener("fetch", (t2) => {
        t2.respondWith(b(this, R, Re).call(this, t2.request, t2, void 0, t2.request.method));
      });
    });
    [...Bt, kt].forEach((a) => {
      this[a] = (i, ...d) => (typeof i == "string" ? f(this, D, i) : b(this, R, J).call(this, a, o(this, D), i), d.forEach((l) => {
        b(this, R, J).call(this, a, o(this, D), l);
      }), this);
    }), this.on = (a, i, ...d) => {
      for (const l of [i].flat()) {
        f(this, D, l);
        for (const c of [a].flat()) d.map((u) => {
          b(this, R, J).call(this, c.toUpperCase(), o(this, D), u);
        });
      }
      return this;
    }, this.use = (a, ...i) => (typeof a == "string" ? f(this, D, a) : (f(this, D, "*"), i.unshift(a)), i.forEach((d) => {
      b(this, R, J).call(this, E, o(this, D), d);
    }), this);
    const { strict: s, ...n } = t;
    Object.assign(this, n), this.getPath = s ?? true ? t.getPath ?? et : Nt;
  }
  route(t, r) {
    const s = this.basePath(t);
    return r.routes.map((n) => {
      var i;
      let a;
      r.errorHandler === qe ? a = n.handler : (a = /* @__PURE__ */ __name2(async (d, l) => (await ke([], r.errorHandler)(d, () => n.handler(d, l))).res, "a"), a[qt] = n.handler), b(i = s, R, J).call(i, n.method, n.path, a);
    }), this;
  }
  basePath(t) {
    const r = b(this, R, ut).call(this);
    return r._basePath = re(this._basePath, t), r;
  }
  mount(t, r, s) {
    let n, a;
    s && (typeof s == "function" ? a = s : (a = s.optionHandler, s.replaceRequest === false ? n = /* @__PURE__ */ __name2((l) => l, "n") : n = s.replaceRequest));
    const i = a ? (l) => {
      const c = a(l);
      return Array.isArray(c) ? c : [c];
    } : (l) => {
      let c;
      try {
        c = l.executionCtx;
      } catch {
      }
      return [l.env, c];
    };
    n || (n = (() => {
      const l = re(this._basePath, t), c = l === "/" ? 0 : l.length;
      return (u) => {
        const p = new URL(u.url);
        return p.pathname = p.pathname.slice(c) || "/", new Request(p, u);
      };
    })());
    const d = /* @__PURE__ */ __name2(async (l, c) => {
      const u = await r(n(l.req.raw), ...i(l));
      if (u) return u;
      await c();
    }, "d");
    return b(this, R, J).call(this, E, re(t, "*"), d), this;
  }
}, D = /* @__PURE__ */ new WeakMap(), R = /* @__PURE__ */ new WeakSet(), ut = /* @__PURE__ */ __name2(function() {
  const t = new ct({ router: this.router, getPath: this.getPath });
  return t.errorHandler = this.errorHandler, f(t, I, o(this, I)), t.routes = this.routes, t;
}, "ut"), I = /* @__PURE__ */ new WeakMap(), J = /* @__PURE__ */ __name2(function(t, r, s) {
  t = t.toUpperCase(), r = re(this._basePath, r);
  const n = { basePath: this._basePath, path: r, method: t, handler: s };
  this.router.add(t, r, [s, n]), this.routes.push(n);
}, "J"), Ee = /* @__PURE__ */ __name2(function(t, r) {
  if (t instanceof Error) return this.errorHandler(t, r);
  throw t;
}, "Ee"), Re = /* @__PURE__ */ __name2(function(t, r, s, n) {
  if (n === "HEAD") return (async () => new Response(null, await b(this, R, Re).call(this, t, r, s, "GET")))();
  const a = this.getPath(t, { env: s }), i = this.router.match(n, a), d = new Mt(t, { path: a, matchResult: i, env: s, executionCtx: r, notFoundHandler: o(this, I) });
  if (i[0].length === 1) {
    let c;
    try {
      c = i[0][0][0][0](d, async () => {
        d.res = await o(this, I).call(this, d);
      });
    } catch (u) {
      return b(this, R, Ee).call(this, u, d);
    }
    return c instanceof Promise ? c.then((u) => u || (d.finalized ? d.res : o(this, I).call(this, d))).catch((u) => b(this, R, Ee).call(this, u, d)) : c ?? o(this, I).call(this, d);
  }
  const l = ke(i[0], this.errorHandler, o(this, I));
  return (async () => {
    try {
      const c = await l(d);
      if (!c.finalized) throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
      return c.res;
    } catch (c) {
      return b(this, R, Ee).call(this, c, d);
    }
  })();
}, "Re"), Ge);
var pt = [];
function Ut(e, t) {
  const r = this.buildAllMatchers(), s = /* @__PURE__ */ __name2((n, a) => {
    const i = r[n] || r[E], d = i[2][a];
    if (d) return d;
    const l = a.match(i[0]);
    if (!l) return [[], pt];
    const c = l.indexOf("", 1);
    return [i[1][c], l];
  }, "s");
  return this.match = s, s(e, t);
}
__name(Ut, "Ut");
__name2(Ut, "Ut");
var Oe = "[^/]+";
var fe = ".*";
var he = "(?:|/.*)";
var ne = Symbol();
var Wt = new Set(".\\+*[^]$()");
function zt(e, t) {
  return e.length === 1 ? t.length === 1 ? e < t ? -1 : 1 : -1 : t.length === 1 || e === fe || e === he ? 1 : t === fe || t === he ? -1 : e === Oe ? 1 : t === Oe ? -1 : e.length === t.length ? e < t ? -1 : 1 : t.length - e.length;
}
__name(zt, "zt");
__name2(zt, "zt");
var K;
var X;
var A;
var Je;
var Pe = (Je = class {
  static {
    __name(this, "Je");
  }
  static {
    __name2(this, "Je");
  }
  constructor() {
    g(this, K);
    g(this, X);
    g(this, A, /* @__PURE__ */ Object.create(null));
  }
  insert(t, r, s, n, a) {
    if (t.length === 0) {
      if (o(this, K) !== void 0) throw ne;
      if (a) return;
      f(this, K, r);
      return;
    }
    const [i, ...d] = t, l = i === "*" ? d.length === 0 ? ["", "", fe] : ["", "", Oe] : i === "/*" ? ["", "", he] : i.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let c;
    if (l) {
      const u = l[1];
      let p = l[2] || Oe;
      if (u && l[2] && (p === ".*" || (p = p.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:"), /\((?!\?:)/.test(p)))) throw ne;
      if (c = o(this, A)[p], !c) {
        if (Object.keys(o(this, A)).some((m) => m !== fe && m !== he)) throw ne;
        if (a) return;
        c = o(this, A)[p] = new Pe(), u !== "" && f(c, X, n.varIndex++);
      }
      !a && u !== "" && s.push([u, o(c, X)]);
    } else if (c = o(this, A)[i], !c) {
      if (Object.keys(o(this, A)).some((u) => u.length > 1 && u !== fe && u !== he)) throw ne;
      if (a) return;
      c = o(this, A)[i] = new Pe();
    }
    c.insert(d, r, s, n, a);
  }
  buildRegExpStr() {
    const r = Object.keys(o(this, A)).sort(zt).map((s) => {
      const n = o(this, A)[s];
      return (typeof o(n, X) == "number" ? `(${s})@${o(n, X)}` : Wt.has(s) ? `\\${s}` : s) + n.buildRegExpStr();
    });
    return typeof o(this, K) == "number" && r.unshift(`#${o(this, K)}`), r.length === 0 ? "" : r.length === 1 ? r[0] : "(?:" + r.join("|") + ")";
  }
}, K = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakMap(), A = /* @__PURE__ */ new WeakMap(), Je);
var _e;
var we;
var Ve;
var Gt = (Ve = class {
  static {
    __name(this, "Ve");
  }
  static {
    __name2(this, "Ve");
  }
  constructor() {
    g(this, _e, { varIndex: 0 });
    g(this, we, new Pe());
  }
  insert(e, t, r) {
    const s = [], n = [];
    for (let i = 0; ; ) {
      let d = false;
      if (e = e.replace(/\{[^}]+\}/g, (l) => {
        const c = `@\\${i}`;
        return n[i] = [c, l], i++, d = true, c;
      }), !d) break;
    }
    const a = e.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = n.length - 1; i >= 0; i--) {
      const [d] = n[i];
      for (let l = a.length - 1; l >= 0; l--) if (a[l].indexOf(d) !== -1) {
        a[l] = a[l].replace(d, n[i][1]);
        break;
      }
    }
    return o(this, we).insert(a, t, s, o(this, _e), r), s;
  }
  buildRegExp() {
    let e = o(this, we).buildRegExpStr();
    if (e === "") return [/^$/, [], []];
    let t = 0;
    const r = [], s = [];
    return e = e.replace(/#(\d+)|@(\d+)|\.\*\$/g, (n, a, i) => a !== void 0 ? (r[++t] = Number(a), "$()") : (i !== void 0 && (s[Number(i)] = ++t), "")), [new RegExp(`^${e}`), r, s];
  }
}, _e = /* @__PURE__ */ new WeakMap(), we = /* @__PURE__ */ new WeakMap(), Ve);
var Jt = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var je = /* @__PURE__ */ Object.create(null);
function ft(e) {
  return je[e] ?? (je[e] = new RegExp(e === "*" ? "" : `^${e.replace(/\/\*$|([.\\+*[^\]$()])/g, (t, r) => r ? `\\${r}` : "(?:|/.*)")}$`));
}
__name(ft, "ft");
__name2(ft, "ft");
function Vt() {
  je = /* @__PURE__ */ Object.create(null);
}
__name(Vt, "Vt");
__name2(Vt, "Vt");
function Yt(e) {
  var c;
  const t = new Gt(), r = [];
  if (e.length === 0) return Jt;
  const s = e.map((u) => [!/\*|\/:/.test(u[0]), ...u]).sort(([u, p], [m, y]) => u ? 1 : m ? -1 : p.length - y.length), n = /* @__PURE__ */ Object.create(null);
  for (let u = 0, p = -1, m = s.length; u < m; u++) {
    const [y, T, v] = s[u];
    y ? n[T] = [v.map(([_]) => [_, /* @__PURE__ */ Object.create(null)]), pt] : p++;
    let w;
    try {
      w = t.insert(T, p, y);
    } catch (_) {
      throw _ === ne ? new dt(T) : _;
    }
    y || (r[p] = v.map(([_, ee]) => {
      const ce = /* @__PURE__ */ Object.create(null);
      for (ee -= 1; ee >= 0; ee--) {
        const [N, Te] = w[ee];
        ce[N] = Te;
      }
      return [_, ce];
    }));
  }
  const [a, i, d] = t.buildRegExp();
  for (let u = 0, p = r.length; u < p; u++) for (let m = 0, y = r[u].length; m < y; m++) {
    const T = (c = r[u][m]) == null ? void 0 : c[1];
    if (!T) continue;
    const v = Object.keys(T);
    for (let w = 0, _ = v.length; w < _; w++) T[v[w]] = d[T[v[w]]];
  }
  const l = [];
  for (const u in i) l[u] = r[i[u]];
  return [a, l, n];
}
__name(Yt, "Yt");
__name2(Yt, "Yt");
function te(e, t) {
  if (e) {
    for (const r of Object.keys(e).sort((s, n) => n.length - s.length)) if (ft(r).test(t)) return [...e[r]];
  }
}
__name(te, "te");
__name2(te, "te");
var U;
var W;
var Se;
var ht;
var Ye;
var Kt = (Ye = class {
  static {
    __name(this, "Ye");
  }
  static {
    __name2(this, "Ye");
  }
  constructor() {
    g(this, Se);
    h(this, "name", "RegExpRouter");
    g(this, U);
    g(this, W);
    h(this, "match", Ut);
    f(this, U, { [E]: /* @__PURE__ */ Object.create(null) }), f(this, W, { [E]: /* @__PURE__ */ Object.create(null) });
  }
  add(e, t, r) {
    var d;
    const s = o(this, U), n = o(this, W);
    if (!s || !n) throw new Error(lt);
    s[e] || [s, n].forEach((l) => {
      l[e] = /* @__PURE__ */ Object.create(null), Object.keys(l[E]).forEach((c) => {
        l[e][c] = [...l[E][c]];
      });
    }), t === "/*" && (t = "*");
    const a = (t.match(/\/:/g) || []).length;
    if (/\*$/.test(t)) {
      const l = ft(t);
      e === E ? Object.keys(s).forEach((c) => {
        var u;
        (u = s[c])[t] || (u[t] = te(s[c], t) || te(s[E], t) || []);
      }) : (d = s[e])[t] || (d[t] = te(s[e], t) || te(s[E], t) || []), Object.keys(s).forEach((c) => {
        (e === E || e === c) && Object.keys(s[c]).forEach((u) => {
          l.test(u) && s[c][u].push([r, a]);
        });
      }), Object.keys(n).forEach((c) => {
        (e === E || e === c) && Object.keys(n[c]).forEach((u) => l.test(u) && n[c][u].push([r, a]));
      });
      return;
    }
    const i = tt(t) || [t];
    for (let l = 0, c = i.length; l < c; l++) {
      const u = i[l];
      Object.keys(n).forEach((p) => {
        var m;
        (e === E || e === p) && ((m = n[p])[u] || (m[u] = [...te(s[p], u) || te(s[E], u) || []]), n[p][u].push([r, a - c + l + 1]));
      });
    }
  }
  buildAllMatchers() {
    const e = /* @__PURE__ */ Object.create(null);
    return Object.keys(o(this, W)).concat(Object.keys(o(this, U))).forEach((t) => {
      e[t] || (e[t] = b(this, Se, ht).call(this, t));
    }), f(this, U, f(this, W, void 0)), Vt(), e;
  }
}, U = /* @__PURE__ */ new WeakMap(), W = /* @__PURE__ */ new WeakMap(), Se = /* @__PURE__ */ new WeakSet(), ht = /* @__PURE__ */ __name2(function(e) {
  const t = [];
  let r = e === E;
  return [o(this, U), o(this, W)].forEach((s) => {
    const n = s[e] ? Object.keys(s[e]).map((a) => [a, s[e][a]]) : [];
    n.length !== 0 ? (r || (r = true), t.push(...n)) : e !== E && t.push(...Object.keys(s[E]).map((a) => [a, s[E][a]]));
  }), r ? Yt(t) : null;
}, "ht"), Ye);
var z;
var F;
var Ke;
var Xt = (Ke = class {
  static {
    __name(this, "Ke");
  }
  static {
    __name2(this, "Ke");
  }
  constructor(e) {
    h(this, "name", "SmartRouter");
    g(this, z, []);
    g(this, F, []);
    f(this, z, e.routers);
  }
  add(e, t, r) {
    if (!o(this, F)) throw new Error(lt);
    o(this, F).push([e, t, r]);
  }
  match(e, t) {
    if (!o(this, F)) throw new Error("Fatal error");
    const r = o(this, z), s = o(this, F), n = r.length;
    let a = 0, i;
    for (; a < n; a++) {
      const d = r[a];
      try {
        for (let l = 0, c = s.length; l < c; l++) d.add(...s[l]);
        i = d.match(e, t);
      } catch (l) {
        if (l instanceof dt) continue;
        throw l;
      }
      this.match = d.match.bind(d), f(this, z, [d]), f(this, F, void 0);
      break;
    }
    if (a === n) throw new Error("Fatal error");
    return this.name = `SmartRouter + ${this.activeRouter.name}`, i;
  }
  get activeRouter() {
    if (o(this, F) || o(this, z).length !== 1) throw new Error("No active router has been determined yet.");
    return o(this, z)[0];
  }
}, z = /* @__PURE__ */ new WeakMap(), F = /* @__PURE__ */ new WeakMap(), Ke);
var pe = /* @__PURE__ */ Object.create(null);
var G;
var O;
var Q;
var de;
var j;
var M;
var V;
var Xe;
var mt = (Xe = class {
  static {
    __name(this, "Xe");
  }
  static {
    __name2(this, "Xe");
  }
  constructor(e, t, r) {
    g(this, M);
    g(this, G);
    g(this, O);
    g(this, Q);
    g(this, de, 0);
    g(this, j, pe);
    if (f(this, O, r || /* @__PURE__ */ Object.create(null)), f(this, G, []), e && t) {
      const s = /* @__PURE__ */ Object.create(null);
      s[e] = { handler: t, possibleKeys: [], score: 0 }, f(this, G, [s]);
    }
    f(this, Q, []);
  }
  insert(e, t, r) {
    f(this, de, ++Me(this, de)._);
    let s = this;
    const n = Tt(t), a = [];
    for (let i = 0, d = n.length; i < d; i++) {
      const l = n[i], c = n[i + 1], u = It(l, c), p = Array.isArray(u) ? u[0] : l;
      if (p in o(s, O)) {
        s = o(s, O)[p], u && a.push(u[1]);
        continue;
      }
      o(s, O)[p] = new mt(), u && (o(s, Q).push(u), a.push(u[1])), s = o(s, O)[p];
    }
    return o(s, G).push({ [e]: { handler: r, possibleKeys: a.filter((i, d, l) => l.indexOf(i) === d), score: o(this, de) } }), s;
  }
  search(e, t) {
    var d;
    const r = [];
    f(this, j, pe);
    let n = [this];
    const a = Ze(t), i = [];
    for (let l = 0, c = a.length; l < c; l++) {
      const u = a[l], p = l === c - 1, m = [];
      for (let y = 0, T = n.length; y < T; y++) {
        const v = n[y], w = o(v, O)[u];
        w && (f(w, j, o(v, j)), p ? (o(w, O)["*"] && r.push(...b(this, M, V).call(this, o(w, O)["*"], e, o(v, j))), r.push(...b(this, M, V).call(this, w, e, o(v, j)))) : m.push(w));
        for (let _ = 0, ee = o(v, Q).length; _ < ee; _++) {
          const ce = o(v, Q)[_], N = o(v, j) === pe ? {} : { ...o(v, j) };
          if (ce === "*") {
            const B = o(v, O)["*"];
            B && (r.push(...b(this, M, V).call(this, B, e, o(v, j))), f(B, j, N), m.push(B));
            continue;
          }
          const [Te, He, ue] = ce;
          if (!u && !(ue instanceof RegExp)) continue;
          const P = o(v, O)[Te], vt = a.slice(l).join("/");
          if (ue instanceof RegExp) {
            const B = ue.exec(vt);
            if (B) {
              if (N[He] = B[0], r.push(...b(this, M, V).call(this, P, e, o(v, j), N)), Object.keys(o(P, O)).length) {
                f(P, j, N);
                const Ce = ((d = B[0].match(/\//)) == null ? void 0 : d.length) ?? 0;
                (i[Ce] || (i[Ce] = [])).push(P);
              }
              continue;
            }
          }
          (ue === true || ue.test(u)) && (N[He] = u, p ? (r.push(...b(this, M, V).call(this, P, e, N, o(v, j))), o(P, O)["*"] && r.push(...b(this, M, V).call(this, o(P, O)["*"], e, N, o(v, j)))) : (f(P, j, N), m.push(P)));
        }
      }
      n = m.concat(i.shift() ?? []);
    }
    return r.length > 1 && r.sort((l, c) => l.score - c.score), [r.map(({ handler: l, params: c }) => [l, c])];
  }
}, G = /* @__PURE__ */ new WeakMap(), O = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ new WeakMap(), de = /* @__PURE__ */ new WeakMap(), j = /* @__PURE__ */ new WeakMap(), M = /* @__PURE__ */ new WeakSet(), V = /* @__PURE__ */ __name2(function(e, t, r, s) {
  const n = [];
  for (let a = 0, i = o(e, G).length; a < i; a++) {
    const d = o(e, G)[a], l = d[t] || d[E], c = {};
    if (l !== void 0 && (l.params = /* @__PURE__ */ Object.create(null), n.push(l), r !== pe || s && s !== pe)) for (let u = 0, p = l.possibleKeys.length; u < p; u++) {
      const m = l.possibleKeys[u], y = c[l.score];
      l.params[m] = s != null && s[m] && !y ? s[m] : r[m] ?? (s == null ? void 0 : s[m]), c[l.score] = true;
    }
  }
  return n;
}, "V"), Xe);
var Z;
var Qe;
var Qt = (Qe = class {
  static {
    __name(this, "Qe");
  }
  static {
    __name2(this, "Qe");
  }
  constructor() {
    h(this, "name", "TrieRouter");
    g(this, Z);
    f(this, Z, new mt());
  }
  add(e, t, r) {
    const s = tt(t);
    if (s) {
      for (let n = 0, a = s.length; n < a; n++) o(this, Z).insert(e, s[n], r);
      return;
    }
    o(this, Z).insert(e, t, r);
  }
  match(e, t) {
    return o(this, Z).search(e, t);
  }
}, Z = /* @__PURE__ */ new WeakMap(), Qe);
var gt = class extends ct {
  static {
    __name(this, "gt");
  }
  static {
    __name2(this, "gt");
  }
  constructor(e = {}) {
    super(e), this.router = e.router ?? new Xt({ routers: [new Kt(), new Qt()] });
  }
};
var Zt = /* @__PURE__ */ __name2((e) => {
  const r = { ...{ origin: "*", allowMethods: ["GET", "HEAD", "PUT", "POST", "DELETE", "PATCH"], allowHeaders: [], exposeHeaders: [] }, ...e }, s = /* @__PURE__ */ ((a) => typeof a == "string" ? a === "*" ? () => a : (i) => a === i ? i : null : typeof a == "function" ? a : (i) => a.includes(i) ? i : null)(r.origin), n = ((a) => typeof a == "function" ? a : Array.isArray(a) ? () => a : () => [])(r.allowMethods);
  return async function(i, d) {
    var u;
    function l(p, m) {
      i.res.headers.set(p, m);
    }
    __name(l, "l");
    __name2(l, "l");
    const c = await s(i.req.header("origin") || "", i);
    if (c && l("Access-Control-Allow-Origin", c), r.credentials && l("Access-Control-Allow-Credentials", "true"), (u = r.exposeHeaders) != null && u.length && l("Access-Control-Expose-Headers", r.exposeHeaders.join(",")), i.req.method === "OPTIONS") {
      r.origin !== "*" && l("Vary", "Origin"), r.maxAge != null && l("Access-Control-Max-Age", r.maxAge.toString());
      const p = await n(i.req.header("origin") || "", i);
      p.length && l("Access-Control-Allow-Methods", p.join(","));
      let m = r.allowHeaders;
      if (!(m != null && m.length)) {
        const y = i.req.header("Access-Control-Request-Headers");
        y && (m = y.split(/\s*,\s*/));
      }
      return m != null && m.length && (l("Access-Control-Allow-Headers", m.join(",")), i.res.headers.append("Vary", "Access-Control-Request-Headers")), i.res.headers.delete("Content-Length"), i.res.headers.delete("Content-Type"), new Response(null, { headers: i.res.headers, status: 204, statusText: "No Content" });
    }
    await d(), r.origin !== "*" && i.header("Vary", "Origin", { append: true });
  };
}, "Zt");
var er = /^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i;
var $e = /* @__PURE__ */ __name2((e, t = rr) => {
  const r = /\.([a-zA-Z0-9]+?)$/, s = e.match(r);
  if (!s) return;
  let n = t[s[1]];
  return n && n.startsWith("text") && (n += "; charset=utf-8"), n;
}, "$e");
var tr = { aac: "audio/aac", avi: "video/x-msvideo", avif: "image/avif", av1: "video/av1", bin: "application/octet-stream", bmp: "image/bmp", css: "text/css", csv: "text/csv", eot: "application/vnd.ms-fontobject", epub: "application/epub+zip", gif: "image/gif", gz: "application/gzip", htm: "text/html", html: "text/html", ico: "image/x-icon", ics: "text/calendar", jpeg: "image/jpeg", jpg: "image/jpeg", js: "text/javascript", json: "application/json", jsonld: "application/ld+json", map: "application/json", mid: "audio/x-midi", midi: "audio/x-midi", mjs: "text/javascript", mp3: "audio/mpeg", mp4: "video/mp4", mpeg: "video/mpeg", oga: "audio/ogg", ogv: "video/ogg", ogx: "application/ogg", opus: "audio/opus", otf: "font/otf", pdf: "application/pdf", png: "image/png", rtf: "application/rtf", svg: "image/svg+xml", tif: "image/tiff", tiff: "image/tiff", ts: "video/mp2t", ttf: "font/ttf", txt: "text/plain", wasm: "application/wasm", webm: "video/webm", weba: "audio/webm", webmanifest: "application/manifest+json", webp: "image/webp", woff: "font/woff", woff2: "font/woff2", xhtml: "application/xhtml+xml", xml: "application/xml", zip: "application/zip", "3gp": "video/3gpp", "3g2": "video/3gpp2", gltf: "model/gltf+json", glb: "model/gltf-binary" };
var rr = tr;
var sr = /* @__PURE__ */ __name2((...e) => {
  let t = e.filter((n) => n !== "").join("/");
  t = t.replace(new RegExp("(?<=\\/)\\/+", "g"), "");
  const r = t.split("/"), s = [];
  for (const n of r) n === ".." && s.length > 0 && s.at(-1) !== ".." ? s.pop() : n !== "." && s.push(n);
  return s.join("/") || ".";
}, "sr");
var bt = { br: ".br", zstd: ".zst", gzip: ".gz" };
var nr = Object.keys(bt);
var ar = "index.html";
var ir = /* @__PURE__ */ __name2((e) => {
  const t = e.root ?? "./", r = e.path, s = e.join ?? sr;
  return async (n, a) => {
    var u, p, m, y;
    if (n.finalized) return a();
    let i;
    if (e.path) i = e.path;
    else try {
      if (i = decodeURIComponent(n.req.path), /(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(i)) throw new Error();
    } catch {
      return await ((u = e.onNotFound) == null ? void 0 : u.call(e, n.req.path, n)), a();
    }
    let d = s(t, !r && e.rewriteRequestPath ? e.rewriteRequestPath(i) : i);
    e.isDir && await e.isDir(d) && (d = s(d, ar));
    const l = e.getContent;
    let c = await l(d, n);
    if (c instanceof Response) return n.newResponse(c.body, c);
    if (c) {
      const T = e.mimes && $e(d, e.mimes) || $e(d);
      if (n.header("Content-Type", T || "application/octet-stream"), e.precompressed && (!T || er.test(T))) {
        const v = new Set((p = n.req.header("Accept-Encoding")) == null ? void 0 : p.split(",").map((w) => w.trim()));
        for (const w of nr) {
          if (!v.has(w)) continue;
          const _ = await l(d + bt[w], n);
          if (_) {
            c = _, n.header("Content-Encoding", w), n.header("Vary", "Accept-Encoding", { append: true });
            break;
          }
        }
      }
      return await ((m = e.onFound) == null ? void 0 : m.call(e, d, n)), n.body(c);
    }
    await ((y = e.onNotFound) == null ? void 0 : y.call(e, d, n)), await a();
  };
}, "ir");
var or = /* @__PURE__ */ __name2(async (e, t) => {
  let r;
  t && t.manifest ? typeof t.manifest == "string" ? r = JSON.parse(t.manifest) : r = t.manifest : typeof __STATIC_CONTENT_MANIFEST == "string" ? r = JSON.parse(__STATIC_CONTENT_MANIFEST) : r = __STATIC_CONTENT_MANIFEST;
  let s;
  t && t.namespace ? s = t.namespace : s = __STATIC_CONTENT;
  const n = r[e] || e;
  if (!n) return null;
  const a = await s.get(n, { type: "stream" });
  return a || null;
}, "or");
var lr = /* @__PURE__ */ __name2((e) => async function(r, s) {
  return ir({ ...e, getContent: /* @__PURE__ */ __name2(async (a) => or(a, { manifest: e.manifest, namespace: e.namespace ? e.namespace : r.env ? r.env.__STATIC_CONTENT : void 0 }), "getContent") })(r, s);
}, "lr");
var dr = /* @__PURE__ */ __name2((e) => lr(e), "dr");
var x = new gt();
x.use("/api/*", Zt());
x.use("/static/*", dr({ root: "./public" }));
x.post("/api/auth/register", async (e) => {
  try {
    const { email: t, password: r, full_name: s, role: n } = await e.req.json();
    if (!t || !r || !s || !n) return e.json({ error: "All fields are required" }, 400);
    if (!["admin", "doctor", "patient"].includes(n)) return e.json({ error: "Invalid role" }, 400);
    if (await e.env.DB.prepare("SELECT id FROM users WHERE email = ?").bind(t).first()) return e.json({ error: "Email already registered" }, 400);
    const d = (await e.env.DB.prepare("INSERT INTO users (email, password, full_name, role) VALUES (?, ?, ?, ?)").bind(t, r, s, n).run()).meta.last_row_id;
    if (n === "patient") await e.env.DB.prepare("INSERT INTO patients (user_id) VALUES (?)").bind(d).run();
    else if (n === "doctor") return e.json({ message: "Doctor account created. Please complete your profile.", userId: d, requiresProfile: true }, 201);
    return e.json({ message: "Registration successful", userId: d, role: n }, 201);
  } catch (t) {
    return console.error("Registration error:", t), e.json({ error: "Registration failed" }, 500);
  }
});
x.post("/api/auth/login", async (e) => {
  try {
    const { email: t, password: r } = await e.req.json();
    if (!t || !r) return e.json({ error: "Email and password required" }, 400);
    const s = await e.env.DB.prepare("SELECT * FROM users WHERE email = ? AND password = ?").bind(t, r).first();
    return s ? e.json({ message: "Login successful", user: { id: s.id, email: s.email, full_name: s.full_name, role: s.role } }) : e.json({ error: "Invalid credentials" }, 401);
  } catch (t) {
    return console.error("Login error:", t), e.json({ error: "Login failed" }, 500);
  }
});
x.put("/api/patients/:userId", async (e) => {
  try {
    const t = e.req.param("userId"), r = await e.req.json(), { gender: s, blood_group: n, date_of_birth: a, phone: i, address: d, emergency_contact: l, allergies: c, chronic_conditions: u } = r;
    return await e.env.DB.prepare("SELECT id FROM patients WHERE user_id = ?").bind(t).first() ? await e.env.DB.prepare(`
        UPDATE patients 
        SET gender = ?, blood_group = ?, date_of_birth = ?, phone = ?, 
            address = ?, emergency_contact = ?, allergies = ?, chronic_conditions = ?
        WHERE user_id = ?
      `).bind(s, n, a, i, d, l, c, u, t).run() : await e.env.DB.prepare(`
        INSERT INTO patients (user_id, gender, blood_group, date_of_birth, phone, address, emergency_contact, allergies, chronic_conditions)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(t, s, n, a, i, d, l, c, u).run(), e.json({ message: "Profile updated successfully" });
  } catch (t) {
    return console.error("Update profile error:", t), e.json({ error: "Failed to update profile" }, 500);
  }
});
x.get("/api/patients/:userId", async (e) => {
  try {
    const t = e.req.param("userId"), r = await e.env.DB.prepare(`
      SELECT p.*, u.full_name, u.email 
      FROM patients p
      JOIN users u ON p.user_id = u.id
      WHERE p.user_id = ?
    `).bind(t).first();
    return r ? e.json(r) : e.json({ error: "Patient not found" }, 404);
  } catch (t) {
    return console.error("Get patient error:", t), e.json({ error: "Failed to get patient" }, 500);
  }
});
x.get("/api/patients/:userId/history", async (e) => {
  try {
    const t = e.req.param("userId"), r = await e.env.DB.prepare("SELECT id FROM patients WHERE user_id = ?").bind(t).first();
    if (!r) return e.json({ error: "Patient not found" }, 404);
    const s = await e.env.DB.prepare(`
      SELECT mh.*, d.name as disease_name, u.full_name as doctor_name
      FROM medical_history mh
      LEFT JOIN diseases d ON mh.disease_id = d.id
      LEFT JOIN doctors doc ON mh.diagnosed_by = doc.id
      LEFT JOIN users u ON doc.user_id = u.id
      WHERE mh.patient_id = ?
      ORDER BY mh.diagnosis_date DESC
    `).bind(r.id).all();
    return e.json(s.results);
  } catch (t) {
    return console.error("Get history error:", t), e.json({ error: "Failed to get medical history" }, 500);
  }
});
x.post("/api/patients/:userId/history", async (e) => {
  try {
    const t = e.req.param("userId"), { disease_name: r, diagnosis_date: s, status: n, notes: a } = await e.req.json(), i = await e.env.DB.prepare("SELECT id FROM patients WHERE user_id = ?").bind(t).first();
    return i ? (await e.env.DB.prepare(`
      INSERT INTO medical_history (patient_id, disease_name, diagnosis_date, status, notes)
      VALUES (?, ?, ?, ?, ?)
    `).bind(i.id, r, s, n, a).run(), e.json({ message: "Medical history added successfully" }, 201)) : e.json({ error: "Patient not found" }, 404);
  } catch (t) {
    return console.error("Add history error:", t), e.json({ error: "Failed to add medical history" }, 500);
  }
});
x.post("/api/doctors/profile", async (e) => {
  try {
    const { userId: t, specialization: r, license_number: s, phone: n, years_of_experience: a, qualification: i, consultation_fee: d } = await e.req.json();
    return await e.env.DB.prepare("SELECT id FROM doctors WHERE user_id = ?").bind(t).first() ? e.json({ error: "Doctor profile already exists" }, 400) : (await e.env.DB.prepare(`
      INSERT INTO doctors (user_id, specialization, license_number, phone, years_of_experience, qualification, consultation_fee)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(t, r, s, n, a, i, d).run(), e.json({ message: "Doctor profile completed" }, 201));
  } catch (t) {
    return console.error("Complete doctor profile error:", t), e.json({ error: "Failed to complete profile" }, 500);
  }
});
x.get("/api/doctors", async (e) => {
  try {
    const t = await e.env.DB.prepare(`
      SELECT d.*, u.full_name, u.email 
      FROM doctors d
      JOIN users u ON d.user_id = u.id
      ORDER BY u.full_name
    `).all();
    return e.json(t.results);
  } catch (t) {
    return console.error("Get doctors error:", t), e.json({ error: "Failed to get doctors" }, 500);
  }
});
x.get("/api/doctors/:userId/patients", async (e) => {
  try {
    const t = e.req.param("userId"), r = await e.env.DB.prepare("SELECT id FROM doctors WHERE user_id = ?").bind(t).first();
    if (!r) return e.json({ error: "Doctor not found" }, 404);
    const s = await e.env.DB.prepare(`
      SELECT DISTINCT p.*, u.full_name, u.email
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      JOIN users u ON p.user_id = u.id
      WHERE a.doctor_id = ?
      ORDER BY u.full_name
    `).bind(r.id).all();
    return e.json(s.results);
  } catch (t) {
    return console.error("Get doctor patients error:", t), e.json({ error: "Failed to get patients" }, 500);
  }
});
x.post("/api/appointments", async (e) => {
  try {
    const { patientUserId: t, doctorId: r, appointment_date: s, appointment_time: n, reason: a } = await e.req.json(), i = await e.env.DB.prepare("SELECT id FROM patients WHERE user_id = ?").bind(t).first();
    return i ? (await e.env.DB.prepare(`
      INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status)
      VALUES (?, ?, ?, ?, ?, 'scheduled')
    `).bind(i.id, r, s, n, a).run(), e.json({ message: "Appointment scheduled successfully" }, 201)) : e.json({ error: "Patient not found" }, 404);
  } catch (t) {
    return console.error("Create appointment error:", t), e.json({ error: "Failed to create appointment" }, 500);
  }
});
x.get("/api/appointments/patient/:userId", async (e) => {
  try {
    const t = e.req.param("userId"), r = await e.env.DB.prepare("SELECT id FROM patients WHERE user_id = ?").bind(t).first();
    if (!r) return e.json({ error: "Patient not found" }, 404);
    const s = await e.env.DB.prepare(`
      SELECT a.*, u.full_name as doctor_name, d.specialization
      FROM appointments a
      JOIN doctors d ON a.doctor_id = d.id
      JOIN users u ON d.user_id = u.id
      WHERE a.patient_id = ?
      ORDER BY a.appointment_date DESC, a.appointment_time DESC
    `).bind(r.id).all();
    return e.json(s.results);
  } catch (t) {
    return console.error("Get appointments error:", t), e.json({ error: "Failed to get appointments" }, 500);
  }
});
x.get("/api/appointments/doctor/:userId", async (e) => {
  try {
    const t = e.req.param("userId"), r = await e.env.DB.prepare("SELECT id FROM doctors WHERE user_id = ?").bind(t).first();
    if (!r) return e.json({ error: "Doctor not found" }, 404);
    const s = await e.env.DB.prepare(`
      SELECT a.*, u.full_name as patient_name, p.phone, p.blood_group
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      JOIN users u ON p.user_id = u.id
      WHERE a.doctor_id = ?
      ORDER BY a.appointment_date DESC, a.appointment_time DESC
    `).bind(r.id).all();
    return e.json(s.results);
  } catch (t) {
    return console.error("Get doctor appointments error:", t), e.json({ error: "Failed to get appointments" }, 500);
  }
});
x.put("/api/appointments/:id", async (e) => {
  try {
    const t = e.req.param("id"), { status: r, notes: s } = await e.req.json();
    return await e.env.DB.prepare(`
      UPDATE appointments 
      SET status = ?, notes = ?
      WHERE id = ?
    `).bind(r, s, t).run(), e.json({ message: "Appointment updated successfully" });
  } catch (t) {
    return console.error("Update appointment error:", t), e.json({ error: "Failed to update appointment" }, 500);
  }
});
x.post("/api/prescriptions", async (e) => {
  try {
    const { patientUserId: t, doctorUserId: r, diagnosis: s, medications: n, instructions: a, valid_until: i, appointment_id: d } = await e.req.json(), l = await e.env.DB.prepare("SELECT id FROM patients WHERE user_id = ?").bind(t).first(), c = await e.env.DB.prepare("SELECT id FROM doctors WHERE user_id = ?").bind(r).first();
    return !l || !c ? e.json({ error: "Patient or doctor not found" }, 404) : (await e.env.DB.prepare(`
      INSERT INTO prescriptions (patient_id, doctor_id, appointment_id, diagnosis, medications, instructions, valid_until)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(l.id, c.id, d, s, JSON.stringify(n), a, i).run(), e.json({ message: "Prescription created successfully" }, 201));
  } catch (t) {
    return console.error("Create prescription error:", t), e.json({ error: "Failed to create prescription" }, 500);
  }
});
x.get("/api/prescriptions/patient/:userId", async (e) => {
  try {
    const t = e.req.param("userId"), r = await e.env.DB.prepare("SELECT id FROM patients WHERE user_id = ?").bind(t).first();
    if (!r) return e.json({ error: "Patient not found" }, 404);
    const s = await e.env.DB.prepare(`
      SELECT p.*, u.full_name as doctor_name, d.specialization
      FROM prescriptions p
      JOIN doctors d ON p.doctor_id = d.id
      JOIN users u ON d.user_id = u.id
      WHERE p.patient_id = ?
      ORDER BY p.prescription_date DESC
    `).bind(r.id).all();
    return e.json(s.results);
  } catch (t) {
    return console.error("Get prescriptions error:", t), e.json({ error: "Failed to get prescriptions" }, 500);
  }
});
x.get("/api/diseases", async (e) => {
  try {
    const t = await e.env.DB.prepare(`
      SELECT * FROM diseases 
      ORDER BY category, name
    `).all();
    return e.json(t.results);
  } catch (t) {
    return console.error("Get diseases error:", t), e.json({ error: "Failed to get diseases" }, 500);
  }
});
x.post("/api/diseases/search", async (e) => {
  try {
    const { symptoms: t } = await e.req.json();
    if (!t || t.length === 0) return e.json({ error: "Symptoms required" }, 400);
    const r = `%${t.join("%")}%`, s = await e.env.DB.prepare(`
      SELECT * FROM diseases 
      WHERE symptoms LIKE ?
      ORDER BY severity DESC
      LIMIT 20
    `).bind(r).all();
    return e.json(s.results);
  } catch (t) {
    return console.error("Search diseases error:", t), e.json({ error: "Failed to search diseases" }, 500);
  }
});
x.get("/api/diseases/:id", async (e) => {
  try {
    const t = e.req.param("id"), r = await e.env.DB.prepare("SELECT * FROM diseases WHERE id = ?").bind(t).first();
    return r ? e.json(r) : e.json({ error: "Disease not found" }, 404);
  } catch (t) {
    return console.error("Get disease error:", t), e.json({ error: "Failed to get disease" }, 500);
  }
});
x.post("/api/ai/chat", async (e) => {
  try {
    const { message: t, conversationHistory: r } = await e.req.json();
    if (!t) return e.json({ error: "Message required" }, 400);
    let s = `You are a helpful medical AI assistant for HEALNEX health platform. 
    Provide accurate, helpful medical information while always recommending users consult 
    with healthcare professionals for serious concerns. Be empathetic and clear.
    
    User message: ${t}`;
    const n = await e.env.AI.run("@cf/meta/llama-3-8b-instruct", { messages: [{ role: "system", content: s }, { role: "user", content: t }] });
    return e.json({ response: n.response, timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  } catch (t) {
    return console.error("AI chat error:", t), e.json({ error: "AI service unavailable" }, 500);
  }
});
x.get("/api/admin/users", async (e) => {
  try {
    const t = await e.env.DB.prepare(`
      SELECT id, email, full_name, role, created_at 
      FROM users 
      ORDER BY created_at DESC
    `).all();
    return e.json(t.results);
  } catch (t) {
    return console.error("Get users error:", t), e.json({ error: "Failed to get users" }, 500);
  }
});
x.get("/api/admin/stats", async (e) => {
  try {
    const t = await e.env.DB.prepare("SELECT COUNT(*) as count FROM users").first(), r = await e.env.DB.prepare("SELECT COUNT(*) as count FROM patients").first(), s = await e.env.DB.prepare("SELECT COUNT(*) as count FROM doctors").first(), n = await e.env.DB.prepare("SELECT COUNT(*) as count FROM appointments").first(), a = await e.env.DB.prepare("SELECT COUNT(*) as count FROM diseases").first();
    return e.json({ totalUsers: (t == null ? void 0 : t.count) || 0, totalPatients: (r == null ? void 0 : r.count) || 0, totalDoctors: (s == null ? void 0 : s.count) || 0, totalAppointments: (n == null ? void 0 : n.count) || 0, totalDiseases: (a == null ? void 0 : a.count) || 0 });
  } catch (t) {
    return console.error("Get stats error:", t), e.json({ error: "Failed to get statistics" }, 500);
  }
});
x.get("/", (e) => e.html(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HEALNEX - Healthcare Data Management Platform</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Rajdhani', sans-serif;
            background: #000000;
            color: #ffffff;
            overflow-x: hidden;
        }
        
        #bg-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        
        .content {
            position: relative;
            z-index: 1;
        }
        
        .neon-text {
            font-family: 'Orbitron', sans-serif;
            text-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff, 0 0 40px #00ffff;
            animation: neon-pulse 1.5s ease-in-out infinite alternate;
        }
        
        @keyframes neon-pulse {
            from { text-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff; }
            to { text-shadow: 0 0 20px #00ffff, 0 0 30px #00ffff, 0 0 40px #00ffff, 0 0 50px #00ffff; }
        }
        
        .glass-card {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(0, 255, 255, 0.3);
            border-radius: 15px;
            box-shadow: 0 8px 32px 0 rgba(0, 255, 255, 0.2);
        }
        
        .btn-neon {
            background: linear-gradient(45deg, #00ffff, #ff00ff);
            border: none;
            color: #000;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
        }
        
        .btn-neon:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px #00ffff, 0 0 40px #ff00ff;
        }
        
        .btn-neon::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .btn-neon:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .feature-card {
            background: linear-gradient(135deg, rgba(0, 255, 255, 0.1), rgba(255, 0, 255, 0.1));
            border: 2px solid transparent;
            background-clip: padding-box;
            position: relative;
            transition: all 0.3s;
        }
        
        .feature-card::before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, #00ffff, #ff00ff, #00ff00, #ffff00);
            border-radius: 15px;
            z-index: -1;
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .feature-card:hover::before {
            opacity: 1;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
        }
        
        input, select, textarea {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(0, 255, 255, 0.5);
            color: #fff;
            transition: all 0.3s;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #00ffff;
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .chat-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 999;
        }
        
        .chat-button {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(45deg, #00ffff, #ff00ff);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.5);
            transition: all 0.3s;
        }
        
        .chat-button:hover {
            transform: scale(1.1);
            box-shadow: 0 0 30px rgba(0, 255, 255, 0.8);
        }
        
        .chat-window {
            display: none;
            position: absolute;
            bottom: 80px;
            right: 0;
            width: 350px;
            height: 500px;
            background: rgba(0, 0, 0, 0.95);
            border: 2px solid #00ffff;
            border-radius: 15px;
            flex-direction: column;
        }
        
        .chat-window.active {
            display: flex;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        .message {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 10px;
        }
        
        .message.user {
            background: linear-gradient(45deg, #00ffff, #0080ff);
            margin-left: 20%;
        }
        
        .message.ai {
            background: linear-gradient(45deg, #ff00ff, #ff0080);
            margin-right: 20%;
        }
        
        .hidden {
            display: none !important;
        }
        
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 255, 255, 0.3);
        }
        
        .dashboard-nav {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .nav-btn {
            padding: 10px 20px;
            background: rgba(0, 255, 255, 0.1);
            border: 1px solid #00ffff;
            color: #00ffff;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .nav-btn:hover, .nav-btn.active {
            background: #00ffff;
            color: #000;
        }
        
        .data-table {
            width: 100%;
            background: rgba(0, 0, 0, 0.5);
            border-collapse: collapse;
        }
        
        .data-table th, .data-table td {
            padding: 12px;
            border: 1px solid rgba(0, 255, 255, 0.3);
            text-align: left;
        }
        
        .data-table th {
            background: rgba(0, 255, 255, 0.2);
            font-weight: 700;
            text-transform: uppercase;
        }
        
        .data-table tr:hover {
            background: rgba(0, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    
    <div class="content">
        <!-- Navbar -->
        <nav class="navbar fixed top-0 w-full z-50 px-6 py-4">
            <div class="container mx-auto flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-heartbeat text-3xl" style="color: #00ffff;"></i>
                    <h1 class="text-2xl font-bold neon-text">HEALNEX</h1>
                    <span class="text-sm" style="color: #ff00ff;">by QUADXTITAN</span>
                </div>
                <div id="nav-menu" class="hidden md:flex space-x-6">
                    <button onclick="showHome()" class="hover:text-cyan-400 transition">Home</button>
                    <button onclick="showFeatures()" class="hover:text-cyan-400 transition">Features</button>
                    <button onclick="showLogin()" class="hover:text-cyan-400 transition">Login</button>
                    <button onclick="showRegister()" class="btn-neon px-6 py-2 rounded-full">Get Started</button>
                </div>
                <div id="user-menu" class="hidden space-x-4">
                    <span id="user-name" class="text-cyan-400"></span>
                    <button onclick="logout()" class="hover:text-red-400 transition">Logout</button>
                </div>
            </div>
        </nav>
        
        <!-- Home Page -->
        <div id="home-page" class="min-h-screen flex items-center justify-center px-6 pt-20">
            <div class="text-center max-w-5xl">
                <h1 class="text-6xl md:text-8xl font-bold neon-text mb-6">HEALNEX</h1>
                <p class="text-xl md:text-3xl mb-4" style="color: #00ffff;">Healthcare Data Management Platform</p>
                <p class="text-lg md:text-xl mb-8" style="color: #ff00ff;">by QUADXTITAN</p>
                <p class="text-lg mb-12 max-w-3xl mx-auto">
                    Tackling healthcare data fragmentation with innovative solutions. 
                    Access your complete health records, connect with doctors, and take control of your healthcare journey.
                </p>
                <div class="flex gap-4 justify-center flex-wrap">
                    <button onclick="showRegister()" class="btn-neon px-8 py-4 rounded-full text-lg">
                        Start Your Journey <i class="fas fa-arrow-right ml-2"></i>
                    </button>
                    <button onclick="showFeatures()" class="px-8 py-4 rounded-full text-lg border-2 border-cyan-400 hover:bg-cyan-400 hover:text-black transition">
                        Learn More
                    </button>
                </div>
                
                <!-- Features Grid -->
                <div id="features-section" class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
                    <div class="feature-card glass-card p-6 rounded-xl">
                        <i class="fas fa-user-md text-5xl mb-4" style="color: #00ffff;"></i>
                        <h3 class="text-xl font-bold mb-2">Patient Dashboard</h3>
                        <p>Complete health records, appointments, and prescriptions in one place</p>
                    </div>
                    <div class="feature-card glass-card p-6 rounded-xl">
                        <i class="fas fa-stethoscope text-5xl mb-4" style="color: #ff00ff;"></i>
                        <h3 class="text-xl font-bold mb-2">Doctor Portal</h3>
                        <p>Manage patients, diagnose conditions, and prescribe treatments efficiently</p>
                    </div>
                    <div class="feature-card glass-card p-6 rounded-xl">
                        <i class="fas fa-database text-5xl mb-4" style="color: #00ff00;"></i>
                        <h3 class="text-xl font-bold mb-2">Disease Database</h3>
                        <p>Comprehensive database of diseases with symptoms, treatments, and prevention</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Login Modal -->
        <div id="login-modal" class="modal">
            <div class="glass-card p-8 rounded-xl max-w-md w-full mx-4">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-3xl font-bold neon-text">Login</h2>
                    <button onclick="closeModal('login-modal')" class="text-3xl hover:text-red-400">&times;</button>
                </div>
                <form id="login-form" onsubmit="handleLogin(event)">
                    <div class="mb-4">
                        <label class="block mb-2">Email</label>
                        <input type="email" id="login-email" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-6">
                        <label class="block mb-2">Password</label>
                        <input type="password" id="login-password" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <button type="submit" class="btn-neon w-full py-3 rounded-lg">
                        <span id="login-btn-text">Login</span>
                        <span id="login-loading" class="loading hidden"></span>
                    </button>
                </form>
                <p class="mt-4 text-center">
                    Don't have an account? 
                    <button onclick="closeModal('login-modal'); showRegister()" class="text-cyan-400 hover:underline">Register</button>
                </p>
            </div>
        </div>
        
        <!-- Register Modal -->
        <div id="register-modal" class="modal">
            <div class="glass-card p-8 rounded-xl max-w-md w-full mx-4">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-3xl font-bold neon-text">Register</h2>
                    <button onclick="closeModal('register-modal')" class="text-3xl hover:text-red-400">&times;</button>
                </div>
                <form id="register-form" onsubmit="handleRegister(event)">
                    <div class="mb-4">
                        <label class="block mb-2">Full Name</label>
                        <input type="text" id="reg-name" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-4">
                        <label class="block mb-2">Email</label>
                        <input type="email" id="reg-email" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-4">
                        <label class="block mb-2">Password</label>
                        <input type="password" id="reg-password" required class="w-full px-4 py-3 rounded-lg">
                    </div>
                    <div class="mb-6">
                        <label class="block mb-2">I am a...</label>
                        <select id="reg-role" required class="w-full px-4 py-3 rounded-lg">
                            <option value="">Select Role</option>
                            <option value="patient">Patient</option>
                            <option value="doctor">Doctor</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-neon w-full py-3 rounded-lg">
                        <span id="register-btn-text">Register</span>
                        <span id="register-loading" class="loading hidden"></span>
                    </button>
                </form>
                <p class="mt-4 text-center">
                    Already have an account? 
                    <button onclick="closeModal('register-modal'); showLogin()" class="text-cyan-400 hover:underline">Login</button>
                </p>
            </div>
        </div>
        
        <!-- Dashboard (hidden initially) -->
        <div id="dashboard" class="hidden min-h-screen px-6 pt-24 pb-20">
            <div class="container mx-auto max-w-7xl">
                <div class="glass-card p-8 rounded-xl mb-6">
                    <h2 class="text-4xl font-bold neon-text mb-2">Dashboard</h2>
                    <p id="welcome-message"></p>
                </div>
                
                <!-- Dashboard content will be loaded dynamically -->
                <div id="dashboard-content"></div>
            </div>
        </div>
    </div>
    
    <!-- AI Chat Bot -->
    <div class="chat-container">
        <div class="chat-window" id="chat-window">
            <div class="p-4 border-b border-cyan-400">
                <h3 class="font-bold">HEALNEX AI Assistant</h3>
                <p class="text-sm opacity-75">Powered by Cloudflare AI</p>
            </div>
            <div class="chat-messages" id="chat-messages">
                <div class="message ai">
                    <p>Hello! I'm your HEALNEX AI health assistant. How can I help you today?</p>
                </div>
            </div>
            <div class="p-4 border-t border-cyan-400">
                <form onsubmit="sendChatMessage(event)" class="flex gap-2">
                    <input type="text" id="chat-input" placeholder="Ask me anything..." 
                           class="flex-1 px-4 py-2 rounded-lg">
                    <button type="submit" class="btn-neon px-4 py-2 rounded-lg">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
            </div>
        </div>
        <div class="chat-button" onclick="toggleChat()">
            <i class="fas fa-robot text-2xl text-white"></i>
        </div>
    </div>
    
    <script src="/static/app.js"><\/script>
</body>
</html>
  `));
var Ue = new gt();
var cr = Object.assign({ "/src/index.tsx": x });
var xt = false;
for (const [, e] of Object.entries(cr)) e && (Ue.all("*", (t) => {
  let r;
  try {
    r = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, r);
}), Ue.notFound((t) => {
  let r;
  try {
    r = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, r);
}), xt = true);
if (!xt) throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");
var drainBody = /* @__PURE__ */ __name2(async (request, env22, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env22);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
__name2(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name2(async (request, env22, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env22);
  } catch (e) {
    const error32 = reduceError(e);
    return Response.json(error32, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = Ue;
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
__name2(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env22, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env22, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
__name2(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env22, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env22, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");
__name2(__facade_invoke__, "__facade_invoke__");
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  static {
    __name(this, "___Facade_ScheduledController__");
  }
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name2(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name2(function(request, env22, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env22, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env22, ctx) {
      const dispatcher = /* @__PURE__ */ __name2(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env22, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env22, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
__name2(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name2((request, env22, ctx) => {
      this.env = env22;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name2((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
__name2(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;

// node_modules/wrangler/templates/pages-dev-util.ts
function isRoutingRuleMatch(pathname, routingRule) {
  if (!pathname) {
    throw new Error("Pathname is undefined.");
  }
  if (!routingRule) {
    throw new Error("Routing rule is undefined.");
  }
  const ruleRegExp = transformRoutingRuleToRegExp(routingRule);
  return pathname.match(ruleRegExp) !== null;
}
__name(isRoutingRuleMatch, "isRoutingRuleMatch");
function transformRoutingRuleToRegExp(rule) {
  let transformedRule;
  if (rule === "/" || rule === "/*") {
    transformedRule = rule;
  } else if (rule.endsWith("/*")) {
    transformedRule = `${rule.substring(0, rule.length - 2)}(/*)?`;
  } else if (rule.endsWith("/")) {
    transformedRule = `${rule.substring(0, rule.length - 1)}(/)?`;
  } else if (rule.endsWith("*")) {
    transformedRule = rule;
  } else {
    transformedRule = `${rule}(/)?`;
  }
  transformedRule = `^${transformedRule.replaceAll(/\./g, "\\.").replaceAll(/\*/g, ".*")}$`;
  return new RegExp(transformedRule);
}
__name(transformRoutingRuleToRegExp, "transformRoutingRuleToRegExp");

// .wrangler/tmp/pages-dOh9w8/ebpwuk3gufk.js
var define_ROUTES_default = { version: 1, include: ["/*"], exclude: ["/static/*"] };
var routes = define_ROUTES_default;
var pages_dev_pipeline_default = {
  fetch(request, env3, context3) {
    const { pathname } = new URL(request.url);
    for (const exclude of routes.exclude) {
      if (isRoutingRuleMatch(pathname, exclude)) {
        return env3.ASSETS.fetch(request);
      }
    }
    for (const include of routes.include) {
      if (isRoutingRuleMatch(pathname, include)) {
        const workerAsHandler = middleware_loader_entry_default;
        if (workerAsHandler.fetch === void 0) {
          throw new TypeError("Entry point missing `fetch` handler");
        }
        return workerAsHandler.fetch(request, env3, context3);
      }
    }
    return env3.ASSETS.fetch(request);
  }
};

// node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody2 = /* @__PURE__ */ __name(async (request, env3, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env3);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default2 = drainBody2;

// node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError2(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError2(e.cause)
  };
}
__name(reduceError2, "reduceError");
var jsonError2 = /* @__PURE__ */ __name(async (request, env3, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env3);
  } catch (e) {
    const error4 = reduceError2(e);
    return Response.json(error4, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default2 = jsonError2;

// .wrangler/tmp/bundle-o8UpaX/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__2 = [
  middleware_ensure_req_body_drained_default2,
  middleware_miniflare3_json_error_default2
];
var middleware_insertion_facade_default2 = pages_dev_pipeline_default;

// node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__2 = [];
function __facade_register__2(...args) {
  __facade_middleware__2.push(...args.flat());
}
__name(__facade_register__2, "__facade_register__");
function __facade_invokeChain__2(request, env3, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__2(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env3, ctx, middlewareCtx);
}
__name(__facade_invokeChain__2, "__facade_invokeChain__");
function __facade_invoke__2(request, env3, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__2(request, env3, ctx, dispatch, [
    ...__facade_middleware__2,
    finalMiddleware
  ]);
}
__name(__facade_invoke__2, "__facade_invoke__");

// .wrangler/tmp/bundle-o8UpaX/middleware-loader.entry.ts
var __Facade_ScheduledController__2 = class ___Facade_ScheduledController__2 {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__2)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler2(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env3, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env3, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env3, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__2(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env3, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__2(request, env3, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler2, "wrapExportedHandler");
function wrapWorkerEntrypoint2(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env3, ctx) => {
      this.env = env3;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__2(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__2(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint2, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY2;
if (typeof middleware_insertion_facade_default2 === "object") {
  WRAPPED_ENTRY2 = wrapExportedHandler2(middleware_insertion_facade_default2);
} else if (typeof middleware_insertion_facade_default2 === "function") {
  WRAPPED_ENTRY2 = wrapWorkerEntrypoint2(middleware_insertion_facade_default2);
}
var middleware_loader_entry_default2 = WRAPPED_ENTRY2;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__2 as __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default2 as default
};
//# sourceMappingURL=ebpwuk3gufk.js.map
