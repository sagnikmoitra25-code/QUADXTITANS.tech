# 🏥 HEALNEX - Healthcare Data Management Platform

**by QUADXTITAN**

A comprehensive, 3D-animated health tech platform designed to tackle healthcare data fragmentation and give individuals complete control over their health information.

---

## 🌐 Live Demo

**Public URL**: https://3000-ilqm37f3a4n843ha6ky69-ad490db5.sandbox.novita.ai

---

## ✨ Project Overview

HEALNEX is an innovative healthcare data management platform that addresses "The Fragmented Health Data Crisis" by providing:

- **Unified Health Records**: Complete patient medical history in one place
- **Smart Appointment Management**: Easy scheduling and tracking
- **Comprehensive Disease Database**: 500+ diseases with symptoms, causes, prevention, and treatment
- **AI-Powered Health Assistant**: Cloudflare AI-powered chatbot for health queries
- **Role-Based Access**: Separate portals for Patients, Doctors, and Admins

---

## 🎯 Currently Completed Features

### ✅ Patient Portal
- **Profile Management**: Complete health profile with blood group, allergies, chronic conditions
- **Appointment Booking**: Schedule appointments with specialized doctors
- **Medical History**: Track diagnoses, treatments, and health status
- **Prescriptions**: View all prescriptions with medications and instructions
- **Disease Database Access**: Search and learn about diseases
- **AI Health Assistant**: Get instant health information

### ✅ Doctor Portal
- **Patient Management**: View and manage patient list
- **Appointment Management**: Track and update appointment status
- **Prescription Writing**: Create detailed prescriptions with multiple medications
- **Patient History Access**: View complete patient medical history
- **Disease Database**: Reference comprehensive disease information
- **Diagnosis Tools**: Access to symptom and treatment information

### ✅ Admin Portal
- **System Statistics**: Overview of users, patients, doctors, appointments
- **User Management**: View and manage all system users
- **Platform Monitoring**: Track platform usage and health

### ✅ Core Features
- **3D Animated Interface**: Professional neon-tech design with Three.js particles
- **Secure Authentication**: Email/password login with role-based access
- **Comprehensive Disease Database**: 60+ diseases with detailed information
- **Real-time AI Chat**: Powered by Cloudflare AI (@cf/meta/llama-3-8b-instruct)
- **Responsive Design**: Works on all devices
- **Cloudflare D1 Database**: Fast, globally distributed SQLite database

---

## 📊 Data Architecture

### Data Models

#### Users
- Authentication and role management (patient, doctor, admin)
- Email, password, full name, role, timestamps

#### Patients
- Personal info: gender, blood group, date of birth
- Contact: phone, address, emergency contact
- Health info: allergies, chronic conditions

#### Doctors
- Professional info: specialization, license number
- Experience: years of experience, qualification
- Availability: consultation fee, available days/hours

#### Medical History
- Disease records with diagnosis date
- Status tracking (active, recovered, chronic, monitoring)
- Doctor attribution for diagnoses

#### Appointments
- Patient-doctor appointments with date/time
- Status tracking (scheduled, completed, cancelled)
- Reason for visit and notes

#### Prescriptions
- Diagnosis and medications (JSON array)
- Instructions and validity period
- Linked to appointments

#### Diseases (60+ entries)
- Comprehensive disease information
- Categories: Infectious, Cardiovascular, Respiratory, Digestive, etc.
- Symptoms, causes, prevention, treatment (JSON arrays)
- Severity levels and contagious status

### Storage Services
- **Cloudflare D1**: Primary database for all relational data
- **Cloudflare AI**: AI-powered health assistant
- **Local Storage**: Browser-based session management

---

## 🚀 Functional Entry Points

### Authentication APIs
- `POST /api/auth/register` - Register new user (patient/doctor)
  - Body: `{ email, password, full_name, role }`
- `POST /api/auth/login` - User login
  - Body: `{ email, password }`

### Patient APIs
- `GET /api/patients/:userId` - Get patient profile
- `PUT /api/patients/:userId` - Update patient profile
  - Body: `{ gender, blood_group, date_of_birth, phone, address, emergency_contact, allergies, chronic_conditions }`
- `GET /api/patients/:userId/history` - Get medical history
- `POST /api/patients/:userId/history` - Add medical history entry
  - Body: `{ disease_name, diagnosis_date, status, notes }`

### Doctor APIs
- `POST /api/doctors/profile` - Complete doctor profile
  - Body: `{ userId, specialization, license_number, phone, years_of_experience, qualification, consultation_fee }`
- `GET /api/doctors` - Get all doctors
- `GET /api/doctors/:userId/patients` - Get doctor's patients

### Appointment APIs
- `POST /api/appointments` - Create appointment
  - Body: `{ patientUserId, doctorId, appointment_date, appointment_time, reason }`
- `GET /api/appointments/patient/:userId` - Get patient appointments
- `GET /api/appointments/doctor/:userId` - Get doctor appointments
- `PUT /api/appointments/:id` - Update appointment status
  - Body: `{ status, notes }`

### Prescription APIs
- `POST /api/prescriptions` - Create prescription
  - Body: `{ patientUserId, doctorUserId, diagnosis, medications: [{name, dosage, frequency, duration}], instructions, valid_until }`
- `GET /api/prescriptions/patient/:userId` - Get patient prescriptions

### Disease APIs
- `GET /api/diseases` - Get all diseases
- `GET /api/diseases/:id` - Get disease details
- `POST /api/diseases/search` - Search diseases by symptoms
  - Body: `{ symptoms: [] }`

### AI API
- `POST /api/ai/chat` - AI health assistant
  - Body: `{ message, conversationHistory }`

### Admin APIs
- `GET /api/admin/users` - Get all users
- `GET /api/admin/stats` - Get system statistics

---

## 🎨 Tech Stack

### Frontend
- **HTML/CSS/JavaScript**: Core web technologies
- **Tailwind CSS**: Utility-first CSS framework (CDN)
- **Three.js**: 3D particle animation background
- **Font Awesome**: Icon library
- **Custom Fonts**: Orbitron (neon text), Rajdhani (body)

### Backend
- **Hono**: Lightweight web framework for Cloudflare Workers
- **TypeScript**: Type-safe development
- **Cloudflare Workers**: Edge runtime deployment
- **Vite**: Build tool and dev server

### Database & AI
- **Cloudflare D1**: Globally distributed SQLite database
- **Cloudflare AI**: LLM-powered health assistant

### Deployment
- **Cloudflare Pages**: Global CDN deployment
- **Wrangler**: Cloudflare CLI tool
- **PM2**: Process manager for local development

---

## 📝 Features Not Yet Implemented

### Planned Future Enhancements

1. **Security Improvements**
   - Password hashing with bcrypt
   - JWT token-based authentication
   - Session management
   - Rate limiting

2. **Advanced Features**
   - File upload for test reports (PDF, images)
   - Real-time notifications
   - Email notifications for appointments
   - SMS reminders
   - Video consultation integration
   - Prescription PDF generation

3. **Analytics**
   - Patient health trends
   - Appointment analytics
   - Disease outbreak tracking
   - Doctor performance metrics

4. **Enhanced AI**
   - Symptom checker
   - Drug interaction checker
   - Personalized health recommendations
   - Multi-language support

5. **Mobile App**
   - Native iOS/Android apps
   - Push notifications
   - Offline mode

---

## 🛠️ Recommended Next Steps

### Phase 1: Security Hardening
1. Implement bcrypt password hashing
2. Add JWT authentication
3. Implement CORS properly
4. Add rate limiting middleware
5. Add input validation and sanitization

### Phase 2: Feature Enhancement
1. Add file upload for medical reports (use Cloudflare R2)
2. Implement email notifications (use Resend or SendGrid)
3. Add prescription PDF generation
4. Enhance AI with symptom checker
5. Add doctor availability calendar

### Phase 3: Scale & Optimize
1. Add caching with Cloudflare KV
2. Implement search with full-text search
3. Add pagination for large datasets
4. Optimize database queries
5. Add performance monitoring

### Phase 4: Production Deployment
1. Create production D1 database
2. Set up environment variables
3. Configure custom domain
4. Set up monitoring and logging
5. Create backup strategy

---

## 🚀 User Guide

### For Patients

1. **Register**: Click "Get Started" and choose "Patient" role
2. **Complete Profile**: Fill in your health information
3. **Book Appointment**: Select a doctor and choose date/time
4. **Track Health**: View your medical history and prescriptions
5. **Ask AI**: Use the chatbot for health questions

### For Doctors

1. **Register**: Sign up with "Doctor" role
2. **Complete Profile**: Add specialization, license, and availability
3. **Manage Appointments**: View and update appointment status
4. **Write Prescriptions**: Create detailed prescriptions for patients
5. **View Patients**: Access patient medical history

### For Admins

1. **Login**: Use admin credentials
2. **Monitor System**: View statistics and user activity
3. **Manage Users**: View and manage all platform users

---

## 💻 Local Development

### Prerequisites
- Node.js 18+
- npm or yarn
- Wrangler CLI

### Setup

```bash
# Clone repository
git clone <repository-url>
cd webapp

# Install dependencies
npm install

# Setup local database
npm run db:migrate:local
npm run db:seed

# Build project
npm run build

# Start development server
pm2 start ecosystem.config.cjs

# Or use npm script
npm run dev:sandbox
```

### Available Scripts

```bash
npm run dev              # Vite dev server
npm run dev:sandbox      # Wrangler pages dev with D1
npm run build            # Build for production
npm run deploy           # Deploy to Cloudflare Pages
npm run db:migrate:local # Apply migrations locally
npm run db:seed          # Seed database
npm run db:reset         # Reset local database
npm run clean-port       # Kill process on port 3000
npm run test             # Test local server
```

---

## 📦 Deployment

### Cloudflare Pages Deployment

```bash
# 1. Create D1 database
npx wrangler d1 create healnex-db

# 2. Update wrangler.jsonc with database ID

# 3. Apply migrations to production
npm run db:migrate:prod

# 4. Seed production database
npx wrangler d1 execute healnex-db --file=./seed.sql

# 5. Deploy to Cloudflare Pages
npm run deploy:prod
```

---

## 🔒 Security Notes

⚠️ **IMPORTANT**: The current implementation uses plain-text passwords for demonstration purposes. 

For production deployment:
1. Implement bcrypt password hashing
2. Use JWT tokens for authentication
3. Add HTTPS-only cookies
4. Implement CSRF protection
5. Add rate limiting
6. Sanitize all user inputs
7. Use environment variables for secrets

---

## 📄 License

This project was created for CodeXVerse 2.0 Health Tech Track by Team QUADXTITAN.

---

## 👥 Team QUADXTITAN

Built with ❤️ for better healthcare data management.

---

## 🐛 Known Issues

1. Password stored as plain text (needs bcrypt)
2. No JWT authentication (uses localStorage)
3. AI responses can be slow (Cloudflare AI cold start)
4. No file upload functionality yet
5. Disease search could be more sophisticated

---

## 📞 Support

For issues or questions, please open an issue in the repository.

---

## 🎉 Acknowledgments

- **Cloudflare**: For D1 database and AI services
- **Hono**: For the excellent web framework
- **Three.js**: For 3D animations
- **Tailwind CSS**: For rapid UI development
- **CodeXVerse 2.0**: For the inspiration and challenge

---

**Last Updated**: 2025-10-26

**Version**: 1.0.0

**Status**: ✅ Fully Functional (Development Mode)
